$(document).ready(function(){
	
	// properties ----
	var athleteIndex;																	// stores the index of the current athlete
	var athleteObj;																		// stores the current athlete object
	var athleteTransition		= false;												// set to true when the athletes are transition in and out of "Athlete's Area"
	var browser;																		// stores the type of browser ex. webkit, safari, opera, msie or mozilla
	var browserVersion;																	// stores the browser version ex 11
	var causeObj;																		// stores the current organization object
	var currentAthlete;																	// stores the index of the current athlete in the "Athlete's Area"
	var currentIndicatorPos;															// stores the index of the current indicator position
	var currentSection;																	// stores the index of the current section
	var hasSupportedAnAthlete	= false;												// set to true if the user has already supported an athlete
	var indicator				= $("#nav-indicator");									// reference to the nav indicator
	var layout;																			// stores the layout object
	var logo 					= $("#logo");											// reference to the logo
	var logoAnimating			= false;												// set to true when the log is fading in and out
	var menu					= $("#menu");											// reference to the menu
	var menux					= Math.ceil(($(window).width() - menu.width()) / 2);	/// stores the current x position of the menu
	var menuPositions 			= [-430, -291, -200, -85, 75];							// hard code margin-left positions
	var pointsFadeInit			= false;												// set to true as soon as points fade has started (use so that it's only triggered once)
	var startParallax 			= false;												// set to true to activate parallax fx in athlete's area
	var userid;																			// stores the user id for this session			

	// constructor ----
	function init(){
		rtz();
		getBrowserAndVersion();
		getCurrentSection();
		hideLogo();
		positionMenuIndicator();
		getAthlete();
		makeChocolateChips();
		checkSupport();
		//applyPIE();
	}
	
	// for testing on IE ----
	var alertFallback = true;
	if (typeof console === "undefined" || typeof window.ui.log === "undefined") {
		console = {};
		if (alertFallback) {
			window.ui.log = function(msg) {
				//alert(msg);
			};
		} else {
			window.ui.log = function() {};
		}
	}
	
	// get browser type and version
	function getBrowserAndVersion(){
		browserVersion = $.browser.version;
		if ($.browser.webkit) {
			var isiPad = navigator.userAgent.match(/iPad/i) != null;
			var isiPhone = navigator.userAgent.match(/iPhone/i) != null;
			var isiPod = navigator.userAgent.match(/iPod/i) != null;
			browser =  (isiPad || isiPhone || isiPod) ? "ios" : "webkit" 
		}
		
		if ($.browser.opera) {
			browser = "opera";
		}
		
		if ($.browser.msie) {
			browser = "msie";
		}
		
		if ($.browser.mozilla) {
			browser = "firefox";
		}
	}
	
	// bring all changing elements to it's starting states (R.eturn T.o Z.ero) ----
	function rtz(){
		//$("#support-facebook").css({opacity:0});
		//$("#thankyou-wrapper").css({opacity:0});
		//$("#support-donate").css({opacity:0});
	}
	
	// cookie monster ----
	function getFlashMovie(name){
		return (navigator.appName.indexOf("Microsoft") != -1) ? window[name] : document[name];
	}
	
	var cookieInterval;
	function makeChocolateChips(){
		cookieInterval = setInterval(function(){
			if (externalInterfaceReady){
				clearInterval(cookieInterval);
				ei.cookieDoesntExist = cookieDoesntExist;
				ei.cookieExists = cookieExists;
				doesCookieExist();
			}
		}, 100);
	}
	
	// check if cookie already exists
	function doesCookieExist(){
		getFlashMovie("kookie").doesCookieExist();
	}
	
	// set userid if cookie already exists
	function cookieExists(val){
		userid = val;
		window.ui.log("userid already exists: " + userid);
	}
	
	// get cookie if doesnt exist generate userid
	function cookieDoesntExist(){
		$.get("/users/id/?token=" + co.model.csrfToken, function(data){
			userid = data.id;
			window.ui.log("userid (generated): " + userid);
			getFlashMovie("kookie").createFlashCookie(userid);
		});
	}
	
	// check if the user has supported an athlete already ----
	var supportInterval;
	function checkSupport(){
		supportInterval = setInterval(function(){
			if (externalInterfaceReady){
				clearInterval(supportInterval);
				ei.neverSupported = neverSupported;
				ei.hasSupported = hasSupported;
				hasUserSupported();
			}
		}, 100);
	}
	
	// check if the user has already supported an athlete ----
	function hasUserSupported(){
		getFlashMovie("kookie").hasUserSupported();
	}
	
	// set to false if the user never supported an athlete ----
	function neverSupported(){
		hasSupportedAnAthlete = false;
		window.ui.log("has supported an athlete: " + hasSupportedAnAthlete);
	}
	
	// set to true if the user has supported an athlete ----
	function hasSupported(){
		hasSupportedAnAthlete = true;
		window.ui.log("has supported an athlete: " + hasSupportedAnAthlete);
	}
	
	// create dynamic facebook link ----
	$(".facebook-link").attr("href", "https://apps.facebook.com/" + co.model.fbNamespace);
	$(".pagetab-link").attr("href", "https://facebook.com/CitiEveryStep/app_302562616477105");
	$(".facebook-link").attr("data-tracking","Home_FB_CLK");
	$(".pagetab-link").attr("data-tracking","Home_FB_CLK");
	
	// gradient text ----
	//$('h1').canvasToolbox({type:'gradient-title'});
	
	/* apply PIE to initial dom elements that need it
	function applyPIE(){
		if(window.PIE) {
			window.ui.log("ummmmm... pie");
			$('#textfields input[type="text"], #textfields input[type="email"], #checkboxes input[type="text"]').each(function() {
				PIE.detach(this);
				PIE.attach(this);
			});
		}
	}
	*/
	
	// hide the logo based on scroll position ----
	function hideLogo(){
		//if (!logoAnimating){
		//	logoAnimating = true;
			if ($(window).scrollTop() > 100){
				$("#logo").fadeOut(250, function(){
					logoAnimating = false;
				});
				//$("#logo2").fadeTo(250, 1);
			} else {
				//$("#logo2").fadeTo(250, 0);
				$("#logo").fadeIn(250, function(){
					logoAnimating = false;
				});
			}
	//	}
	}
	
	// functionality for menu indicator ----
	function positionMenuIndicator(){
		indicator.css({"margin-left": menuPositions[currentSection]});
		currentIndicatorPos = currentSection;
		setCurrentMenu();
	}
	
	// move the nav indicator to the correct position based on the item clicked ----
	function moveMenuIndicator(index){
		// [-430, -291, -200, -85, 75]
		var mc = $($(".text-link")[index]);
		var mc_width = mc.width();
		var mc_x = mc.offset().left;
		
		var ind = $("#nav-indicator");
		var ind_width = ind.width();
		var ind_x = ind.offset().left;
		
		var page_center = $(window).width() / 2;
		
		var marginleft = mc_x + (mc_width / 2) - (ind_width / 2) - page_center;
		/*
		$("#nav-indicator").animate({marginLeft: menuPositions[index] + "px"}, 800, "easeOutQuad", function(){
			currentIndicatorPos = index;
			setCurrentMenu();
		});
		*/
		$("#nav-indicator").animate({marginLeft:marginleft + "px"}, 800, "easeOutQuad", function(){
			currentIndicatorPos = index;
			setCurrentMenu();
		});
	}
	
	// changes the current menu to red ----
	function setCurrentMenu(){
		var menuItems = $("#menu li.text-link");
		$.each(menuItems, function(){
			$(this).removeClass("current");
		});
		$(menuItems[currentSection]).addClass("current");
	}
	
	// handler for main video ----
	$("#main-video-poster").click(function(){
		var overlayWidth = $(window).width();
		var overlayHeight = $(document).height();
		$("#black-overlay").css({"width":overlayWidth, "height":overlayHeight, opacity:.5});
		$("#black-overlay").fadeIn("fast");
		// get width and height of window
		var winw = $(window).width();
		var winh = $(window).height();
		
		$("#video-player-new").css({
			"width": 960,
			"height":540,
			"top": $(window).scrollTop() + (winh / 2) - $("#video-player-new").height() / 2,
			"left": (winw - $(this).width()) / 2 + 32
		});
		
		if (browser != "ios") {
			$("#video-player").show();
			$("#ios-player").hide();
			
			$f("video-player", "flowplayer/flowplayer.commercial-3.2.7.swf", {
				key: co.model.flowplayer.license,
				logo: null,
				wmode: "opaque",
				clip: {
					url: streamingPath + "/video/page-tab.flv",
					autoPlay: true,
					autoBuffering: true/*,
				 	scaling: "fit"*/
				},		
				canvas: {
					backgroundColor: 'rgba(255, 252, 255, 1)'
									},
				plugins: {
 					controls: {
						"borderRadius":0,
						"timeColor":"#ffffff",
						"bufferGradient":"none",
						"backgroundColor":"rgba(8, 132, 194, 1)",
						"volumeSliderGradient":"none",
						"timeBorderRadius":20,
						"time":false,
						"progressGradient":"none",
						"height":20,
						"volumeColor":"#003d7e",
						"opacity":1,
						"timeFontSize":12,
						"border":"0px",
						"bufferColor":"#ffffff",
						"progressColor": "#003d7e",
						"volumeSliderColor":"#ffffff",
						"buttonColor":"#ffffff",
						"autoHide": {"enabled":true,"hideDelay":500,"hideStyle":"fade","mouseOutDelay":500,"hideDuration":400,"fullscreenOnly":false}
					},
					"backgroundGradient":[0.5,0.4,0.3,0.2,0,0,0,0],
					"width":"100pct","display":"block",
					"sliderBorder":"1px solid rgba(128, 128, 128, 0.7)",
					"buttonOverColor":"#ffffff","url":"flowplayer.controls-3.2.5.swf",
					"fullscreen":false,
					"timeBgColor":"rgb(0, 0, 0, 0)",
					"borderWidth":0,
					"scrubberBarHeightRatio":0.5,
					"bottom":0,
					"buttonOffColor":"rgba(130,130,130,1)",
					"zIndex":1,
					"sliderColor":"#000000",
					"scrubberHeightRatio":0.5,
					"tooltipTextColor":"#ffffff",
					"spacing":{"time":6,"volume":8,"all":2},
					"sliderGradient":"none",
					"timeBgHeightRatio":0.6,
					"volumeSliderHeightRatio":0.8,
					"name":"controls",
					"timeSeparator":" ",
					"volumeBarHeightRatio":0.4,
					"left":"50pct",
					"tooltipColor":"#000000",
					"durationColor":"#ffffff",
					"progressColor":"#ffffff",
					"timeBorder":"0px solid rgba(0, 0, 0, 0.3)",
					"volume":false,
					"builtIn":false,
					"volumeBorder":"1px solid rgba(128, 128, 128, 0.7)",
					"margins":[2,12,2,12]
				},		
				onLoad: function(){
					//$("#video-player_api").prepend('<param value="transparent" name="wmode">');
				
					$("#logo").fadeOut("fast");
					$("#main-video-poster").fadeOut(400, function(){
						$(this).attr("src", "images/video-poster-end.png");
						$(this).delay(300).fadeIn(400);
					});

					$("#video-close-bttn").click(function(event){
						$("#black-overlay").trigger("click");
						$("#video-player").add("#ios-player").remove();
						$("#video-player-container").prepend('<div id="video-player"></div><div id="ios-player"></div>');
						event.stopPropagation();
					});
				},
				onFinish: function(){
					$("#black-overlay").trigger("click");
					$("#logo").fadeIn("fast");
				}
			});
		} else {
			$("#video-player").hide();
			$("#ios-player").show();
			//$("#ios-player").prepend('<video width="960" height="540" controls="controls" autoplay="autoplay"><source id="ios-video-source" type="video/mp4" src="video/page-tab.mp4" /></video>');
			$("#ios-player").html('<video width="960" height="540" controls="controls" autoplay="autoplay"><source id="ios-video-source" type="video/mp4" src="' + streamingPath + '/video/page-tab.mp4" /></video>');
		}
		
		$("#video-player-new").fadeIn("fast");
	});
	
	// fetch athlete data ----
	var fetchAthleteInterval;
	function getAthlete(){
		var numOfAthletes = co.model.athletes.length;
		athleteIndex = Math.floor(Math.random() * numOfAthletes - 1) + 1; // un-comment this line for random athlete selection
	//	window.ui.log("athlete index: " + athleteIndex);
	//	athleteIndex = 1; // un-comment this line to debug specific athletes
		athleteObj = co.model.athletes[athleteIndex];
		causeObj = getCause();
		currentAthlete = athleteObj.firstName + " " + athleteObj.lastName;
		
		for (var i = 0; i < AthleteLayoutObj.athletes.length; i++){
			if (AthleteLayoutObj.athletes[i].fullName == currentAthlete){
				layout = AthleteLayoutObj.athletes[i];
			}
		}
		
		moveAthleteMenuIndicator(layout.thumbnailPosition);
		selectThumbnail($("." + layout.thumbnailClass).find("img"));
		fetchAthleteInterval = setInterval(function(){
			if (externalInterfaceReady){
				clearInterval(fetchAthleteInterval);
				loadAthleteData();
			}
		}, 100);
	}
	
	// fetch athlete cause data ----
	function getCause(){
		for (var i = 0; i < co.model.causes.length; i++){
			if (co.model.causes[i].id == athleteObj.causeId){
				return co.model.causes[i];
			}
		}
	}
	
	// rollover handler for athletes menu ----
	var currentw, currenth, img;
	$(".athlete-tn").mouseover(function(){
		var img = $(this).find("img");
		var source = img.attr("src");
		var filename = source.substr(source.lastIndexOf("/") + 1);
		var arr = filename.split("-");
		var athlete = arr[0];
		var state = arr[1];
		
		if (state == "fade.png"){
			img.attr("src", "/images/" + athlete + "-filled.png");
		}
		
		//
		currentw = img.width();
		currenth = img.height();
		var scale = 1.5;
		//img.stop(true, false).animate({width:currentw * 1.5, height:currenth * 1.5}, 400);
		
		// rollover tooltip
		$("#athlete-rollovers").stop();
		if (athlete == "mcgrory"){
			$("#athlete-rollovers").removeClass("center");
		} else {
			$("#athlete-rollovers").addClass("center");
		}
		$("#athlete-rollovers").show();
		$(".rollover-name").html($(this).find("img").attr("alt"));
		$(".rollover-sport").html(co.model.athletes[getMicroSiteOrder($(this).find("img").attr("rel"))].sport);
		
		// get the xpos to where the tooltip should appear
		var newx = ($(this).find("img").offset().left + ($(this).find("img").width() / 2)) - ($("#athlete-rollovers").width() / 2);
		
		// keep the tooltip inside of the main container if newx is outside
		if (newx < $("#main-container").offset().left){
			newx += 50;
		}
		if (newx + $("#athlete-rollovers").width() > $("#main-container").offset().left + $("#main-container").width()){
			newx -= 15;
		}
		
		//window.ui.log(("#main-container").offset().left);
		$("#athlete-rollovers").css({
			"top":$("#athletes #nav-container").offset().top,
			"left":newx
		});
		
		$("#athlete-rollovers").css({opacity:1});
	});
	
	// rollout handler for athletes menu ----
	$(".athlete-tn").mouseout(function(){
		$.each($(".athlete-tn"), function(){
			var img = $(this).find("img");
			var source = img.attr("src");
			var filename = source.substr(source.lastIndexOf("/") + 1);
			var arr = filename.split("-");
			var athlete = arr[0];
			var state = arr[1];
			var athleteAlt = img.attr("alt");
			
			if (state == "filled.png" && athleteAlt != currentAthlete){
				img.attr("src", "/images/" + athlete + "-fade.png");
			}
			
			//img.stop(true, false).animate({width:currentw, height:currenth}, 400);
		});
		$("#athlete-rollovers").fadeOut("fast");
	});
		
	// fetch the athlete index from the db microsite order ----
	function getMicroSiteOrder(num) {
		for (var i = 0; i < co.model.athletes.length; i++){
			if (co.model.athletes[i].micrositeOrder == num){
				return i;
			}
		}
	}
	
	// click handler for athletes menu ----
	$(".athlete-tn").click(function changeToAthlete(event){
		//console.log(event.target.nodeName + ", " + event.currentTarget.nodeName + ", " + event.delegateTarget.nodeName);
		ui.tracking.track("Home_Ath_PV");
		if (!athleteTransition){
			
			if (event.target.nodeName == "IMG") {
				
				$.scrollTo($("#nav-container").offset().top - 91, 400, {easing:"easeOutQuad"});
			}
			
			else {
				
				$.scrollTo($("#nav-container").offset().top + 100, 400, {easing:"easeOutQuad"});
			}
			
			var athlete = $(this).find("img").attr("alt");
			var athlete_img = $(this).find("img");
		
			if (currentAthlete != athlete){
				athleteTransition = true;
				currentAthlete = athlete;
				switch(athlete){
					case "Amanda McGrory": 			moveAthleteMenuIndicator(AthleteLayoutObj.athletes[0].thumbnailPosition); break;
					case "Bob & Mike Bryan":		moveAthleteMenuIndicator(AthleteLayoutObj.athletes[1].thumbnailPosition); break;
					case "Carlos Leon": 			moveAthleteMenuIndicator(AthleteLayoutObj.athletes[2].thumbnailPosition); break;
					case "Christie Rampone": 		moveAthleteMenuIndicator(AthleteLayoutObj.athletes[3].thumbnailPosition); break;	
					case "Cullen Jones": 			moveAthleteMenuIndicator(AthleteLayoutObj.athletes[4].thumbnailPosition); break;
					case "Danell Leyva": 			moveAthleteMenuIndicator(AthleteLayoutObj.athletes[5].thumbnailPosition); break;
					case "Dominique Dawes": 		moveAthleteMenuIndicator(AthleteLayoutObj.athletes[6].thumbnailPosition); break;
					case "Gwen Jorgensen": 			moveAthleteMenuIndicator(AthleteLayoutObj.athletes[7].thumbnailPosition); break;
					case "Kari Miller": 			moveAthleteMenuIndicator(AthleteLayoutObj.athletes[8].thumbnailPosition); break;
					case "Meb Keflezighi": 			moveAthleteMenuIndicator(AthleteLayoutObj.athletes[9].thumbnailPosition); break;
					case "Rowdy Gaines": 			moveAthleteMenuIndicator(AthleteLayoutObj.athletes[10].thumbnailPosition); break;
					case "Sanya Richards-Ross": 	moveAthleteMenuIndicator(AthleteLayoutObj.athletes[11].thumbnailPosition); break;
				}
				
				resetAllThumbnails();
				selectThumbnail(athlete_img);
			
				var i;
				$("#athletes-container").animate({height:"730px"})
				.fadeTo("fast", 0, function(){
					for (i = 0; i < AthleteLayoutObj.athletes.length; i++){
						if (AthleteLayoutObj.athletes[i].fullName == athlete){
							athleteIndex = AthleteLayoutObj.athletes[i].athleteIndex;
						}
					}
					//
					//athleteObj = co.model.athletes[athleteIndex];
					athleteObj = co.model.athletes[getMicroSiteOrder(athleteIndex)];
					causeObj = getCause();
					currentAthlete = athleteObj.firstName + " " + athleteObj.lastName;
				
					for (i = 0; i < AthleteLayoutObj.athletes.length; i++){
						if (AthleteLayoutObj.athletes[i].fullName == currentAthlete){
							layout = AthleteLayoutObj.athletes[i];
						}
					}
				
					loadAthleteData();
				});
			}
		}
	});
	
	// load athlete data ----
	function loadAthleteData(){
		$("#athletes-container").load("athletes-data.php #sanya", function(){
			// turn off parallax fx
			startParallax = false;
			
			var supportBttnTop;
			
			$(".facebook-link").attr("href", "https://apps.facebook.com/" + co.model.fbNamespace);
			$(".pagetab-link").attr("href", "https://facebook.com/CitiEveryStep/app_302562616477105");
				
			// main image
			$("#full-image img").attr("src", layout.largeImage);
			$("#full-image img").attr("alt", layout.fullName);
			$("#full-image").css({
				"top":layout.largeImageStartPos.top,
				"left":layout.largeImageStartPos.left,
				opacity:0
			});
			
			// label
			$("#athlete-firstname").html(athleteObj.firstName);
			$("#athlete-lastname").html(athleteObj.lastName);
			$("#athlete-sport").html(athleteObj.sport);
			$("#athlete-label-wrapper").width(layout.labelWidth);
			$("#athlete-label-wrapper").css({"left":-($("#athlete-label-wrapper").width())});
			if(window.PIE) {
				$(".athlete-label, .athlete-sport").each(function() {
					PIE.detach(this);
					PIE.attach(this);
				});
			}
			
			// tab menu
			$("#athlete-tab-menu").css({"top":layout.tabMenuPos.top, "left":layout.tabMenuPos.left, "z-index":layout.tabMenuZIndex});
			$("#organization-container img").attr("src", layout.organizationImage);
			$("#organization-container img").attr("alt", causeObj.title);
			//$("#athlete-tab-menu").css({"width":$("#story-label").width() + $("#tab-bullet").width() + $("#org-label").width() + $("#org-img").width()});
			$("#story-label").html("About " + athleteObj.firstName);
			$("#information p#about-text").html(athleteObj.story);
			$("#information p#org-text").html(causeObj.description);
			// hide support button if user already supported
			if (!hasSupportedAnAthlete) {
				$(".bttn-label").html("Support " + athleteObj.firstName);
				$("#support-bttn-container img").attr( "alt", "Support " + athleteObj.firstName);
			} else {
				$(".support-bttn-container").hide();
			}
			window.ui.log("has supported an athlete: " + hasSupportedAnAthlete);
			//fixes ie8 render issue
			if (!hasSupportedAnAthlete) {
				
				if($.browser.msie && $.browser.version<="8.0")	{
					$("#support-icon").attr('src', '/images/cta-support-icon-ie.png');
					$("#support-icon").css('top', '0px');
					$(".support-bttn-container span").css('top', '-10px');		
					$('#textfields input[type="text"], #textfields input[type="email"], #checkboxes input[type="text"]').addClass('ieShadow');				
				}
				
				/*fixes ie8 hover issue	*/
				if($.browser.msie && $.browser.version=="7.0")	{
					$(".support-bttn-container").css('display', 'inline');
					$('#percent-graphic-container div').css('left', '0px');	
				}
			}
			
			// quick stats
			$("#quick-stats").css({"top":layout.quickStatsPos.top, "left":layout.quickStatsPos.left});
			$("#quick-stats .sport").html(athleteObj.sport);
			$("#quick-stats .status").html(athleteObj.olympicsStatus);
			$("#quick-stats .age").html(ui.dateToAge(athleteObj.birthDate));
			$("#quick-stats .hometown").html(athleteObj.homeCity + ", " + athleteObj.homeState);
			$("#quick-stats .organization").html(causeObj.shortTitle);
			
			// progress
			$("#progress").css({"top":layout.progressPos.top, "left":layout.progressPos.left, "z-index":layout.progressZIndex});
			var goal = athleteObj.goal;
			var firstnum = goal.charAt(0);
			var secondnum = goal.charAt(1);
			var numvalue = ui.numberToWord(goal).split(" ");
			var addpoint = (secondnum != 0) ? "." + secondnum + " " : " ";
			var finalgoal = firstnum + addpoint + numvalue[1];
			$("#percent-container .goal").html("Goal: " + finalgoal);
			if (window.PIE){
				$("#progress").each(function(){
					PIE.detach(this);
					PIE.attach(this);
				});
			}
			
			// 2nd main image
			$("#full-image2 img").attr("src", layout.largeImage2);
			$("#full-image2").css({
				"top":layout.largeImage2Pos.top,
				"left":layout.largeImage2Pos.left
			});
			
			// support details
			$("#support-details").css({
				"top":layout.supportDetailsPos.top,
				"left":layout.supportDetailsPos.left
			});
			$("#support-details .support-firstname").html(athleteObj.firstName);
			$("#support-details .support-sport").html(athleteObj.sport);
			$("#support-details .support-organization").html(causeObj.title);
			$("#points-description p i").html(causeObj.title);
			$("#support-details .col1 .dollars").html("$" + ui.commifyNumber(athleteObj.usocDonations));
			$("#support-details .col2 .dollars").html("$" + ui.commifyNumber(athleteObj.tyPointDonations));
			$("#bttn-enter-promo").click(function(e){
				e.preventDefault();
				// get width and height for overlay
				var overlayWidth = $(window).width();
				var overlayHeight = $(document).height();
				$("#black-overlay").css({"width":overlayWidth, "height":overlayHeight, opacity:.5});
				$("#black-overlay").fadeIn("fast");
				// get width and height of window
				var winw = $(window).width();
				var winh = $(window).height();
				// position modal
				$("#enter-promo-modal").css({
					"top": $(window).scrollTop() + (winh / 2) - $("#enter-promo-modal").height() / 2,
					"left": (winw - $(this).width()) / 2
				});
				//
				$("#promo-code").removeClass("requiredText");
				$("#promo-code-form label").hide();
				// fade in modal
				if($('html').is('.ie7')) {
					$("#enter-promo-modal").each(function() {
						PIE.detach(this);
						PIE.attach(this);
						$("#enter-promo-modal").show();
					});
				} else {
					$("#enter-promo-modal").fadeIn("fast");
				}
			});
			
			//thank you modal
			$("#thankyou-modal .athlete-sport-label").html(athleteObj.sport);
			$("#thankyou-modal .athlete-organization").html(causeObj.title);
			
			// fade in container
			$(this).fadeTo("fast", 1);
			
			// animate everything in
			$("#athlete-label-wrapper").animate({left:0}, {duration: 400, easing: "easeOutSine"});
			$("#athlete-tab-menu").delay(300).fadeIn(400, function(){
				$("#tab-indicator img").css("margin-left", (($("#story-label").width() - $("#tab-indicator img").width()) / 2) + "px"); /// this sets the initial position for the tab menu indicator
			});
			
			/* applie PIE to 'Support Button' */
			if (window.PIE) {
				$(".support-bttn-container").each(function(){
					PIE.detach(this);
					PIE.attach(this);
				});
			}
			
			//
			$("#quick-stats").delay(600).fadeIn(400);
			$("#progress").delay(900).fadeIn(400);
			$("#full-image").delay(1200).animate({
				top: layout.largeImagePos.top,
				left: layout.largeImagePos.left,
				opacity: 1
			},{
				duration: 800,
				easing: "easeOutSine",
				complete: function(){
				//	startParallax = true;
					athleteTransition = false;
					showControls();
					positionInvisibleButtons();
					loadProgressData(athleteObj.points, athleteObj.goal);
				}
			});
		});
	}
	
	// show the controls in the athlete's area ----
	function showControls(){
		var i;
		var layoutArr = AthleteLayoutObj.athletes;
		
		if (layout.id != 0){
			$("#prev-bttn").click(function(){
				for (i = 0; i < layoutArr.length; i++){
					if (layoutArr[i].fullName == currentAthlete){
						var prevID = layoutArr[i].id - 1;
					}
				}
				
				for (i = 0; i < layoutArr.length; i++){
					if (layoutArr[i].id == prevID){
						var tnClass = layoutArr[i].thumbnailClass;
					}
				}
					
				$("." + tnClass).trigger("click");
			});
			
			$("#prev-bttn").fadeIn("fast");
		}
		
		if (layout.id != 11){
			$("#next-bttn").click(function(){
				for (i = 0; i < layoutArr.length; i++){
					if (layoutArr[i].fullName == currentAthlete){
						var nextID = layoutArr[i].id + 1;
					}
				}
				
				for (i = 0; i < layoutArr.length; i++){
					if (layoutArr[i].id == nextID){
						var tnClass = layoutArr[i].thumbnailClass;
					}
				}
				
				$("." + tnClass).trigger("click");
			});
			
			$("#next-bttn").fadeIn("fast");
		}
		
		$("#play-bttn").css({
			"top":layout.playBttnPos.top,
			"left":layout.playBttnPos.left
		});
		
		$("#play-bttn").fadeIn("fast", function(){
			$(this).click(function(){
				// get width and height for overlay
				var overlayWidth = $(window).width();
				var overlayHeight = $(document).height();
				$("#black-overlay").css({"width":overlayWidth, "height":overlayHeight, opacity:.5});
				$("#black-overlay").fadeIn("fast");
				// get width and height of window
				var winw = $(window).width();
				var winh = $(window).height(); 
				//
				$("#video-player-new").css({
					"width": 960,
					"height":540,
					"top": $(window).scrollTop() + (winh / 2) - $("#video-player-new").height() / 2,
					"left": (winw - $("#video-player-new").width()) / 2
				});
				//
				if (browser != "ios") {
					$("#video-player").show();
					$("#ios-player").hide();
					
					$f("video-player", "flowplayer/flowplayer.commercial-3.2.7.swf", {
						key: co.model.flowplayer.license,
						logo: null,
						wmode: "opaque",
						clip: {
							url: layout.video,
							autoPlay: true,
							autoBuffering: true,
							scaling: "fit",
							"onStart": function() {
								ui.tracking.track("Home_AthVideo_CLK");
							}
						},
							canvas: {
    						backgroundColor: 'rgba(255, 252, 255, 1)'
						},
						plugins: {
							controls: {
								"borderRadius":0,
								"timeColor":"#ffffff",
								"bufferGradient":"none",
								"backgroundColor":"rgba(8, 132, 194, 1)",
								"volumeSliderGradient":"none",
								"timeBorderRadius":20,
								"time":false,
								"progressGradient":"none",
								"height":20,
								"volumeColor":"#003d7e",
								"opacity":1,
								"timeFontSize":12,
								"border":"0px",
								"bufferColor":"#ffffff",
								"progressColor": "#003d7e",
								"volumeSliderColor":"#ffffff",
								"buttonColor":"#ffffff",
								"autoHide": {"enabled":true,"hideDelay":500,"hideStyle":"fade","mouseOutDelay":500,"hideDuration":400,"fullscreenOnly":false}
							},
							"backgroundGradient":[0.5,0.4,0.3,0.2,0,0,0,0],
							"width":"100pct","display":"block",
							"sliderBorder":"1px solid rgba(128, 128, 128, 0.7)",
							"buttonOverColor":"#ffffff","url":"flowplayer.controls-3.2.5.swf",
							"fullscreen":false,
							"timeBgColor":"rgb(0, 0, 0, 0)",
							"borderWidth":0,
							"scrubberBarHeightRatio":0.5,
							"bottom":0,
							"buttonOffColor":"rgba(130,130,130,1)",
							"zIndex":1,
							"sliderColor":"#000000",
							"scrubberHeightRatio":0.5,
							"tooltipTextColor":"#ffffff",
							"spacing":{"time":6,"volume":8,"all":2},
							"sliderGradient":"none",
							"timeBgHeightRatio":0.6,
							"volumeSliderHeightRatio":0.8,
							"name":"controls",
							"timeSeparator":" ",
							"volumeBarHeightRatio":0.4,
							"left":"50pct",
							"tooltipColor":"#000000",
							"durationColor":"#a3a3a3",
							"progressColor":"#ffffff",
							"timeBorder":"0px solid rgba(0, 0, 0, 0.3)",
							"volume":false,
							"builtIn":false,
							"volumeBorder":"1px solid rgba(128, 128, 128, 0.7)",
							"margins":[2,12,2,12]
						},
						onLoad: function (){
							/*$("#videoPlayer").prepend('<img id="videoplayer-close-bttn" class="close-bttn2 float-right" src="images/global/modal-close.png" width="27" height="27" alt="Close" />');
							$("#videoplayer-close-bttn").click(function(){
								$("#black-overlay").trigger("click");
								$("#videoPlayer").remove();
								$('<div id="videoPlayer"></div>').insertAfter("#athlete-rollovers");
							});*/
							$("#video-close-bttn").click(function(event){
								$("#black-overlay").trigger("click");
								$("#video-player").add("#ios-player").remove();
								$("#video-player-container").prepend('<div id="video-player"></div><div id="ios-player"></div>');
								event.stopPropagation();
							});
						},
						onFinish: function(){
							$("#black-overlay").trigger("click");
						}
					});
				} else {
					$("#video-player").hide();
					$("#ios-player").show();
					$("#ios-player").html('<video width="960" height="540" controls="controls" autoplay="autoplay"><source id="ios-video-source" type="video/mp4" src="' + layout.video + '" /></video>');
					ui.tracking.track("Home_AthVideo_CLK"); // trigger this onStart instead
				}
		
				$("#video-player-new").fadeIn("fast");
			});
		});
	}
	
	// position the invisible button & invisible button functionality ----
	function positionInvisibleButtons() {
		
		var supportBttnTop; 
		var currentTabSection = $("#about-text");
		var currentTabSectionName = "about";
		
		$("#invisible-tab").css({"top":parseInt($("#athlete-tab-menu").css("top")) + 12, "left":$("#athlete-tab-menu").position().left});
		$("#story-tab").width($("#story-label").width());
		$("#story-tab").mouseover(function(){
			if ($("#org-text").is(":visible")){
				$("#story-label").addClass("current");
			}
		});
		$("#story-tab").mouseout(function(){
			if ($("#org-text").is(":visible")){
				$("#story-label").removeClass("current");
			}
		});
		$("#story-tab").click(function(){
			// set current section
			currentTabSection = $("#about-text");
			currentTabSectionName = "about";
			// add/remove current class
			$("#story-label").addClass("current");
			$("#org-label").removeClass("current");
			// position indicator
			$("#tab-indicator img").css("margin-left", (($("#story-label").width() - $("#tab-indicator img").width()) / 2) + "px");
			// show new content
			$("#information p#org-text").add("#organization-container").fadeOut("fast", function(){
				$("#information p#about-text").fadeIn("fast");
				// reposition invisible support button
				supportBttnTop = parseInt($("#athlete-tab-menu").css("top")) + $("#athlete-tab-menu").height() - $(".support-bttn-container").height() - 10;
				$("#invisible-bttn").css({"top":supportBttnTop, "left":$("#athlete-tab-menu").position().left});
			});
		});
		$("#organization-tab").width($("#org-label").width());
		$("#organization-tab").mouseover(function(){
			if ($("#about-text").is(":visible")){
				$("#org-label").addClass("current");
			}
		});
		$("#organization-tab").mouseout(function(){
			if ($("#about-text").is(":visible")){
				$("#org-label").removeClass("current");
			}
		});
		$("#organization-tab").click(function(){
			// set current section
			currentTabSection = $("#org-text");
			currentTabSectionName = "organization";
			// add/remove current class
			$("#story-label").removeClass("current");
			$("#org-label").addClass("current");
			// position indicator
			$("#tab-indicator img").css("margin-left", Math.floor($("#org-label").position().left) + ($("#org-label").width() / 2) + "px");
			// show new content
			$("#information p#about-text").fadeOut("fast", function(){
				$("#information p#org-text").add("#organization-container").fadeIn("fast");
				// reposition invisible support button
				supportBttnTop = parseInt($("#athlete-tab-menu").css("top")) + $("#athlete-tab-menu").height() - $(".support-bttn-container").height() - 10;
				$("#invisible-bttn").css({"top":supportBttnTop, "left":$("#athlete-tab-menu").position().left});
			});
		});

		$('#story-label').click(function() {
			$('#story-tab').triggerHandler('click');
		});

		$('#org-label').click(function() {
			$('#organization-tab').triggerHandler('click');
		});
		
		// position scroller buttons
		var timeout, fps = 1000/60, speed = 2, extraspace = 30;
		var currentp = ($("#about-text").is(":visible")) ? $("#about-text") : $("#org-text");
		var containerHeight = (currentTabSectionName == "about") ? $("#information").height() : $("#information").height() - $("#organization-container").height();
		var containerY;
		
		var scrollerContainerX = ($("#scroller-container").position().left == 0) ? parseInt($("#scroller-container").css("margin-left")) : $("#scroller-container").position().left;
		
		$("#dn-bttn").css({
			"top":$(".scroller-dn").offset().top - $("#athletes-container").offset().top - 10,
			"left":$("#athlete-tab-menu").position().left + scrollerContainerX + 14
		});
		
		$("#dn-bttn").mouseover(function(){
			$(".scroller-dn").css("background-position", "0 -7px");
		});
		
		$("#dn-bttn").mouseout(function(){
			$(".scroller-dn").css("background-position", "0 0");
		});
		
		$("#dn-bttn").mousedown(function(){
			containerY = (currentTabSectionName == "about") ? 0 : 70;
			if (currentTabSection.height() > containerHeight){
				timeout = setInterval(function(){
					currentTabSection.css({"top":currentTabSection.position().top - speed});
					if (currentTabSection.position().top < (containerHeight - currentTabSection.height() - extraspace)){
						currentTabSection.css({"top":(containerHeight - currentTabSection.height() - extraspace)});
					}
				}, fps);
				//console.log('you done moused down the down button');
			}
		});
		
		$("#up-bttn").css({
			"top":$(".scroller-dn").offset().top - $("#athletes-container").offset().top - 10,
			"left":$("#athlete-tab-menu").position().left + scrollerContainerX
		});
		
		$("#up-bttn").mouseover(function(){
			$(".scroller-up").css("background-position", "0 -7px");
		});
		
		$("#up-bttn").mouseout(function(){
			$(".scroller-up").css("background-position", "0 0");
		});
		
		$("#up-bttn").mousedown(function(){
			containerY = (currentTabSectionName == "about") ? 0 : 70;
			timeout = setInterval(function(){
				currentTabSection.css({"top":currentTabSection.position().top + speed});
				if (currentTabSection.position().top > containerY){
					currentTabSection.css({"top":containerY});
				}
			}, fps);
			//console.log('you done moused down the up button');
		});
		
		$("#dn-bttn, #up-bttn").bind('mouseup mouseout', function() {
			clearInterval(timeout);
			//console.log('you done moused up/out');
		});
		
		// position the support button
		if (!hasSupportedAnAthlete) {
			$("#invisible-bttn").width($(".support-bttn-container").width() + 54);
		
			supportBttnTop = parseInt($("#athlete-tab-menu").css("top")) + $("#athlete-tab-menu").height() - $(".support-bttn-container").height() - 10;
		
			$("#invisible-bttn").css({"top":supportBttnTop, "left":$("#athlete-tab-menu").position().left});
			$("#invisible-bttn").mouseover(function(){
				$(".support-bttn-container span").addClass("text-shadow");
			});
			$("#invisible-bttn").mouseout(function(){
				$(".support-bttn-container span").removeClass("text-shadow");
			});
			$("#invisible-bttn").click(function(){
				
				$('#confirmation-modal h2').html("Ready to support "+athleteObj.firstName+" and award 25 ThankYou<sup>&reg;</sup> Points to "+causeObj.title+"?");

				// show a modal choooooser
				var overlayWidth = $(window).width();
				var overlayHeight = $(document).height();
				$("#black-overlay").css({"width":overlayWidth, "height":overlayHeight, opacity:.5});
				$("#black-overlay").fadeIn("fast");
				$("#confirmation-modal").css({display:'block'}).css({top:$(window).scrollTop()+100,left:($(window).width()-$("#confirmation-modal").width())/2});

				if(window.PIE) {
					$('#confirmation-modal .cta_style-04').each(function() {
						PIE.detach(this);
						PIE.attach(this);
					});
				}

			});
		} else {
			$("#invisible-bttn").hide();
		}
	}

	$(document).on('click', '[data-action="support-athlete"]', function() {
		$("#black-overlay,#confirmation-modal").hide();
		// support the athlete
		ui.tracking.track("Home_SupportTY_PV");
		$.ajax("/users/" + userid, {
			type: "PUT",
			data: {"id":userid, "athleteId":athleteObj.id, "token": co.model.csrfToken}
		}).done(function(results){
			window.ui.log("user support now set");
			getFlashMovie("kookie").setUserSupported();
		});
	
		// change to secondary page
		$.scrollTo($("#athletes-container").offset().top - 91, 400, {easing:"easeOutQuad", onAfter:function(){
			$("#full-image").add("#athlete-label-wrapper").add("#athlete-tab-menu").add("#quick-stats").add("#progress").add("#invisible-tab").add("#invisible-bttn").add("#next-bttn").add("#prev-bttn").add("#play-bttn").fadeOut("slow", function(){
				$("#athletes-container").animate({height:"661px"}, "slow", function(){
					$("#full-image2, #support-details").fadeIn("fast");
				});
			});
		}});
	});
	
	// mouse move handler for athlete's area ----
	$("#athletes-container").mousemove(function(e){
		//window.ui.log("x:" + (e.pageX - $("#main-container").offset().left) + ", y:" + (e.pageY - $(this).offset().top));
		if (startParallax){
			var container = $(this);
			
			var miny, maxy, minx, maxx, imgxspan, imgyspan, newx, newy;
			var pageminy = container.offset().top;
			var pagemaxy = container.offset().top + container.height();
			var pageheight = pagemaxy - pageminy;
			var mousey = e.pageY - container.offset().top;
			
			var pageminx = container.offset().left;
			var pagemaxx = container.offset().left + container.width();
			var pagewidth = pagemaxx - pageminx;
			var mousex = e.pageX - container.offset().left;
			
			// parallax athlete
			miny = layout.largeImagePos.minY;
			maxy = layout.largeImagePos.maxY;
			imgyspan = maxy - miny;
			
			minx = layout.largeImagePos.minX;
			maxx = layout.largeImagePos.maxX;
			imgxspan = maxx - minx;
			
			// newx = ((maxx - minx) / (pagemaxx - pageminx) * mousex) + minx; // this line works in the reverse order BAZINGA!!!!
			// newy = ((maxy - miny) / (pagemaxy - pageminy) * mousey) + miny;
			newx = imgxspan - ((mousex / pagewidth) * imgxspan) + minx;
			newy = imgyspan - ((mousey / pageheight) * imgyspan) + miny;
			$("#full-image").css({"top":newy, "left":newx});
			
			// parallax quick stats
			miny = layout.quickStatsPos.minY;
			maxy = layout.quickStatsPos.maxY;
			imgyspan = maxy - miny;
			
			minx = layout.quickStatsPos.minX;
			maxx = layout.quickStatsPos.maxX;
			imgxspan = maxx - minx;
			
			newx = imgxspan - ((mousex / pagewidth) * imgxspan) + minx;
			newy = imgyspan - ((mousey / pageheight) * imgyspan) + miny;
			$("#quick-stats").css({"top":newy, "left":newx});
			
			// parallax progress
			miny = layout.progressPos.minY;
			maxy = layout.progressPos.maxY;
			imgyspan = maxy - miny;
			
			minx = layout.progressPos.minX;
			maxx = layout.progressPos.maxX;
			imgxspan = maxx - minx;
			
			newx = imgxspan - ((mousex / pagewidth) * imgxspan) + minx;
			newy = imgyspan - ((mousey / pageheight) * imgyspan) + miny;
			$("#progress").css({"top":newy, "left":newx});
		}
	});
	
	// show tooltip on donate links ----
	$(".tooltip-link").live("mouseover", function(){
		var linkx;
		
		if ($(this).hasClass("donate-usoc")){
			$(".tooltip-top").css("background-image", "url(../images/tooltip-topl.png)");
			$("#usoc-link").show();
			$("#thankyou-link").hide();
			linkx = $(this).offset().left - $("#main-container").offset().left;
		} else {
			$(".tooltip-top").css("background-image", "url(../images/tooltip-topr.png)");
			$("#usoc-link").hide();
			$("#thankyou-link").show();
			linkx = $(this).offset().left - $("#main-container").offset().left - ($("#tooltip").width() - $(this).width());
		}
		
		var linky = $(this).offset().top - $("#athletes-container").offset().top;
		var linkh = $(this).height();

		$("#tooltip").css({
			"top": linky + linkh + 10,
			"left": linkx
		});
		
		$("#tooltip").show();
	});
	
	$(".tooltip-link").live("mouseout", function(){
		$("#tooltip").hide();
	});
	
	// continue button handler ----
	$("#continue").click(function(){
		$.scrollTo($("#athletes").offset().top - 91, 1000, {easing:"easeOutQuad"});
	});
	
	// menu handler ----
	$("li.clickable2").click(function(){
		var index;
		var whereto = $(this).attr("rel");
		var destY = Math.ceil($("#" + whereto).offset().top);
		
		$.scrollTo(Math.max(0,destY - 91), 1000, {easing:"easeOutQuad"});
		
		switch(whereto){
			case "video": 			index = 0; break;
			case "about": 			index = 1; break;
			case "athletes": 		index = 2; break;
			case "enter-to-win": 	index = 3; break;
			case "more-ways": 		index = 4; break;
		}
		
		moveMenuIndicator(index);
		//(whereto != "menu") ? $.scrollTo($("#" + whereto), 1000, {easing:"easeOutQuad"}) : $.scrollTo(0, 1000, {easing:"easeOutQuad"});
	});
	
	// everest ----
	$('#more-ways').appear(function(){
		$("#everest-img").empty().append('<img src="https://pixel.everesttech.net/2561/t?ev_FBConvert=<FBConvert>&ev_transid=<transid>" width="1" height="1"/>');
	});
	
	$('#thankyou').appear(function(){
		$("#everest-img").empty().append('<img src="https://pixel.everesttech.net/2561/t?ev_FBConvert=<FBConvert>&ev_transid=<transid>" width="1" height="1"/>');
	});
	
	// toggle more details section in Support section ----
	$("#bttn-more-details").click(function(){
		($("#more-details").is(":visible")) ? $("#bttn-more-details").html("See details") : $("#bttn-more-details").html("Hide details");
		$("#more-details").toggle("slow");
	});
	
	// set all thumbnails to the fade image ----
	function resetAllThumbnails() {
		$(".athlete-tn").find("img").each(function(){
			var src = $(this).attr("src");
			var newsrc = src.replace("filled", "fade");
			
			if ($(this).attr("src") != newsrc) {
				$(this).attr("src", newsrc);
			}
		});
	}
	
	// change the current athlete's thumbnail to the fill image ----
	function selectThumbnail(athlete) {
		var src = athlete.attr("src");
		var newsrc = src.replace("fade", "filled");
		athlete.attr("src", newsrc);
	}
	
	// animate the athlete menu indicator ----
	function moveAthleteMenuIndicator(xpos){
		$("#nav-container").animate({backgroundPosition: xpos + 'px 0'});
	}
	
	// load in progress data ----
	function loadProgressData(points, goal){
		// get the dollar amount
		var dollars = Math.floor(points / 100);
		// get the percentage based on total goal and current points
		var percent = Math.ceil((points * 100) / goal);
		var visualPercent = (percent > 100) ? 100 : percent;
		// update the points field with the amount of points
		$("#points-container .points").html(ui.commifyNumber(points));
		// update the dollars field with the amount of dollars
		$("#points-container .dollars").html("($" + ui.commifyNumber(dollars) + ")");
		// animate the progress bar	
		$("#percent-graphic-container .bar").animate({top:69 - ((69/100) * visualPercent)},{duration: 1000});
		// update the percent field with the percentage
		$("#percent-graphic-container .percent p").html(percent);
	}
	
	// allow modal to not be closed from promo pop up
	// commented out, we don't understand the purpose - 18 May 2012 by Leisl S and Mike A
	/*$("#enter-promo-modal").click(function(e){
      	e.stopPropagation();
	});*/
	
	// hide the modals and overlay ----
	$(document).on('click', '#black-overlay,#enter-promo-modal .close-bttn,.close-bttn2,#video-close-bttn,#confirmation-modal .close-bttn', function(event){
		$("#black-overlay,#enter-promo-modal,#rules-overlay,#video-player-new,#thankyou-modal,#confirmation-modal").hide();
		$("#video-player").add("#ios-player").remove();
		$("#video-player-container").prepend('<div id="video-player"></div><div id="ios-player"></div>');
		
		if ($(window).scrollTop() < 100){
			$("#logo").fadeIn("slow");
		}

		event.stopPropagation();
	});
	
	// click handler for promo code submit button

	$(document).on('submit', "#promo-code-form", function(e) {
		$("#bttn-submit-promocode").triggerHandler('click');
		return false;
	});
	
	$("#bttn-submit-promocode").click(function(e){
		e.stopPropagation();
		
		$("#promo-code").removeClass("requiredText");
		$("#promo-code-form label").hide();
		
		if ($.trim($("#promo-code").val()) != "") {
			if ($("#promo-code").val() != undefined){
				$("#promo-code").removeClass("requiredText");
				$("#promo-code-form label").hide();
				
				var id = userid;
				var promo_code = $.trim($("#promo-code").val());
				var athleteID = athleteObj.id;
				var token = co.model.csrfToken;
				
				$.ajax('/users/' + id, {
					type: 'PUT',
					data: {"id":id, "promoCode":promo_code, "athleteId":athleteID, "token": co.model.csrfToken},
					success:function(){
						ui.tracking.track("PromoCode_TY_PV");
						window.ui.log("promo code redeemed OK");
						var winw = $(window).width();
						var winh = $(window).height();
						// position thank you modal
						$("#thankyou-modal").css({
							"top": $(window).scrollTop() + (winh / 2) - $("#thankyou-modal").height() / 2,
							"left": (winw - $("#thankyou-modal").width()) / 2
						});
							
						$("#enter-promo-modal").fadeOut("fast");
						$("#thankyou-modal").fadeIn("fast");
						//
						$("#enter-promo-modal").fadeOut("fast");
						$("#thankyou-modal").fadeIn("fast");
					},
					error:function(){
						$("#promo-code").addClass("requiredText");
						$("#promo-code-form label").show();
					}
					/*
					complete: function(data){
						window.ui.log("ID: " + data.id);				
						if (typeof data.id !== undefined){
							ui.tracking.track("PromoCode_TY_PV");
							window.ui.log("promo code redeemed OK");
							var winw = $(window).width();
							var winh = $(window).height();
							// position thank you modal
							$("#thankyou-modal").css({
								"top": $(window).scrollTop() + (winh / 2) - $("#thankyou-modal").height() / 2,
								"left": (winw - $("#thankyou-modal").width()) / 2
							});
							
							$("#enter-promo-modal").fadeOut("fast");
							$("#thankyou-modal").fadeIn("fast");
							//
							$("#enter-promo-modal").fadeOut("fast");
							$("#thankyou-modal").fadeIn("fast");
						} else {
							$("#promo-code").addClass("requiredText");
							$("#promo-code-form label").show();	
						}
					}*/
				});
			}
		} else {
			$("#promo-code").addClass("requiredText");
			$("#promo-code-form label").show();
		}
	});
	
	// sweepstakes functionality ----
	$("#sweepstakes-form input").focus(function(){
		$(document).keypress(function(e) {
    		if(e.keyCode == 13) {
    	    	$("#submit-button-container a").trigger("click");
    		}
		});
	});
	
	$("#submit-button-container a").click(function(e){
		e.preventDefault();
		
		if (validateForm()){
			$.ajax({
				//url: '/sweepstakes', 
				url: 'https://' + document.location.host + '/sweepstakes',
				data: {
					firstName:$.trim($("#first-name").val()),
					lastName:$.trim($("#last-name").val()),
					zip:$.trim($("#zip-code").val()),
					email:$.trim($("#email").val()),
					phone:$.trim($("#phone-number").val()),
					over18:$("#over18").val()==="on"?1:0,
					agreedToTerms:$("#agreedToTerms").val()==="on"?1:0,
					optin:$("#optin").val()==="on"?1:0,
					token:co.model.csrfToken
				}, 
				success: function(data){
					if (data.success) {
						$("#form-section").fadeOut("fast");
						$("#thankyou").fadeIn("fast");
						ui.tracking.track("Home_SweepsTY_PV");
					} else {
						window.ui.log("FAILED");
					}
				},
				type: 'POST',
				dataType: "json"
			});
		} else {
			window.ui.log("form field(s) has error");
		}
	});
	
	// first name field reset on blur if validated ----
	$("#first-name").blur(function(){
		if(/[a-zA-Z ]+/.test($.trim($(this).val()))) {
			$("#label-firstname").removeClass("requiredLabel");
			$("#first-name").removeClass("requiredText");
		}
	});
	
	// last name field reset on blur if validated ----
	$("#last-name").blur(function(){
		if(/[a-zA-Z ]+/.test($.trim($(this).val()))) {
			$("#label-lastname").removeClass("requiredLabel");
			$("#last-name").removeClass("requiredText");
		}
	});
	
	// zip code field reset on blur if validated ----
	$("#zip-code").blur(function(){
		if(/^\d{5}(-\d{4})?$/.test($.trim($(this).val()))) {
			$("#label-zipcode").removeClass("requiredLabel");
			$("#zip-code").removeClass("requiredText");
		}
	});
	
	// email field reset on blur if validated ----
	$("#email").blur(function(){
		if(/^[0-9a-zA-Z]([-.\w]*[0-9a-zA-Z_+])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9}$/.test($.trim($(this).val()))) {
			$("#label-email").removeClass("requiredLabel");
			$("#email").removeClass("requiredText");
		}
	});
	
	// phone number field reset on blur if validated ----
	$("#phone-number").blur(function(){
		if(/^[2-9]\d{2}[- ]?\d{3}[- ]?\d{4}$/.test($.trim($(this).val())) || !($.trim($(this).val()))) {
			$("#label-phone").removeClass("requiredLabel");
			$("#phone-number").removeClass("requiredText");
		}
	});
	
	// over 18 checkbox reset on blur if validated ----
	$("#over18").on("click", function(){
		if ($(this).is(":checked")) {
			$("#label-over18").removeClass("requiredLabel");
		}
	});
	
	// agreed to terms reset on blur if validated ----
	$("#agreedToTerms").on("click", function(){
		if ($(this).is(":checked")) {
			$("#label-agreedToTerms").removeClass("requiredLabel");
		}
	});
	
	// validate the sweepstakes form ----
	function validateForm(){
		var results 		= true;
		
		var labelFirstName 	= $("#label-firstname");
		var inputFirstName 	= $("#first-name");
		var firstName 		= $.trim(inputFirstName.val());
		
		var labelLastName 	= $("#label-lastname");
		var inputLastName 	= $("#last-name");
		var lastName 		= $.trim(inputLastName.val());
		
		var labelZipCode	= $("#label-zipcode");
		var inputZipCode	= $("#zip-code");
		var zipCode			= $.trim(inputZipCode.val());
		
		var labelEmail		= $("#label-email");
		var inputEmail		= $("#email");
		var email			= $.trim(inputEmail.val());
		
		var labelPhone		= $("#label-phone");
		var inputPhone		= $("#phone-number");
		var phoneNumber		= $.trim(inputPhone.val());
		
		var labelOver18		= $("#label-over18"); 
		var over18			= $("#over18:checked").val();
		
		var labelAgree		= $("#label-agreedToTerms");
		var agreeToTerms	= $("#agreedToTerms:checked").val();
		
		// validate first name
		if (firstName == "" || firstName == undefined) {
			results = false;
			labelFirstName.addClass("requiredLabel");
			inputFirstName.addClass("requiredText");
		} else if(!/[a-zA-Z ]+/.test(firstName)) {
			results = false;
			labelFirstName.addClass("requiredLabel");
			inputFirstName.addClass("requiredText");
		}
		
		// validate last name
		if (lastName == "" || lastName == undefined) {
			results = false;
			labelLastName.addClass("requiredLabel");
			inputLastName.addClass("requiredText");
		} else if(!/[a-zA-Z ]+/.test(firstName)) {
			results = false;
			labelLastName.addClass("requiredLabel");
			inputLastName.addClass("requiredText");
		}
		
		// validate zip code
		if (zipCode == "" || zipCode == undefined) {
			results = false;
			labelZipCode.addClass("requiredLabel");
			inputZipCode.addClass("requiredText");
		} else if(!/^\d{5}(-\d{4})?$/.test(zipCode)){
			results = false;
			labelZipCode.addClass("requiredLabel");
			inputZipCode.addClass("requiredText");
		}
		
		// validate email address
		if (email == "" || email == undefined) {
			results = false;
			labelEmail.addClass("requiredLabel");
			inputEmail.addClass("requiredText");
		} else if(!/^[0-9a-zA-Z]([-.\w]*[0-9a-zA-Z_+])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9}$/.test(email)){
			results = false;
			labelEmail.addClass("requiredLabel");
			inputEmail.addClass("requiredText");
		}
		
		// validate phone number
		if (phoneNumber != ""){
			if (!/^[2-9]\d{2}[- ]?\d{3}[- ]?\d{4}$/.test(phoneNumber)) {
				labelPhone.addClass("requiredLabel");
				inputPhone.addClass("requiredText");
			}
		}
		
		// validate checkboxes
		if (!over18){
			results = false;
			labelOver18.addClass("requiredLabel");
		}
		
		if (!agreeToTerms){
			results = false;
			labelAgree.addClass("requiredLabel");
		}
		
		return results;
	}
	
	// fade in points graphic one arrow at a time ----
	function fadeInPointsArrow(){
		/*
		var points1 = $("#points1");
		var points2 = $("#points2");
		var points3 = $("#points3");
		var facebook = $("#support-facebook");
		var thankyou = $("#thankyou-wrapper");
		var donate = $("#support-donate");
		
		if (!pointsFadeInit) {
			pointsFadeInit = true;
			points1.delay(500).fadeIn("slow", function(){
				points2.fadeIn("slow", function(){
					points3.fadeIn("slow");
				});
			});
		
			facebook.delay(500).animate({opacity:1}, "slow", "linear", function(){
				donate.animate({opacity:1}, "slow", "linear", function(){
					thankyou.animate({opacity:1}, "slow", "linear");
				});
			});
		}
		*/
	}
	
	// modal window handler for terms and rules ----
	$(".sweeps-rules").click(function(e){
		e.preventDefault();
		// get width and height for overlay
		var overlayWidth = $(window).width();
		var overlayHeight = $(document).height();
		// position overlay
		$("#black-overlay").css({
			"width":overlayWidth, 
			"height":overlayHeight,
			opacity:.5
		});
		// fade in overlay
		$("#black-overlay").fadeIn("fast");
		// get width and height of visible area
		var winw = $(window).width();
		var winh = $(window).height();
		//
		$("#rules-overlay").css({
			"top": $(window).scrollTop() + (winh - $("#rules-overlay").height()) / 2,
			"left": (winw - $("#rules-overlay").width()) / 2
		});
		//get content
		var page = ($(this).attr("href") == "terms-conditions") ? "terms.php" : "rules.php";
		$(".rules-overlay-body .content").load(page, function(){
			$("#rules-overlay").fadeIn("fast");
		});
	});
	
	// window resize handler ----
	$(window).resize(onResize);
	function onResize(){
		menux = Math.ceil(($(window).width() - menu.width()) / 2);
		positionMenuIndicator();
	}
	
	// get the current section of the page ----
	function getCurrentSection(){
		var currentPos = $(window).scrollTop();
		var sectionOffset = 200;
		var sectionAbout = $("#about").offset().top - sectionOffset; 
		var sectionAthletes = $("#athletes").offset().top - sectionOffset;
		var sectionWin = $("#enter-to-win").offset().top - sectionOffset;
		var sectionSupport = $("#more-ways").offset().top - sectionOffset;
		var scrolltop = $(window).scrollTop();
		
		if (scrolltop < sectionAbout){
			currentSection = 0;
		} else if (scrolltop > sectionAbout && scrolltop < sectionAthletes) {
			currentSection = 1;
		} else if (scrolltop > sectionAthletes && scrolltop < sectionWin){
			currentSection = 2;
		} else if (scrolltop > sectionWin && scrolltop < sectionSupport) {
			currentSection = 3;
		} else if (scrolltop > sectionSupport) {
			currentSection = 4;
		}
		
		return currentSection;
	}
	
	// scroll event hander ----
	$(window).scroll(function(){
		getCurrentSection();
		hideLogo();
	});
	
	// triggers when scrolling stops ----
	$(window).bind("scrollstop", function(){
		getCurrentSection();
		switch(currentSection) {
			case 0: moveMenuIndicator(0); break;
			case 1: moveMenuIndicator(1); break;
			case 2: moveMenuIndicator(2); break;
			case 3: moveMenuIndicator(3); break;
			case 4: moveMenuIndicator(4); fadeInPointsArrow(); break;
		}
	});
	
	
	// fix for non-html5 browser that doesn't support placeholder text
	$('[placeholder]').focus(function() {
  		var input = $(this);
  		if (input.val() == input.attr('placeholder')) {
   			input.val('');
    		input.removeClass('placeholder');
  		}
	}).blur(function() {
  		var input = $(this);
  		if (input.val() == '' || input.val() == input.attr('placeholder')) {
    		input.addClass('placeholder');
    		input.val(input.attr('placeholder'));
  		}
	}).blur();
	
	// prevent placeholder text from being submitted as possible values 
	$('[placeholder]').parents('form').submit(function() {
  		$(this).find('[placeholder]').each(function() {
    		var input = $(this);
    		if (input.val() == input.attr('placeholder')) {
      			input.val('');
    		}
  		})
	});
	
	
	// initialize ----
	init();
});
