
define(["jquery"], function ($) {
	
	/**
	 * jQuery Cookie plugin
	 *
	 * Copyright (c) 2010 Klaus Hartl (stilbuero.de)
	 * Dual licensed under the MIT and GPL licenses:
	 * http://www.opensource.org/licenses/mit-license.php
	 * http://www.gnu.org/licenses/gpl.html
	 *
	 */
	jQuery.cookie=function(e,b,a){if(1<arguments.length&&"[object Object]"!==""+b){a=jQuery.extend({},a);if(null===b||void 0===b)a.expires=-1;if("number"===typeof a.expires){var d=a.expires,c=a.expires=new Date;c.setDate(c.getDate()+d)}b=""+b;return document.cookie=[encodeURIComponent(e),"=",a.raw?b:encodeURIComponent(b),a.expires?"; expires="+a.expires.toUTCString():"",a.path?"; path="+a.path:"",a.domain?"; domain="+a.domain:"",a.secure?"; secure":""].join("")}a=b||{};c=a.raw?function(a){return a}:decodeURIComponent;
	return(d=RegExp("(?:^|; )"+encodeURIComponent(e)+"=([^;]*)").exec(document.cookie))?c(d[1]):null};

	/*
	 * jQuery Easing v1.3 - http://gsgd.co.uk/sandbox/jquery/easing/
	 *
	 * Uses the built in easing capabilities added In jQuery 1.1
	 * to offer multiple easing options
	 *
	 * TERMS OF USE - jQuery Easing
	 * 
	 * Open source under the BSD License. 
	 * 
	 * Copyright © 2008 George McGinley Smith
	 * All rights reserved.
	 * 
	 * Redistribution and use in source and binary forms, with or without modification, 
	 * are permitted provided that the following conditions are met:
	 * 
	 * Redistributions of source code must retain the above copyright notice, this list of 
	 * conditions and the following disclaimer.
	 * Redistributions in binary form must reproduce the above copyright notice, this list 
	 * of conditions and the following disclaimer in the documentation and/or other materials 
	 * provided with the distribution.
	 * 
	 * Neither the name of the author nor the names of contributors may be used to endorse 
	 * or promote products derived from this software without specific prior written permission.
	 * 
	 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
	 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
	 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
	 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
	 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
	 *  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
	 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
	 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
	 * OF THE POSSIBILITY OF SUCH DAMAGE. 
	 *
	*/
	jQuery.easing.jswing=jQuery.easing.swing;jQuery.extend(jQuery.easing,{def:"easeOutQuad",swing:function(e,f,a,h,g){return jQuery.easing[jQuery.easing.def](e,f,a,h,g)},easeInQuad:function(e,f,a,h,g){return h*(f/=g)*f+a},easeOutQuad:function(e,f,a,h,g){return -h*(f/=g)*(f-2)+a},easeInOutQuad:function(e,f,a,h,g){if((f/=g/2)<1){return h/2*f*f+a}return -h/2*((--f)*(f-2)-1)+a},easeInCubic:function(e,f,a,h,g){return h*(f/=g)*f*f+a},easeOutCubic:function(e,f,a,h,g){return h*((f=f/g-1)*f*f+1)+a},easeInOutCubic:function(e,f,a,h,g){if((f/=g/2)<1){return h/2*f*f*f+a}return h/2*((f-=2)*f*f+2)+a},easeInQuart:function(e,f,a,h,g){return h*(f/=g)*f*f*f+a},easeOutQuart:function(e,f,a,h,g){return -h*((f=f/g-1)*f*f*f-1)+a},easeInOutQuart:function(e,f,a,h,g){if((f/=g/2)<1){return h/2*f*f*f*f+a}return -h/2*((f-=2)*f*f*f-2)+a},easeInQuint:function(e,f,a,h,g){return h*(f/=g)*f*f*f*f+a},easeOutQuint:function(e,f,a,h,g){return h*((f=f/g-1)*f*f*f*f+1)+a},easeInOutQuint:function(e,f,a,h,g){if((f/=g/2)<1){return h/2*f*f*f*f*f+a}return h/2*((f-=2)*f*f*f*f+2)+a},easeInSine:function(e,f,a,h,g){return -h*Math.cos(f/g*(Math.PI/2))+h+a},easeOutSine:function(e,f,a,h,g){return h*Math.sin(f/g*(Math.PI/2))+a},easeInOutSine:function(e,f,a,h,g){return -h/2*(Math.cos(Math.PI*f/g)-1)+a},easeInExpo:function(e,f,a,h,g){return(f==0)?a:h*Math.pow(2,10*(f/g-1))+a},easeOutExpo:function(e,f,a,h,g){return(f==g)?a+h:h*(-Math.pow(2,-10*f/g)+1)+a},easeInOutExpo:function(e,f,a,h,g){if(f==0){return a}if(f==g){return a+h}if((f/=g/2)<1){return h/2*Math.pow(2,10*(f-1))+a}return h/2*(-Math.pow(2,-10*--f)+2)+a},easeInCirc:function(e,f,a,h,g){return -h*(Math.sqrt(1-(f/=g)*f)-1)+a},easeOutCirc:function(e,f,a,h,g){return h*Math.sqrt(1-(f=f/g-1)*f)+a},easeInOutCirc:function(e,f,a,h,g){if((f/=g/2)<1){return -h/2*(Math.sqrt(1-f*f)-1)+a}return h/2*(Math.sqrt(1-(f-=2)*f)+1)+a},easeInElastic:function(f,h,e,l,k){var i=1.70158;var j=0;var g=l;if(h==0){return e}if((h/=k)==1){return e+l}if(!j){j=k*0.3}if(g<Math.abs(l)){g=l;var i=j/4}else{var i=j/(2*Math.PI)*Math.asin(l/g)}return -(g*Math.pow(2,10*(h-=1))*Math.sin((h*k-i)*(2*Math.PI)/j))+e},easeOutElastic:function(f,h,e,l,k){var i=1.70158;var j=0;var g=l;if(h==0){return e}if((h/=k)==1){return e+l}if(!j){j=k*0.3}if(g<Math.abs(l)){g=l;var i=j/4}else{var i=j/(2*Math.PI)*Math.asin(l/g)}return g*Math.pow(2,-10*h)*Math.sin((h*k-i)*(2*Math.PI)/j)+l+e},easeInOutElastic:function(f,h,e,l,k){var i=1.70158;var j=0;var g=l;if(h==0){return e}if((h/=k/2)==2){return e+l}if(!j){j=k*(0.3*1.5)}if(g<Math.abs(l)){g=l;var i=j/4}else{var i=j/(2*Math.PI)*Math.asin(l/g)}if(h<1){return -0.5*(g*Math.pow(2,10*(h-=1))*Math.sin((h*k-i)*(2*Math.PI)/j))+e}return g*Math.pow(2,-10*(h-=1))*Math.sin((h*k-i)*(2*Math.PI)/j)*0.5+l+e},easeInBack:function(e,f,a,i,h,g){if(g==undefined){g=1.70158}return i*(f/=h)*f*((g+1)*f-g)+a},easeOutBack:function(e,f,a,i,h,g){if(g==undefined){g=1.70158}return i*((f=f/h-1)*f*((g+1)*f+g)+1)+a},easeInOutBack:function(e,f,a,i,h,g){if(g==undefined){g=1.70158}if((f/=h/2)<1){return i/2*(f*f*(((g*=(1.525))+1)*f-g))+a}return i/2*((f-=2)*f*(((g*=(1.525))+1)*f+g)+2)+a},easeInBounce:function(e,f,a,h,g){return h-jQuery.easing.easeOutBounce(e,g-f,0,h,g)+a},easeOutBounce:function(e,f,a,h,g){if((f/=g)<(1/2.75)){return h*(7.5625*f*f)+a}else{if(f<(2/2.75)){return h*(7.5625*(f-=(1.5/2.75))*f+0.75)+a}else{if(f<(2.5/2.75)){return h*(7.5625*(f-=(2.25/2.75))*f+0.9375)+a}else{return h*(7.5625*(f-=(2.625/2.75))*f+0.984375)+a}}}},easeInOutBounce:function(e,f,a,h,g){if(f<g/2){return jQuery.easing.easeInBounce(e,f*2,0,h,g)*0.5+a}return jQuery.easing.easeOutBounce(e,f*2-g,0,h,g)*0.5+h*0.5+a}});


	// custom jquery plugins : circle graph animation and gradient title text
	(function ($) {
		var methods = {
			init: function (options) {
				return this.each(function () {
					if ($('html.ie6,html.ie7').length == 0) {
						if (options.type == "arc" && (this.canvasToolbox === undefined || this.canvasToolbox === null)) {
							this.canvasToolbox = {
								type: 'arc'
							};
							this.paper = Raphael(this, $(this).width(), $(this).height());
							this.arcParams = {
								cx: parseInt($(this).width() / 2, 10),
								cy: parseInt($(this).height() / 2, 10),
								width: parseInt($(this).attr('arc-width'), 10),
								color: $(this).css('color')
							};
							this.arcParams.r = this.arcParams.cx - parseInt(this.arcParams.width / 2, 10);
							this.paper.customAttributes.arc = function (xloc, yloc, value, total, R) {
								var alpha = 360 / total * value,
									a = (90 - alpha) * Math.PI / 180,
									x = xloc + R * Math.cos(a),
									y = yloc - R * Math.sin(a),
									path;
								if (total == value) {
									path = [
										["M", xloc, yloc - R],
										["A", R, R, 0, 1, 1, xloc - 0.01, yloc - R]
									];
								} else {
									path = [
										["M", xloc, yloc - R],
										["A", R, R, 0, +(alpha > 180), 1, x, y]
									];
								}
								return {
									path: path
								};
							};
							this.arc = this.paper.path().attr({
								"stroke": this.arcParams.color,
								"stroke-width": this.arcParams.width,
								arc: [this.arcParams.cx, this.arcParams.cy, 0, 100, this.arcParams.r]
							});
						}
						if (options.type == "gradient-title" && (this.canvasToolbox === undefined || this.canvasToolbox === null)) {
							this.canvasToolbox = {
								fontSize: (($(this).is('[data-title-size]')) ? parseInt($(this).attr('data-title-size')) : parseInt($(this).css('font-size'))),
								type: 'gradient-title',
								lines: new Array(),
								dy: 0,
								attrs: {
									"fill": "0-#19aee5-#004685:75-#004685",
									"font-family": "regular",
									"text-anchor": "start",
									"text-transform": "uppercase",
									"text-align": "center"
								}
							};
							if (($.browser.mozilla || $.browser.msie) && $(this).is('[data-alt-title-size]')) {
								this.canvasToolbox.fontSize = parseInt($(this).attr('data-alt-title-size'));
							}
							if (typeof (FB) !== 'undefined') {
								this.canvasToolbox.dy = ($(this).height() / 2);
							}
							this.canvasToolbox.attrs["font-size"] = this.canvasToolbox.fontSize + "px";
							var _lines = $(this).html().replace(/(<br>)|(<br \/>)|(<BR>)|(<BR \/>)/g, "|");
							_lines = _lines.replace(/&amp;/g, "&");
							this.canvasToolbox.lines = _lines.replace(/(<sup>)|(<\/sup>)|(<SUP>)|(<\/SUP>)/g, "").split("|");
							$(this).wrapInner('<span class="inner-text" />');
							this.paper = Raphael(this, parseInt($(this).width(), 10), parseInt($(this).height(), 10));
							$('.inner-text', this).css({
								display: 'none'
							});
							if (this.canvasToolbox.lines.length == 1) {
								var _text = this.paper.text(0, this.canvasToolbox.dy).attr(this.canvasToolbox.attrs);
								_text.attr('text', this.canvasToolbox.lines[0].toString().toUpperCase());
								if ($('html.ie8').length == 0) {
									this.paper.setSize(_text.getBBox().width, parseInt($(this).height(), 10));
								}
							} else {
								var _self = this;
								$.each(this.canvasToolbox.lines, function (iter, line) {
									var _dy = ((typeof (FB) !== 'undefined') ? (_self.canvasToolbox.fontSize / 2) : 0) + ((_self.canvasToolbox.fontSize * .9) * iter);
									_self.paper.text(0, _dy, line.toString().toUpperCase()).attr(_self.canvasToolbox.attrs);
								});
							}
							$(this).css({
								visibility: 'visible'
							});
						}
					}
				});
			},
			animateIn: function () {
				return this.each(function () {
					if ($('html.ie6,html.ie7').length == 0) {
						var _arc = parseInt($(this).attr('arc-percentage'), 10);
						if (_arc >= 0 && _arc <= 100) {
							this.arc.animate({
								arc: [this.arcParams.cx, this.arcParams.cy, _arc, 100, this.arcParams.r]
							}, 1500, ">");
						}
					}
				});
			}
		};
		$.fn.canvasToolbox = function (method) {
			if (methods[method]) {
				return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
			} else if (typeof method === 'object' || !method) {
				return methods.init.apply(this, arguments);
			} else {
				$.error('Method ' + method + ' does not exist on jQuery.canvasToolbox');
			}
		};
	})(jQuery);

	/*
	 * jQuery.appear
	 * http://code.google.com/p/jquery-appear/
	 *
	 * Copyright (c) 2009 Michael Hixson
	 * Licensed under the MIT license (http://www.opensource.org/licenses/mit-license.php)
	*/
	(function($){$.fn.appear=function(f,o){var s=$.extend({one:true},o);return this.each(function(){var t=$(this);t.appeared=false;if(!f){t.trigger('appear',s.data);return;}var w=$(window);var c=function(){if(!t.is(':visible')){t.appeared=false;return;}var a=w.scrollLeft();var b=w.scrollTop();var o=t.offset();var x=o.left;var y=o.top;if(y+t.height()>=b&&y<=b+w.height()&&x+t.width()>=a&&x<=a+w.width()){if(!t.appeared)t.trigger('appear',s.data);}else{t.appeared=false;}};var m=function(){t.appeared=true;if(s.one){w.unbind('scroll',c);var i=$.inArray(c,$.fn.appear.checks);if(i>=0)$.fn.appear.checks.splice(i,1);}f.apply(this,arguments);};if(s.one)t.one('appear',s.data,m);else t.bind('appear',s.data,m);w.scroll(c);$.fn.appear.checks.push(c);(c)();});};$.extend($.fn.appear,{checks:[],timeout:null,checkAll:function(){var l=$.fn.appear.checks.length;if(l>0)while(l--)($.fn.appear.checks[l])();},run:function(){if($.fn.appear.timeout)clearTimeout($.fn.appear.timeout);$.fn.appear.timeout=setTimeout($.fn.appear.checkAll,20);}});$.each(['append','prepend','after','before','attr','removeAttr','addClass','removeClass','toggleClass','remove','css','show','hide'],function(i,n){var u=$.fn[n];if(u){$.fn[n]=function(){var r=u.apply(this,arguments);$.fn.appear.run();return r;}}});})(jQuery);
	
	/**
	 * @author Alexander Farkas
	 * v. 1.22
	 */
	(function($) {
		if(!document.defaultView || !document.defaultView.getComputedStyle){ // IE6-IE8
			var oldCurCSS = $.curCSS;
			$.curCSS = function(elem, name, force){
				if(name === 'background-position'){
					name = 'backgroundPosition';
				}
				if(name !== 'backgroundPosition' || !elem.currentStyle || elem.currentStyle[ name ]){
					return oldCurCSS.apply(this, arguments);
				}
				var style = elem.style;
				if ( !force && style && style[ name ] ){
					return style[ name ];
				}
				return oldCurCSS(elem, 'backgroundPositionX', force) +' '+ oldCurCSS(elem, 'backgroundPositionY', force);
			};
		}
		
		var oldAnim = $.fn.animate;
		$.fn.animate = function(prop){
			if('background-position' in prop){
				prop.backgroundPosition = prop['background-position'];
				delete prop['background-position'];
			}
			if('backgroundPosition' in prop){
				prop.backgroundPosition = '('+ prop.backgroundPosition;
			}
			return oldAnim.apply(this, arguments);
		};
		
		function toArray(strg){
			strg = strg.replace(/left|top/g,'0px');
			strg = strg.replace(/right|bottom/g,'100%');
			strg = strg.replace(/([0-9\.]+)(\s|\)|$)/g,"$1px$2");
			var res = strg.match(/(-?[0-9\.]+)(px|\%|em|pt)\s(-?[0-9\.]+)(px|\%|em|pt)/);
			return [parseFloat(res[1],10),res[2],parseFloat(res[3],10),res[4]];
		}
		
		$.fx.step. backgroundPosition = function(fx) {
			if (!fx.bgPosReady) {
				var start = $.curCSS(fx.elem,'backgroundPosition');
				if(!start){//FF2 no inline-style fallback
					start = '0px 0px';
				}
				
				start = toArray(start);
				fx.start = [start[0],start[2]];
				var end = toArray(fx.end);
				fx.end = [end[0],end[2]];
				
				fx.unit = [end[1],end[3]];
				fx.bgPosReady = true;
			}
			//return;
			var nowPosX = [];
			nowPosX[0] = ((fx.end[0] - fx.start[0]) * fx.pos) + fx.start[0] + fx.unit[0];
			nowPosX[1] = ((fx.end[1] - fx.start[1]) * fx.pos) + fx.start[1] + fx.unit[1];           
			fx.elem.style.backgroundPosition = nowPosX[0]+' '+nowPosX[1];

		};
	})(jQuery);
	
	// scrollbarevents
	(function(){
	 
			var special = jQuery.event.special,
					uid1 = 'D' + (+new Date()),
					uid2 = 'D' + (+new Date() + 1);
	 
			special.scrollstart = {
					setup: function() {
	 
							var timer,
									handler =  function(evt) {
	 
											var _self = this,
													_args = arguments;
	 
											if (timer) {
													clearTimeout(timer);
											} else {
													evt.type = 'scrollstart';
													jQuery.event.handle.apply(_self, _args);
											}
	 
											timer = setTimeout( function(){
													timer = null;
											}, special.scrollstop.latency);
	 
									};
	 
							jQuery(this).bind('scroll', handler).data(uid1, handler);
	 
					},
					teardown: function(){
							jQuery(this).unbind( 'scroll', jQuery(this).data(uid1) );
					}
			};
	 
			special.scrollstop = {
					latency: 300,
					setup: function() {
	 
							var timer,
											handler = function(evt) {
	 
											var _self = this,
													_args = arguments;
	 
											if (timer) {
													clearTimeout(timer);
											}
	 
											timer = setTimeout( function(){
	 
													timer = null;
													evt.type = 'scrollstop';
													jQuery.event.handle.apply(_self, _args);
	 
											}, special.scrollstop.latency);
	 
									};
	 
							jQuery(this).bind('scroll', handler).data(uid2, handler);
	 
					},
					teardown: function() {
							jQuery(this).unbind( 'scroll', jQuery(this).data(uid2) );
					}
			};
	 
	})();

	/**
	 * jQuery.ScrollTo - Easy element scrolling using jQuery.
	 * Copyright (c) 2007-2009 Ariel Flesler - aflesler(at)gmail(dot)com | http://flesler.blogspot.com
	 * Dual licensed under MIT and GPL.
	 * Date: 5/25/2009
	 * @author Ariel Flesler
	 * @version 1.4.2
	 *
	 * http://flesler.blogspot.com/2007/10/jqueryscrollto.html
	 */
	;(function(d){var k=d.scrollTo=function(a,i,e){d(window).scrollTo(a,i,e)};k.defaults={axis:'xy',duration:parseFloat(d.fn.jquery)>=1.3?0:1};k.window=function(a){return d(window)._scrollable()};d.fn._scrollable=function(){return this.map(function(){var a=this,i=!a.nodeName||d.inArray(a.nodeName.toLowerCase(),['iframe','#document','html','body'])!=-1;if(!i)return a;var e=(a.contentWindow||a).document||a.ownerDocument||a;return d.browser.safari||e.compatMode=='BackCompat'?e.body:e.documentElement})};d.fn.scrollTo=function(n,j,b){if(typeof j=='object'){b=j;j=0}if(typeof b=='function')b={onAfter:b};if(n=='max')n=9e9;b=d.extend({},k.defaults,b);j=j||b.speed||b.duration;b.queue=b.queue&&b.axis.length>1;if(b.queue)j/=2;b.offset=p(b.offset);b.over=p(b.over);return this._scrollable().each(function(){var q=this,r=d(q),f=n,s,g={},u=r.is('html,body');switch(typeof f){case'number':case'string':if(/^([+-]=)?\d+(\.\d+)?(px|%)?$/.test(f)){f=p(f);break}f=d(f,this);case'object':if(f.is||f.style)s=(f=d(f)).offset()}d.each(b.axis.split(''),function(a,i){var e=i=='x'?'Left':'Top',h=e.toLowerCase(),c='scroll'+e,l=q[c],m=k.max(q,i);if(s){g[c]=s[h]+(u?0:l-r.offset()[h]);if(b.margin){g[c]-=parseInt(f.css('margin'+e))||0;g[c]-=parseInt(f.css('border'+e+'Width'))||0}g[c]+=b.offset[h]||0;if(b.over[h])g[c]+=f[i=='x'?'width':'height']()*b.over[h]}else{var o=f[h];g[c]=o.slice&&o.slice(-1)=='%'?parseFloat(o)/100*m:o}if(/^\d+$/.test(g[c]))g[c]=g[c]<=0?0:Math.min(g[c],m);if(!a&&b.queue){if(l!=g[c])t(b.onAfterFirst);delete g[c]}});t(b.onAfter);function t(a){r.animate(g,j,b.easing,a&&function(){a.call(this,n,b)})}}).end()};k.max=function(a,i){var e=i=='x'?'Width':'Height',h='scroll'+e;if(!d(a).is('html,body'))return a[h]-d(a)[e.toLowerCase()]();var c='client'+e,l=a.ownerDocument.documentElement,m=a.ownerDocument.body;return Math.max(l[h],m[h])-Math.min(l[c],m[c])};function p(a){return typeof a=='object'?a:{top:a,left:a}}})(jQuery);


});
