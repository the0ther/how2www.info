
require([
	"jquery",
	"ui",
	"jquery-plugins",
	"/js/libs/underscore.1.3.1-backbone.0.9.1.js",
	"/js/libs/flowplayer-3.2.9.min.js"
], function ($, UI) {

	window.$ = $;

	window.ui = (window.ui) ? $.extend(true, window.ui, UI) : UI;
	
	// tracking
	require(["/js/libs/s_code.js","https://www.everestjs.net/static/st.v2.js"], function () {
		window.ui.tracking.atlasPrefix = "EveryStepWeb_";
		window.ui.tracking.init();
	});
	
	require([
		"co",
		"/js/libs/swfobject.js"
	], function (CO) {
		
		window.co = $.extend(true, window.co, CO);

		// flash cookie
		$('body').prepend('<div id="sausalito" style="position:absolute;top:0;left:-2000px"></div>');

		window.ei = {};
		window.externalInterfaceReady = false;

		window.setExternalInterface = function () {
			externalInterfaceReady = true;
		}
		
		window.isReady = function () {
			// window.ui.log("checking if external interface is ready");
			return externalInterfaceReady;
		}
		
		window.setExternalInterface();

		var so = new SWFObject("cookie.swf", "kookie", "20", "20", "10", "#FFFFFF");
		so.write("sausalito");

	});

});

