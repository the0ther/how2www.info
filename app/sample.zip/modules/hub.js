$(document).ready( function() {
	$('img.01').addClass('show');	
	/* header animation with queue of athlete animation */
	$('#takeover p.s01').delay(1250).animate({ left:'0px'}, 650, 'easeOutExpo', function(){
		$('#takeover p.s02').delay(1000).animate({ left:'0px'}, 540, 'easeOutExpo',function(){
			$('#takeover p.s03').delay(1000).animate({ left:'0px'}, 750, 'easeOutExpo', function(){
				$('img.01').delay(4000).queue(function(next){
				    $('img.01').fadeOut(500);
					$('img.02').fadeIn(1000).addClass('shown');
				    next();
					// image 3
					if ($('img.02').hasClass('shown')) {
						$('img.02').delay(3500).queue(function(next){
							$('img.02').fadeOut(500).removeClass('shown');
							$('img.03').fadeIn(1000).addClass('shown');
							next();
							//image 4
							if ($('img.03').hasClass('shown')) {
								$('img.03').delay(3500).queue(function(next){
									$('img.03').fadeOut(500).removeClass('shown');
									$('img.04').fadeIn(1000).addClass('shown');
									next();
									//image 5
									if ($('img.04').hasClass('shown')) {
										$('img.04').delay(3500).queue(function(next){
											$('img.04').fadeOut(500).removeClass('shown');
											$('img.06').fadeIn(1000).addClass('shown');
											next();
											/*image 6
											if ($('img.05').hasClass('shown')) {
												$('img.05').delay(3500).queue(function(next){
													$('img.05').fadeOut(500).removeClass('shown');
													$('img.06').fadeIn(1000).addClass('shown');
													next();
													
													if ($('img.06').hasClass('shown')) {
														$('img.06').delay(3500).queue(function(next){
															$('img.06').fadeOut(500).removeClass('shown');
															$('img.07').fadeIn(1000).addClass('shown');
															next();
														});
													}
												});
											}*/
										});
									}
								});
							}
						});
					}
				});
			});
		});
	});
	
	$('#list-links a#fb-link, a.link-attached').mouseover(function(){
		$('div#list-links').css({'background-image':'url(images/takeover/bg-takeover-list-on.png)'});
		$('#list-links h2 a, a#fb-link span').css('color','#00bdf2');
	});
	$('#list-links a#fb-link, a.link-attached').mouseout(function(){
		$('div#list-links').css({'background-image':'url(images/takeover/bg-takeover-list.png)'});
		$('#list-links h2 a, a#fb-link span').css('color','#188ac7');
	});
	
	$('#box-team, #box-cards, #box-tools').hover(function(){
		$(this).css('backgroundPosition','bottom left');},function(){$(this).css('backgroundPosition','top left');
	});	
		
});