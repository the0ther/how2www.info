
require([
	"jquery",
	"ui",
	"jquery-plugins",
	"/js/libs/underscore.1.3.1-backbone.0.9.1.js",
	"/js/libs/flowplayer.js"
], function ($, UI) {

	window.$ = $;
	window.ui = (window.ui) ? $.extend(true, window.ui, UI) : UI;
	window.co = window.co || {};
	
	// identify site section and template
	var _section = $('body').attr('data-site');
	var _template = $('body').attr('data-template');

	// athletes page redirect
	if(_template == "athlete-details") {
		if(self == top) {
			$.cookie("athlete_redirect",document.location.href.split("/")[document.location.href.split("/").length-1],{path:"/"});
			top.location = "https://apps.facebook.com/"+co.model.fbNamespace;
		}
	} else {
		if($.cookie('athlete_redirect') !== null && $.cookie('athlete_redirect') !== "") {
			self.location = "/fb/athletes/"+$.cookie('athlete_redirect');
			$.cookie('athlete_redirect',"",{path:"/"});
		}
	}

	// tracking
	require([
		"/js/libs/s_code.js",
		"https://www.everestjs.net/static/st.v2.js"
	], function () {
		if(_section == "facebook") {
			window.ui.tracking.atlasPrefix = "EveryStepFB_";
		}
		window.ui.tracking.init();
	});
	
	// video popup page
	if(_template == "video") {
		$(document).ready(function() {
			window.ui.makeVideoPlayer({autoPlay:true});
			$f().load();
		});
	}

	// printable text pages
	if(_template == "print-page") {
		$(document).ready(function () {
			window.print();
		});
	}
	
	// employees
	if(_template == "employees") {
		if($('body').is('[data-template]')) {
			window.ui.log("fetching : "+"/js/modules/"+$.trim($('body').attr('data-template'))+".js");
			$.getScript(window.ui.serverBasePath+"/js/modules/"+$.trim($('body').attr('data-template'))+".js");
		}
	}

	// FB app pages
	if(_section == "facebook") {

		window.co.UserReady = $.Deferred();
		
		window.co.UserReady.done(function () {
			window.ui.log("main.js: the inited User object ",ui.theUser);
			if($('body').is('.canvas-app')) {
					window.ui.theHeader = new window.co.HeaderView({el:$('header:first')[0]});
			}
		});

		$('body').prepend('<div id="fb-root"></div>');

		require([
			"co",
			"https://connect.facebook.net/en_US/all.js",
			"https://platform.twitter.com/widgets.js"
		], function (CO) {
			
			window.co = $.extend(true, window.co, CO);
			window.ui.theApp = new window.co.App(window.co.model);
			window.ui.theAthletes = new window.co.Athletes(window.co.model.athletes);
			
			FB.init({
				appId: window.ui.appId,
				cookie: true, 
				xfbml: true,
				oauth: true,
				channelUrl:'//'+document.location.host+'/channel.html'
			});

			// Facebook hack for the line 22 all.js permissions error
			FB.UIServer.setLoadedNode = function(a,b){FB.UIServer._loadedNodes[a.id]=b;};
			
			//FB.Canvas.setAutoGrow();
			window.ui.iframeMan.init();

			// liking athlete page violates FB policy, likely to go away. using this now to listen for likes of content on dashboard (and elsewhere?)
			FB.Event.subscribe('edge.create',function(response){
				$.post("/points",{"activityId":2,"userId":window.ui.theUser.id,"metadata":'{"action":"likes","id":"'+response+'","from":"'+window.ui.theUser.id+'"}',token:window.co.model.csrfToken});
				window.ui.feedMan.muckPoints(10);
			});
			
			FB.Event.subscribe('comment.create', function(res) {
				$.post('/points', {
					'activityId': 26,
					'userId': window.ui.theUser.id,
					'metadata': '{"action": "comments", "id":"'+res.commentID+'", "from": "'+window.ui.theUser.id+'"}',
					'token': window.co.model.csrfToken
				});
			});
			
			FB.Canvas.scrollTo(0,0);

			window.ui.theUser = new window.co.User();
			window.ui.theCauses = new window.co.Causes();
			window.ui.theCauses.fetch({
				success: function () {
					window.ui.theAthletes.setCauses(window.ui.theCauses);
				},
				error: function () {
					window.ui.log('main.js: fetching the Causes collection failed!');
				}
			});
			
			FB.Canvas.setDoneLoading();
			window.ui.initFBappUI();

			if($('body').is('[data-template]')) {
				window.ui.log("fetching : "+"/js/modules/"+$.trim($('body').attr('data-template'))+".js");
				$.getScript(window.ui.serverBasePath+"/js/modules/"+$.trim($('body').attr('data-template'))+".js");
			}
			
		});
	}

	
});
