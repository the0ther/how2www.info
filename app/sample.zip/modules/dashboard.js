ui.log('dashboard: loaded script');


$(document).ready(function () {
	
	var $dashboard = $('.container-dashboard-page');
	

	// bulk up the user object
	window.ui.theUser.attributes.myAthlete = window.ui.theAthletes.get(ui.theUser.get('athleteId')).toJSON();
	window.ui.theUser.attributes.fbNamespace = window.ui.theApp.get('fbNamespace');
	window.ui.theUser.attributes.hostName = document.location.host;
	
	// render intro
	if($.cookie('dashboardinit') != null) {
		$dashboard.find('.div-intro-copy').html(_.template($('#dashboard-intro-step-template').html(), window.ui.theUser.toJSON()));
		$.cookie('dashboardinit',null,{path:"/"});
	} else {
		$dashboard.find('.div-intro-copy').html(_.template($('#dashboard-intro-template').html(), window.ui.theUser.toJSON()));
	}

	// render base template
	$dashboard.append(_.template($('#dashboard-content-template').html(), window.ui.theUser.toJSON()));
	
	$('h1:first,.div-tab-controls:first div:first,.div-tab-controls:last div:last').canvasToolbox({type:'gradient-title'});
	
	$('.div-tab-controls').each(function() {
		var _margin = (760-$('> div:first', this).outerWidth(true)-$('> div:last', this).outerWidth(true))/2;
		$(this).css({paddingLeft:_margin+"px"});
	});

	if(window.PIE) {
		$('.div-tab-controls > div').each(function() {
			PIE.detach(this);
			PIE.attach(this);
		});
		$('.div-tab-controls:first div:first,.div-tab-controls:last div:last').each(function() {
			$(this).css({width:$(this).width()-40});
		});
	}

	//window.ui.log($('.div-tab-controls').html())

	// bind ui controls
	$dashboard.on({
		'click' : function () {
			ui.shareApp();
		},
		'mouseenter' : function () {
			$(this).next().show();
		},
		'mouseleave' : function () {
			$(this).next().hide();
		}
	}, '[data-behavior="share-app"]');

	$dashboard.on({
		'mouseenter' : function () {
			$(this).next().show();
		},
		'mouseleave' : function () {
			$(this).next().hide();
		}
	}, '[data-action="tooltip"]');
	
	$('[data-role$="-feed-container"]').each(function () {
		this.renderButtons = function() {
			if($(this).is('[data-role="supporter-feed-container"]')) {
				var _scope = $(this).parent();
				var _top = 0;
				if($(this).find('[data-role="feed-item"]:first').length > 0) {
					_top = Math.abs(parseInt($(this).find('[data-role="feed-item"]:first').position().top));
				}
				if(_top == 0){
					$('[data-trigger="scroll-up"]',_scope).addClass('disabled');
				}else{
					$('[data-trigger="scroll-up"]',_scope).removeClass('disabled');
				}
				if(_top >= parseInt($(this).attr('data-height'))){
					$('[data-trigger="scroll-down"]',_scope).addClass('disabled');
				}else{
					$('[data-trigger="scroll-down"]',_scope).removeClass('disabled');
				}
			} else {
				var _scope = $(this).parent()[0];
				if(!$('[data-role="feed-item"]:last', this).is('.void')) {
					$('[data-trigger="scroll-right"]', _scope).css({display:'none'});
				} else {
					$('[data-trigger="scroll-right"]', _scope).css({display:''});
				}
				if(!$('[data-role="feed-item"]:first', this).is('.void')) {
					$('[data-trigger="scroll-left"]', _scope).css({display:'none'});
				} else {
					$('[data-trigger="scroll-left"]', _scope).css({display:''});
				}
			}
		}
	});

	$('[data-trigger="scroll-left"],[data-trigger="scroll-right"]').click(function (event) {
		var _d = ($(this).is('[data-trigger="scroll-left"]')) ? -1 : 1;
		var $container = $(this).siblings('[data-role="facebook-feed-container"],[data-role="twitter-feed-container"]');
		var $current = $container.find('[data-role="feed-item"]').not('.void');
		var _index = $container.find('[data-role="feed-item"]').index($current);
		if((_index+_d) > -1 && (_index+_d) < $container.find('[data-role="feed-item"]').length) {
			var $next = $container.find('[data-role="feed-item"]:eq('+(_index+_d)+')');
			$current.stop().animate({opacity:0},400,'swing', function () {
				$(this).addClass('void').css({zIndex:1});
			});
			$next.css({opacity:0,zIndex:3}).removeClass('void').stop().animate({opacity:1},400,'swing', function () {
				$next.css({zIndex:2});
				$container[0].renderButtons();
			});
			$container.stop().animate({height:$next.height()},800,'swing');
			if($container.is('[data-role="facebook-feed-container"]')) {
				window.ui.positionMosiac($next.height());
			}
		}
	});

	$(document).on({
		mouseenter : function () {
			$('img', this).css({top:-48});
		},
		mouseleave : function () {
			$('img', this).css({top:0});
		}
	}, '[data-trigger="scroll-left"],[data-trigger="scroll-right"]');

	$('[data-trigger="scroll-down"]').mousedown(function(){
		var $feed = $(this).parent().siblings('[data-role="supporter-feed-container"]');
		var _h = parseInt($feed.attr('data-height'));
		var _t = (_h-Math.abs(parseInt($feed.find('[data-role="feed-item"]:first').position().top)))/.25;
		$feed.find('[data-role="feed-item"]').animate({top:"-"+_h+"px"},_t,"linear");
	});

	$('[data-trigger="scroll-up"]').mousedown(function(){
		var $feed = $(this).parent().siblings('[data-role="supporter-feed-container"]');
		var _t = (Math.abs(parseInt($feed.find('[data-role="feed-item"]:first').position().top)))/.25;
		$feed.find('[data-role="feed-item"]').animate({top:0},_t,"linear");
	});

	$('[data-trigger="scroll-down"],[data-trigger="scroll-up"]').mouseup(function(){
		var $feed = $(this).parent().siblings('[data-role="supporter-feed-container"]');
		$feed.find('[data-role="feed-item"]').stop();
		$feed[0].renderButtons();
	});

	
	
	$(document).on({
		mouseenter : function () {
			if(!$(this).is('[data-mucked="true"]')) {
				$('[data-role="cta"]', this).stop().animate({width:90}, 400, 'swing');
			}
			var _size = ($(this).is('[data-role="media-content-large"]') ? 2 : 1);
			var $caption = $('[data-role="caption"]', this);
			$caption.stop().animate({height:$caption.attr('data-height'),paddingTop:(10*_size)+"px",paddingBottom:(12*_size)+"px"}, 400, 'swing');
			$('.div-fb-stats', this).addClass('hover');
		},
		mouseleave : function () {
			if(!$(this).is('[data-mucked="true"]')) {
				$('[data-role="cta"]', this).stop().animate({width:0}, 400, 'swing');
			}
			$('[data-role="caption"]', this).stop().animate({height:0,paddingTop:"0px",paddingBottom:"0px"}, 400, 'swing');
			$('.div-fb-stats', this).removeClass('hover');
		},
		click : function() {
			
			if($(this).parents('.div-all-athlete-content').length > 0) {
				window.ui.tracking.track("Gallery_Video_CLK");
			} else {
				window.ui.tracking.track("Dashboard_Video_CLK");
			}

			var _pointsParams = {
				"activityId":36,
				"userId":window.ui.theUser.id,
				"metadata":'{"resourceId":'+$('[data-resource-id]', this).attr('data-resource-id')+'}',
				"token":window.co.model.csrfToken
			};
			
			var _ogaction = (($('[data-resource-type]', this).attr('data-resource-type') == "video") ? 'watch' : 'view');
			var _ogobject = (($('[data-resource-type]', this).attr('data-resource-type') == "video") ? 'video' : 'photo');
			var _url = window.ui.serverBasePath+$('[data-media-path]', this).attr('data-media-path');

			if($('[data-role="article-content"]', this).length == 0) {
				window.ui.modal.open($('#videoPopup'));
				$('#videoPopup iframe').attr('src', _url);
				_pointsParams.activityId = (($('[data-resource-type]', this).attr('data-resource-type') == "video") ? 34 : 35);
			} else {
				_ogobject = "article";
				_url = window.ui.serverBasePath+"/athletes/"+window.ui.theUser.attributes.myAthlete.id+"/articles/"+$('[data-role="article-content"]', this).attr("data-resource-id");
			}

			if(_ogaction != "watch") {
				_ogaction = window.ui.theApp.get('fbNamespace')+':'+_ogaction;
			}
				
			if(!$(this).is('[data-mucked="true"]')) {
				$.post("/points",_pointsParams);
				ui.feedMan.muckItem(this);
				ui.feedMan.muckPoints();

				FB.api('/me/'+_ogaction+'?'+_ogobject+'='+_url,'post',function(response){
					// console.log(response);
				});
			}
		}
	}, '[data-role^="media-content-"]');

	$(document).on({
		mouseenter : function () {
			$('a',this).css({textDecoration:'underline'});
			$('p,.title', this).css({opacity:0.5});
		},
		mouseleave : function () {
			$('a',this).css({textDecoration:''});
			$('p,.title', this).css({opacity:1});
		},
		click : function () {
			window.open($('a', this).attr('href'), '_blank');
		}
	}, '[data-role="article-content"]');
	

	$(document).on('click', '.closeButton', function() {
		window.ui.modal.close($('#videoPopup'));
	});

	$(document).on('click', '#modal-mask', function() {
		window.ui.modal.close($('#videoPopup'));
	});

	// load feeds
	ui.feedMan.getAthleteFacebookFeed(window.ui.theUser.attributes.myAthlete.firstName, $('[data-role="facebook-feed-container"]'), function(data, targetEl) {
		var _fbhtml = new Array();
		var _twhtml = new Array();
		for(var i=0; i < data.updates.length; i++) {
			var _stub = {
				"what":data.updates[i].data.text,
				"who":((data.updates[i].data.channel == "twitter")?data.updates[i].data.author.token:data.updates[i].data.author.alias),
				"when":ui.prettyDate(new Date(data.updates[i].data.timestamp*1000).toString().substring(4,24)),
				"channel":data.updates[i].data.channel,
				"likes":data.updates[i].data.praises,
				"comments":data.updates[i].data.comments.length,
				"id" : data.updates[i].data.token
			};
			if(data.updates[i].data.photos.length > 0) {
				_stub.imageUrl = data.updates[i].data.photos[0].url;
				_stub.imageClass = "img-feed";
			} else {
				_stub.imageUrl = window.ui.assetPath+'/images/athlete-detail/'+window.ui.theUser.attributes.myAthlete.id+'/about-photo.png';
				_stub.imageClass = "img-profile";
			}
			
			// split up fb and twitter items
			if(data.updates[i].data.channel == "facebook") {
				_fbhtml.push(_.template($('#dashboard-facebook-feed-template').html(),_stub));
			}
		}

		$(targetEl).append(_fbhtml.join(""));
		$('[data-role="feed-item"]:eq(0)', targetEl).removeClass('void');
		$(targetEl).css({overflow:'hidden',height:$('[data-role="feed-item"]:eq(0)', targetEl).height()}).removeClass('style-loading');
		window.ui.positionMosiac();
		$(targetEl)[0].renderButtons();
	});

	ui.feedMan.getAthleteTwitterFeed(window.ui.theUser.attributes.myAthlete.firstName, $('[data-role="twitter-feed-container"]'), function(data, targetEl) {
		var _fbhtml = new Array();
		var _twhtml = new Array();
		for(var i=0; i < data.updates.length; i++) {
			var _stub = {
				"what":data.updates[i].data.text,
				"who":((data.updates[i].data.channel == "twitter")?data.updates[i].data.author.token:data.updates[i].data.author.alias),
				"when":ui.prettyDate(new Date(data.updates[i].data.timestamp*1000).toString().substring(4,24)),
				"channel":data.updates[i].data.channel,
				"likes":data.updates[i].data.praises,
				"comments":data.updates[i].data.comments.length,
				"id" : data.updates[i].data.token
			};
			if(data.updates[i].data.photos.length > 0) {
				_stub.imageUrl = data.updates[i].data.photos[0].url;
				_stub.imageClass = "img-feed";
			} else {
				_stub.imageUrl = window.ui.assetPath+'/images/athlete-detail/'+window.ui.theUser.attributes.myAthlete.id+'/about-photo.png';
				_stub.imageClass = "img-profile";
			}
			
			// split up fb and twitter items
			if(data.updates[i].data.channel == "twitter") {
				_twhtml.push(_.template($('#dashboard-twitter-feed-template').html(),_stub));
			}
		}

		$(targetEl).append(_twhtml.join(""));
		$('[data-role="feed-item"]:eq(0)', targetEl).removeClass('void');
		$(targetEl).css({overflow:'hidden',height:$('[data-role="feed-item"]:eq(0)', targetEl).height()}).removeClass('style-loading');
		$(targetEl)[0].renderButtons();
	});

	ui.feedMan.getSupportersFeed(window.ui.theUser.attributes.myAthlete.firstName, $('[data-role="supporter-feed-container"]'), function(data, targetEl) {
			var _html = new Array();
			for(var i=0; i < data.updates.length; i++) {
				var _stub = {
					"what":data.updates[i].data.text,
					"who":((data.updates[i].data.channel == "twitter")?data.updates[i].data.author.token:data.updates[i].data.author.alias),
					"when":ui.prettyDate(new Date(data.updates[i].data.timestamp*1000).toString().substring(4,24)),
					"channel":data.updates[i].data.channel
				};
				_html.push(_.template($('#dashboard-supporter-feed-template').html(),_stub));
			}
			$(targetEl).append(_html.join(""));
			var _height = $(targetEl).height();
			$(targetEl).css({height:275,overflow:'hidden'}).attr('data-height', _height-275);
			$(targetEl)[0].renderButtons();
	});
	

	// load XML content

	$.get('/data/'+window.ui.theUser.get('athleteId')+'/athleteMedia.xml', function (data) {

		window.ui.myAthleteXml = $(data);
		var _urls = new Array;

		$('[data-role^="media-content-"]', $('.div-my-athlete-content')[0]).each(function (i) {
			var $node = window.ui.myAthleteXml.find('video,photo,article').filter(':eq('+$(this).attr('data-load-order')+')');
			_urls.push(ui.serverBasePath+ui.feedMan.loadItem($node, this));
		});

		if(window.ui.myAthleteXml.find('video,photo,article').length > 11) {
			$('[data-action="load-more"]').show();
		}

		$('[data-action="load-more"]').click(function() {
			window.ui.feedMan.gimmeSomeMore();
		});

		$('[data-role="caption"]').each(function () {
			$(this).attr('data-height', $(this).height());
			$(this).css({height:0});
		});

		$('.div-article-content .title').each(function () {
			ui.rightSizeText(this);
		});

		ui.feedMan.muckItems();

		// get fb stats

		FB.api("/",{ids: _urls.join(",")},function (response) {

			$.each(response, function(i, item) {
				var _id = item.id.split("/")[item.id.split("/").length-1];
				ui.feedMan.setFBStats(_id, item);
			});

		});

	});

	$.get('/data/all-athletes.php', function (data) {
		
		window.ui.theAthleteXml = $('<?xml version="1.0" encoding="UTF-8"?>'+data.replace(/<\?xml version="1.0" encoding="UTF-8"\?>/g,''));
		ui.feedMan.buildPages('video', 9);
		ui.feedMan.buildPages('photo', 5);

		$('.div-tab-controls:last div:first').click(function () {
				$('.div-tab-controls:last').addClass('void');
				$('.div-all-athlete-content').addClass('hidden');
				$('.div-tab-controls:first').removeClass('void');
				$('.div-my-athlete-content').removeClass('hidden');
				ui.iframeMan.smoothScroll(550);
		});

		$('.div-tab-controls:first div:last').click(function () {
			$('.div-tab-controls:first').addClass('void');
			$('.div-my-athlete-content').addClass('hidden');
			$('.div-tab-controls:last').removeClass('void');
			$('.div-all-athlete-content').removeClass('hidden');
			if(window.ui.theAthleteXml.find('video').length > 0) {
				ui.feedMan.loadPage(0, $('[data-role="all-athlete-videos"]'));
			}
			if(window.ui.theAthleteXml.find('photo').not('[doNotShowInGallery="1"]').length > 0) {
				ui.feedMan.loadPage(0, $('[data-role="all-athlete-photos"]'));
			} else {
				$('[data-role="all-athlete-photos"]').parent().addClass('hidden');
			}
			ui.iframeMan.smoothScroll(550);
		});
	});

	// parse FB plugins
	FB.XFBML.parse($dashboard[0]);

});


