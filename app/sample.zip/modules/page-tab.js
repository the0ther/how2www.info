
$(document).ready(function () {

	if($('body').is('.page-tab')) {
		$(document).ready(function () {

			window.ui.makeVideoPlayer({
				onStart: function() {
					window.ui.tracking.track("PageTab_Video_CLK");
				},
				onFinish: function() {
					$f().unload();
					$('.videoPlayer').css({background:"url("+window.ui.assetPath+"/images/page-tab/replay.png) 350px 170px no-repeat"});
					$('header>p, header>img').show();
				}
			});

			$('[data-tracking="PageTab_GS_CLK"]').click(function (event) {
				window.ui.tracking.track("PageTab_GS_CLK");
				top.location = this.href;
				event.stopPropagation();
				event.preventDefault();
				return false;
			});

			$('[use-modal-iframe]').click(function () {
				$f().unload();
				$('.videoPlayer').css({background:"url("+window.ui.assetPath+"/images/page-tab/replay.png) 350px 170px no-repeat"});
				$('header>p, header>img').show();
			});
			
			window.ui.ActivitiesView = new window.co.ActivitiesView(window.co.model.activities);
			var pageTabView = new window.co.PageTabView({el:"body"});

		});
	}

});

