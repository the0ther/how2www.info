
require([
	"jquery",
	"ui",
	"/js/libs/flowplayer.js",
	"https://connect.facebook.net/en_US/all.js"
], function ($, UI) {

	window.$ = $;
	window.ui = (window.ui) ? $.extend(true, window.ui, UI) : UI;
	
	$('body').prepend('<div id="fb-root">');

	FB.init({
		appId: window.ui.appId,
		cookie: true, 
		xfbml: true,
		oauth: true,
		channelUrl:'//'+document.location.host+'/channel.html'
	});

	$.get('/data/all-athletes.php', function (data) {
		var $xml = $(data);

		$xml.find('[id]').each(function () {
			var _id = $.trim($(this).attr('id'));
			$(this).attr('id', $.trim($(this).parents('athlete-media').find('athlete-id').text())+_id);
		});

		var $node = $xml.find('[id="'+ window.ui.resourceId +'"]');

		if($node.length > 0) {
			$('[data-role="caption"]').text($node.find('copy').text());

			var _type = $node[0].nodeName.toLowerCase();

			if(_type == "photo") {
				var $img = $('<img src="'+$.trim($node.find('mediaPath').text())+'" alt="'+$node.find('description').text()+'">');
				$('[data-role="media-content"]').append($img);
			}

			if(_type == "video") {
				var $video = $('<a href="'+ $.trim($node.find('mediaPath').text()) +'" class="videoPlayer videoPopup_videoPlayer">');
				$('[data-role="media-content"]').append($video);
				ui.makeVideoPlayer();
			}
		}

	});

	window.setInterval(function() {
		window.parent.window.ui.modal.resizeIframe($('body').height());
	},200);
	

});
