
define(function () {
	
	// make it safe to use console.log always
	(function(b){function c(){}for(var d="assert,count,debug,dir,dirxml,error,exception,group,groupCollapsed,groupEnd,info,log,markTimeline,profile,profileEnd,time,timeEnd,trace,warn".split(","),a;a=d.pop();)b[a]=b[a]||c})(window.console=window.console||{});

	var _ui = {tracking:{},feedMan:{},mediaMan:{},modal:{}};
	
	_ui.serverBasePath = document.location.protocol+"//"+document.location.host;
	
	_ui.phoneRegex = /^[2-9]\d{2}[- ]?\d{3}[- ]?\d{4}$/;
	_ui.emailRegex = /^[0-9a-zA-Z]([-.\w]*[0-9a-zA-Z_+])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9}$/;
	_ui.zipRegex = /^\d{5}$/;

	// usage: log('inside coolFunc', this, arguments);
	// paulirish.com/2009/log-a-lightweight-wrapper-for-consolelog/
	_ui.log = function(msg) {
		if(window.console && document.location.href.indexOf("everystep.citi.com") == -1) {
				arguments.callee = arguments.callee.caller;
				console.log( Array.prototype.slice.call(arguments) );
		}
	};
	
	_ui.modal.open = function(modalEl) {
		modalEl = modalEl || [];
		$(modalEl).attr('data-pageheight', 'pushdown');
		$('#modal-mask').add(modalEl).show();
		this.positionModal(modalEl);
	};

	_ui.modal.close = function(modalEl) {
		modalEl = modalEl || [];
		$(modalEl).attr('data-pageheight', '');
		$('#modal-mask').add(modalEl).hide();
		$('iframe', modalEl[0]).attr('src', window.ui.assetPath+'/images/blank.gif').css({height:''});
	};

	_ui.modal.positionModal = function(modalEl) {
		var _h = modalEl.height();
		FB.Canvas.getPageInfo(function(info){
			//modalEl.css({top:info.scrollTop+((info.clientHeight-_h)/2)-40});
			modalEl.css({top:info.scrollTop+60});
		});
	};

	_ui.modal.resizeIframe = function(height) {
		$('#videoPopup iframe').css({height:height});
		// this.positionModal($('#videoPopup'));
	};

	_ui.iframeMan = {
		timer: null,
		last: 0,
		init: function () {
			this.timer = window.setInterval(window.ui.iframeMan.autoGrow,20);
		},
		autoGrow: function () {
			var _h = $('body').height();
			var _p = $('[data-pageheight="pushdown"]');
			if(_p.not(':hidden').length > 0) {
				if(_p.is('#videoPopup')) {
					_h = Math.max(_h,_p.outerHeight(true)+_p.position().top+60);
				} else {
					_h = Math.max(_h,_p.outerHeight(true)+_p.position().top+$('header').height()+60);
				}
			}
			if(_h != this.last) {
				FB.Canvas.setSize({height:_h});
				this.last = _h;
			}
		},
		smoothScroll: function (scrollTo) {
			FB.Canvas.getPageInfo(function(info) {
				var _from = {property: info.scrollTop};
				var _to = {property: scrollTo};
				$(_from).animate(_to,{duration:800,step:function(now,fx) {
					FB.Canvas.scrollTo(0,now);
				}});
	    });
		}
	};

	_ui.feedMan.get = function (groupsArray, targetEl, successCallback, errorCallback) {
		successCallback = successCallback || function () {};
		errorCallback = errorCallback || function () {};
		var _limit = $(targetEl).children('[data-role="feed-item"]').length+20;
		if(_limit <= 100) {
			$.ajax({
				url : "https://publiciscitieverystep.feedmagnet.com/content/get/?groups="+groupsArray.join("&groups="),
				data : {limit:_limit,impression:"a03c1bcdaa8ce1791b47d4938fadee0da5dbe252"},
				dataType : "jsonp",
				jsonp : "callback",
				timeout : 10000,
				success : function(data){
					for(var i=0; i < data.updates.length; i++) {
						data.updates[i].data.text = data.updates[i].data.text.replace(/(http:\/\/[^\s]+)/g, window.ui.feedMan.buildLink('$1'));
						//data.updates[i].data.text = data.updates[i].data.text.replace(/.\">/g,'"').replace(/,\"/g,'"');
					}

					successCallback(data, targetEl);
				},
				error : function(jqXHR, textStatus, errorThrown) {
					errorCallback(jqXHR, textStatus, errorThrown, targetEl);
				}
			});
		}
	};

	_ui.feedMan.buildLink = function(link) {

		return '<a href="'+link+'">'+link+'</a>';
	};

	_ui.feedMan.imageLoaded = function (imgEl) {
		var $feed = $(imgEl).parents('[data-role$="-feed-container"]');
		var $item = $(imgEl).parents('[data-role="feed-item"]');
		if(!$item.is('.void')) {
			$feed.css({height:$item.height()});
			if($feed.is('[data-role="facebook-feed-container"]')) {
				window.ui.positionMosiac();
			}
		}
	};

	_ui.feedMan.getSupportersFeed = function (prefix, targetEl, successCallback, errorCallback) {
		prefix = prefix.toLowerCase().replace('bob & mike','bryan-bros');
		this.get([prefix+"-mentions"], targetEl, successCallback, errorCallback );
	};

	_ui.feedMan.getAthleteFeed = function (prefix, targetEl, successCallback, errorCallback) {
		prefix = prefix.toLowerCase().replace('bob & mike','bryan-bros');
		var _groups = [prefix+"-wall",prefix+"-status",prefix+"-handle"];
		if($(targetEl).is('[data-feed-type="all"]')){
			_groups = new Array();
			window.ui.theAthletes.each(function (model) {
				var _aprefix = model.get('firstName').toLowerCase().replace('bob & mike','bryan-bros');
				if(_aprefix != prefix) {
					_groups.push(_aprefix+'-wall',_aprefix+'-status',_aprefix+'-handle');
				}
			});
		}
		this.get(_groups, targetEl, successCallback, errorCallback );
	};

	_ui.feedMan.getAthleteTwitterFeed = function (prefix, targetEl, successCallback, errorCallback) {
		prefix = prefix.toLowerCase().replace('bob & mike','bryan-bros');
		var _groups = [prefix+"-handle"];
		if($(targetEl).is('[data-feed-type="all"]')){
			_groups = new Array();
			window.ui.theAthletes.each(function (model) {
				var _aprefix = model.get('firstName').toLowerCase().replace('bob & mike','bryan-bros');
				if(_aprefix != prefix) {
					_groups.push(_aprefix+'-handle');
				}
			});
		}
		this.get(_groups, targetEl, successCallback, errorCallback );
	};

	_ui.feedMan.getAthleteFacebookFeed = function (prefix, targetEl, successCallback, errorCallback) {
		prefix = prefix.toLowerCase().replace('bob & mike','bryan-bros');
		var _groups = [prefix+"-wall",prefix+"-status"];
		if($(targetEl).is('[data-feed-type="all"]')){
			_groups = new Array();
			window.ui.theAthletes.each(function (model) {
				var _aprefix = model.get('firstName').toLowerCase().replace('bob & mike','bryan-bros');
				if(_aprefix != prefix) {
					_groups.push(_aprefix+'-wall',_aprefix+'-status');
				}
			});
		}
		this.get(_groups, targetEl, successCallback, errorCallback );
	};
	
	_ui.feedMan.buildPages = function (type, pageSize) {
		
		var _vHtml = new Array;
		var _pHtml = new Array;

		for(var i=0; i < Math.ceil(ui.theAthleteXml.find(type).not('[doNotShowInGallery="1"]').length/pageSize); i++) {
			_vHtml.push($('#dashboard-all-'+type+'s-template').html());
			_pHtml.push('<span data-role="page-link" data-page="'+i+'">'+(i+1)+'</span>');
		}

		$('[data-role="all-athlete-'+type+'s"]').append(_vHtml.join(""));
		$('[data-role="all-athlete-'+type+'s"]').find('[data-role^="media-content-"]').filter(':gt('+(ui.theAthleteXml.find(type).length-1)+')').remove();
		$('.div-all-athlete-'+type+'s-pagination').append('<span data-role="page-prev" class="arrow">&lt;&nbsp;&nbsp;&nbsp;</span>'+_pHtml.join("&nbsp; | &nbsp;")+'<span data-role="page-next" class="arrow">&nbsp;&nbsp;&nbsp;&gt;</span>');
		//$('[data-role="all-athlete-'+type+'s"] [data-role="page"]:first').attr('data-current-page', true);
		
		var $pagination = $('.div-all-athlete-'+type+'s-pagination');

		$('[data-role="page-link"]', $pagination[0]).click(function() {
			ui.feedMan.loadPage($(this).attr('data-page'), $(this).parent().prev());
		});

		$('[data-role="page-prev"]', $pagination[0]).click(function() {
			var $container = $(this).parent().prev();
			var _index = $container.find('[data-role="page"]').index($container.find('[data-current-page="true"]')[0])-1;
			if(_index > -1) {
				ui.feedMan.loadPage(_index, $container);
			}
		});

		$('[data-role="page-next"]', $pagination[0]).click(function() {
			var $container = $(this).parent().prev();
			var _index = $container.find('[data-role="page"]').index($container.find('[data-current-page="true"]')[0])+1;
			if(_index < $container.find('[data-role="page"]').length) {
				ui.feedMan.loadPage(_index, $container);
			}
		});
	};

	_ui.feedMan.loadPage = function (index, targetEls) {
		targetEls.each(function() {
			var _type = ($(this).attr('data-role').indexOf("photo") != -1) ? "photo" : "video";
			if(!$('[data-role="page"]:eq('+index+')', this).is('[data-loaded="true"]')) {
				$('[data-role^="media-content-"]', $('[data-role="page"]:eq('+index+')', this)[0]).each(function () {
					var $node = window.ui.theAthleteXml.find(_type).not('[doNotShowInGallery="1"]').filter(':first');
					ui.feedMan.loadItem($node, this, $.trim($node.parents("athlete-media").find("athlete-id").text()));
					window.ui.theAthleteXml.find(_type).not('[doNotShowInGallery="1"]').filter(':first').remove();
				});

				$('[data-role="caption"]', $('[data-role="page"]:eq('+index+')', this)[0]).each(function () {
					$(this).attr('data-height', $(this).height());
					$(this).css({height:0});
				});
				
				ui.feedMan.muckItems();

				$('[data-role="page"]:eq('+index+')', this).attr('data-loaded', 'true');
			}
			
			var $current = $('[data-current-page="true"]', this);
			var $next = $('[data-role="page"]:eq('+index+')', this);
			
			if($('[data-role="page"]', this).index($current[0]) != $('[data-role="page"]', this).index($next[0])) {
				$current.stop().attr('data-current-page', '').animate({left:-800},800,"swing");
				$next.stop().css({left:800}).attr('data-current-page', 'true').animate({left:15},800,"swing");
				$('[data-role="page-link"]', $(this).next()[0]).removeClass('active').filter(':eq('+index+')').addClass('active');
			}

		});
	};

	_ui.feedMan.gimmeSomeMore = function() {

		var _pageSize = 6;
		var _count = $('.div-my-athlete-content [data-role^="media-content-"]').length
		var _rem = window.ui.myAthleteXml.find('video,photo,article').length-_count;
		var _urls = new Array;

		if(_rem > 0) {
			for(var i=0; i < _pageSize; i++) {
				var $div = $('<div class="div-media-'+((i==0) ? "large" : "small")+' float-left style-loading div-media-more'+(i+1)+'" data-role="media-content-small"></div>');
				$('[data-role="more-content"]').append($div);
				
				_urls.push(window.ui.serverBasePath+ui.feedMan.loadItem(window.ui.myAthleteXml.find('video,photo,article').filter(':eq('+(_count+i)+')'), $div[0]));

				$('[data-role="caption"]', $div[0]).each(function () {
					$(this).attr('data-height', $(this).height());
					$(this).css({height:0});
				});

				$('.div-article-content .title', $div[0]).each(function () {
					ui.rightSizeText(this);
				});
			}

			ui.feedMan.muckItems();

			FB.api("/",{ids: _urls.join(",")},function (response) {
				$.each(response, function(i, item) {
					var _id = item.id.split("/")[item.id.split("/").length-1];
					ui.feedMan.setFBStats(_id, item);
				});
			});
		}
		if(_rem <= _pageSize) {
			$('[data-action="load-more"]').hide();
		}
	};

	_ui.feedMan.muckItems = function () {
		for(var i=0; i < window.ui.theUser.attributes.points.details.length; i++) {
			if(window.ui.theUser.attributes.points.details[i].metadata && window.ui.theUser.attributes.points.details[i].metadata.resourceId) {
				var _id = window.ui.theUser.attributes.points.details[i].metadata.resourceId;
				if(_id) {
					var $el = $('[data-resource-id="'+_id+'"][data-mucked!="true"]');
					if($el.length > 0) {
						ui.feedMan.muckItem(($el.is('[data-role="image"]')) ? $el.parent()[0] : $el[0]);
					}
				}
			}
		}
	}

	_ui.feedMan.loadItem = function(node, el, athleteId) {
		athleteId = athleteId || window.ui.theUser.get('athleteId');
		var _return = "";
		var _content = {
			id:'',
			type:'',
			image:'',
			caption:'',
			url:'#',
			isNew:false,
			verb:'',
			title:'',
			date:'',
			source:'',
			isVideo:false,
			mediaPath:''
		};
		if(node.length > 0) {
			_content.id = athleteId+$.trim(node.attr('id'));
			_content.type = node[0].nodeName.toLowerCase();
			_content.caption = node.find('description').text();
			_content.isNew = node.is('[isNew="1"]');
			_content.title = node.find('title').text();
			_content.date = node.find('date').text();
			_content.source = node.find('publication').text();
			_content.url = node.find('link').text();
			if(_content.type == "video") {
				_content.verb = "WATCH";
				_content.isVideo = true;
			} else {
				_content.verb = "VIEW";
			}
			if($(el).is('[data-role="media-content-large"]')) {
				_content.image = window.ui.assetPath+node.find('thumbnails large').text();
			} else {
				_content.image = window.ui.assetPath+node.find('thumbnails small').text();
			}
			_content.mediaPath = "/athletes/"+athleteId+"/"+_content.type+"s/"+athleteId+$.trim(node.attr('id'));
			_return = _content.mediaPath;
			$(el).html(_.template(((_content.type == "article") ? $('#dashboard-media-article-template').html() : $('#dashboard-media-content-template').html()), _content));
		} else {
			$(el).remove();
		}
		return _return;
	};

	_ui.feedMan.muckItem = function(el) {
		var _type = $('[data-resource-type]', el).attr('data-resource-type');
		var _text = ((_type == "video") ? "WATCHED" : "VIEWED");
		
		if($(el).is('[data-role="article-content"]')) {
			// $(el).css({opacity:0.5});
			$(el).parent().attr('data-mucked', 'true');
		} else {
			$(el).attr('data-mucked', 'true');
		}

		$('[data-role="cta"]', el).text(_text).stop().css({width:110});
	};

	_ui.feedMan.muckPoints = function(points) {
		points = points || 1;
		$('[data-mucked-points="true"]').each(function() {
			var _points = parseInt($(this).text().replace(/,/g,""), 10)+points;
			$(this).text(window.ui.commifyNumber(_points));
		});
	};

	_ui.feedMan.setFBStats = function (id, stats) {
		window.ui.log(id);
		$('.img-media-content[data-resource-id="'+id+'"]').each(function() {
			stats.shares = (stats.shares || 0);
			stats.comments = (stats.comments || 0);
			$(this).parent().append(_.template($('#dashboard-fb-stats-template').html(), stats));
		});
	};

	_ui.positionMosiac = function (height) {
		height = height || $('[data-role="facebook-feed-container"] [data-role="feed-item"]').not('.void').height();
		$('[data-behavior="mosiac-shim"]:first').stop().animate({top: Math.max(0, (height-367)*0.25)}, 600, 'swing');
		$('[data-behavior="mosiac-shim"]:last').stop().animate({top: Math.max(0, (height-367)*0.75)}, 600, 'swing');
	};

	_ui.rightSizeText = function(el) {
		var _h = $(el).height();
		var $child = $(el).children(':first');
		var _fs = 42;
		$child.css({fontSize:(_fs)+"px"});
		while ($child.height() > _h) {
			$child.css({fontSize:(_fs--)+"px"});
		}
	};
	
	_ui.tracking = {
		atlasUrl: "https://view.atdmt.com/iaction/",
		atlasPrefix: "EveryStepWeb_",
		pagePath: document.location.pathname

	};

	_ui.tracking.campaignTable = [
		{"site":"America Online", "label":"Run of Patch-300x250", "guid":"E658B9D4-51BE-4C34-8314-C22387766F45"},
		{"site":"America Online", "label":"Run of Patch-300x600", "guid":"861C2DA8-F57B-484B-A7A2-0D78FA23FC43"},
		{"site":"America Online", "label":"Run of Patch-300x250", "guid":"66E7CB52-83C1-4E99-AA0E-7B5DE3F56020"},
		{"site":"America Online", "label":"Run of Patch-300x600", "guid":"0F489276-E589-4B8B-A373-8639145B0D97"},
		{"site":"America Online", "label":"Patch Editorial Content", "guid":"CA0AC3A5-A796-4F33-AF93-8B3E7412E7D1"},
		{"site":"ESPN", "label":"ESPN - Banner / InContent - Olympics - Story Pages Rotational: ESPN - InContent - Olympics - Story Pages Rotational", "guid":"3839C446-3CBC-48A0-A9EF-476A46A7E961"},
		{"site":"ESPN", "label":"ESPN - Banner / InContent - Olympics - Story Pages Rotational", "guid":"2A439997-AE7F-4D6A-8860-7701A0289E1F"},
		{"site":"ESPN", "label":"ESPN - Billboard / InContent - ESPN - Frontpage Sponsorship: ESPN - Billboard / InContent - ESPN - Frontpage Sponsorship: ESPN - InContent - ESPN - Frontpage Sponsorship (5/16)", "guid":"8FF7D74D-0DB7-4103-955D-52DDA0761EAE"},
		{"site":"ESPN", "label":"ESPN - Billboard / InContent - ESPN - Frontpage Sponsorship: ESPN - Billboard / InContent - ESPN - Frontpage Sponsorship: ESPN - Billboard - ESPN - Frontpage Sponsorship (5/16)", "guid":"20A96E2B-6C4F-4BF0-8CFD-43CE80B5CDDB"},
		{"site":"ESPN", "label":"ESPN - Billboard / InContent - ESPN - Frontpage Sponsorship: ESPN - Billboard / InContent - ESPN - Frontpage Sponsorship: ESPN - InContent - ESPN - Frontpage Sponsorship (6/26)", "guid":"65769E39-2709-4DEE-9A71-3A2D5E3D4B6D"},
		{"site":"ESPN", "label":"ESPN - Billboard / InContent - ESPN - Frontpage Sponsorship: ESPN - Billboard / InContent - ESPN - Frontpage Sponsorship: ESPN - Billboard - ESPN - Frontpage Sponsorship (6/26)", "guid":"9908E367-7C86-45CA-89A6-A73098D15063"},
		{"site":"ESPN", "label":"ESPN - InContent - Olympics - Homepage Sponsorship: ESPN - InContent - Olympics - Homepage Sponsorship", "guid":"C14D6D6D-15E8-40C1-A305-F032AC49B1AB"},
		{"site":"ESPN", "label":"ESPN - Video - Sportscenter Collection Sponsorship (5/16)", "guid":"E5985CA1-D68C-40B5-8904-0985BEC72603"},
		{"site":"ESPN", "label":"ESPN - Video - Sportscenter Collection Sponsorship (6/26)", "guid":"4E9D3B7A-A5AC-46E4-8469-68D0578F201C"},
		{"site":"ESPN", "label":"ESPN - Video - Sportscenter Collection Sponsorship (7/19)", "guid":"E657A660-A7B3-4E57-A662-C6E18AE87C06"},
		{"site":"ESPN", "label":"Day Blast (5/16)", "guid":"8B68815F-12FA-471B-9204-266E2F2F272F"},
		{"site":"ESPN", "label":"Day Blast (6/26)", "guid":"1AE90DF9-CB99-4031-9FFB-C9BA78420CD7"},
		{"site":"Facebook", "label":"Premium Engagement Ads & Sponsored Stories: Sustaining Media: Gain awareness and brand lift", "guid":"AC7E66F7-330B-45CA-84AD-5E4B6B2B7557"},
		{"site":"Facebook", "label":"Marketplace Engagement Ads & Sponsored Stories: Sustaining Media: Spread mass reach and presence (NO LONGER RUNNING)", "guid":"E1CD6530-7AA9-43E5-8A50-C0A0E0105ADC"},
		{"site":"Facebook", "label":"Reachblock: Facebook Homepage 1 Day Takeover: Recommended for campaign launch date - Max reach and frequency for 1 day. Target - A25+ (5/14)", "guid":"25B5CC3B-14D4-41F1-9428-64789E0FC8C3"},
		{"site":"Internal Ad Serving", "label":"Search - Efficient Frontier", "guid":"A6652BF8-C7B5-4A56-ABD6-DA5598B02604"},
		{"site":"Meebo", "label":"Animated Media Alert - Expanded State", "guid":"BC5F7E20-0ACE-499A-B227-22E0A11FF273"},
		{"site":"Meebo", "label":"Animated Media Alert - Resolved State", "guid":"D7025D6C-6FB3-4AD8-BC5C-C8A62843D4CF"},
		{"site":"Meebo", "label":"Animated Media Alert - Initial State", "guid":"F3810280-7881-4EB7-9A19-41D8861A036E"},
		{"site":"SocialCode", "label":"Social Code Cost per Click Campaign", "guid":"24E2A741-6D16-49A3-9F6A-2DF01ADA01E5"},
		{"site":"Yahoo! Inc.", "label":"Yahoo Mail_FB Logged in users BT 6 Geos 160x600", "guid":"F2C37CFF-9F61-4F79-BDF3-5FBAE688F31D"},
		{"site":"Yahoo! Inc.", "label":"Yahoo Mail_FB Logged in users BT 6 Geos 300x250", "guid":"6FF2BB22-D6F5-4365-9F42-555DCC168639"},
		{"site":"Yahoo! Inc.", "label":"Yahoo Mail Heavy Social Sharers 6 Geos 160x600", "guid":"760B1965-EBAC-4405-AB74-8BCC03A89AB8"},
		{"site":"Yahoo! Inc.", "label":"Yahoo Mail Heavy Social Sharers 6 Geos 300x250", "guid":"EFE52AFF-79A8-4541-A91B-D4ECD3DB2D2C"},
		{"site":"Yahoo! Inc.", "label":"Yahoo Mail Heavy Social Sharers 6 Geos 300x600", "guid":"82F0C71D-FBDB-4A49-A0BB-9218B46B2986"},
		{"site":"Yahoo! Inc.", "label":"Yahoo O&O ROS_FB Logged in users BT 6 Geos 160x600", "guid":"C7354637-7685-4F1A-8442-5B0DD197E471"},
		{"site":"Yahoo! Inc.", "label":"Yahoo O&O ROS_FB Logged in users BT 6 Geos 300x250", "guid":"F00A300A-9F0A-48F0-A248-37082339CDCB"},
		{"site":"Yahoo! Inc.", "label":"Yahoo O&O ROS_FB Logged in users BT 6 Geos 728x90", "guid":"018561B1-8E1E-4E6C-A210-B41D4450735E"},
		{"site":"Yahoo! Inc.", "label":"Yahoo O&O ROS_Heavy Social Sharers 6 Geos 160x600", "guid":"7E4077E6-7C18-4F97-A654-9C6EA15020D1"},
		{"site":"Yahoo! Inc.", "label":"Yahoo O&O ROS_Heavy Social Sharers 6 Geos 300x250", "guid":"7120E96F-85CA-4871-9241-8AE2FC5E2576"},
		{"site":"Yahoo! Inc.", "label":"Yahoo O&O ROS_Heavy Social Sharers 6 Geos 300x600", "guid":"9D967E2A-7048-4E99-A4D9-A8988BBB0C9A"},
		{"site":"Yahoo! Inc.", "label":"Yahoo O&O ROS_Heavy Social Sharers 6 Geos 728x90", "guid":"58ABFF01-989E-4D64-B6CB-E587D2F6C0AC"},
		{"site":"Yahoo! Inc.", "label":"Yahoo ROS 160x600 BONUS", "guid":"303F6FF7-AE19-4773-86CF-CE48153ABA71"},
		{"site":"Yahoo! Inc.", "label":"Yahoo Sports ROS 6 Geos 160x600", "guid":"9AC41D8C-4C65-4792-88EE-F1B248E6EE8A"},
		{"site":"Yahoo! Inc.", "label":"Yahoo Sports ROS 6 Geos 300x250", "guid":"FC5DF41E-3548-42DA-8DB3-127BA4851961"},
		{"site":"Yahoo! Inc.", "label":"Yahoo Sports ROS 6 Geos 728x90", "guid":"FD3DCB5C-0164-4760-BC36-6DE09F2CBD1A"},
		{"site":"Yahoo! Inc.", "label":"Yahoo! Sports FB Logged in User 160x600", "guid":"ADB5BA6E-EA35-4800-B15E-834D9871D116"},
		{"site":"Yahoo! Inc.", "label":"Yahoo! Sports FB Logged in User 300X250", "guid":"FFEF4CF8-040D-41F8-9DE1-7127F193D619"},
		{"site":"Yahoo! Inc.", "label":"Yahoo! Sports Homepage Takeover_300x250", "guid":"E04F982B-55C1-4DFD-8B5B-AF5BE4FA7443"},
		{"site":"Yahoo! Inc.", "label":"Yahoo! Homepage Custom Interactive", "guid":"E1234C0C-8574-44AD-8B13-32D3938D1BA6"}
	];

	_ui.tracking.track = function(tag) {
		var _atlasTag = this.atlasKey+"_"+this.atlasPrefix+tag
		var _omnitureTag = this.atlasPrefix+tag;
		
		window.ui.log(tag,_atlasTag,_omnitureTag);
		
		if(this.atlasFrame == null) {
			this.atlasFrame = $('<iframe id="atlas-tracking-frame" src="'+this.atlasUrl+_atlasTag+'" width="1" height="1" frameborder="0"></iframe>').appendTo('body');				
		} else {
			this.atlasFrame.attr('src',this.atlasUrl+_atlasTag);
		}
		s.pageName = _omnitureTag;
		s.t();

		if(tag == "PageTab_GS_CLK") {
			$('body').append('<iframe width="1" height="1" frameborder="0" src="https://socialcodedev.com/tracking/pixel_fires.php?app_id=B60496287A9C11E19A291231381A1D5D&app_action_type_id=B605DFCE7A9C11E19A291231381A1D5D">');
		}

		if(tag == "ATHTY_PV") {
			window.ef_event_type = "transaction";
			window.ef_transaction_properties = "ev_FBConvert=<FBConvert>&ev_transid=<transid>";
			window.ef_segment = "";
			window.ef_search_segment = "";
			window.ef_userid = "2561";
			window.ef_pixel_host = "pixel.everesttech.net";
			window.ef_fb_is_app = 0;
			effp();
		}

		if(tag == "Sweeps_TY_PV") {
			window.ef_event_type = "transaction";
			window.ef_transaction_properties = "ev_FBEntry=<FBEntry>&ev_transid=<transid>";
			window.ef_segment = "";
			window.ef_search_segment = "";
			window.ef_userid = "2561";
			window.ef_pixel_host = "pixel.everesttech.net";
			window.ef_fb_is_app = 0;
			effp();
		}

		if(tag == "Home_SupportTY_PV") {
			window.ef_event_type = "transaction";
			window.ef_transaction_properties = "ev_LPConvert=<LPConvert>&ev_transid=<transid>";
			window.ef_segment = "";
			window.ef_search_segment = "";
			window.ef_userid = "2561";
			window.ef_pixel_host = "pixel.everesttech.net";
			window.ef_fb_is_app = 0;
			effp();
		}

		if(tag == "Home_SweepsTY_PV") {
			window.ef_event_type = "transaction";
			window.ef_transaction_properties = "ev_LPEntry=<LPEntry>&ev_transid=<transid>";
			window.ef_segment = "";
			window.ef_search_segment = "";
			window.ef_userid = "2561";
			window.ef_pixel_host = "pixel.everesttech.net";
			window.ef_fb_is_app = 0;
			effp();
		}
	};

	_ui.tracking.init = function() {
		
		this.guid = s.getQueryParam('guid');
		this.cid = s.getQueryParam('cid');
		this.iid = s.getQueryParam('iid');
		
		if(top != self) {
			if(typeof this.referrer !== 'undefined') {
				this.referrer = this.referrer.split('?')[1];
				if(this.referrer !== undefined && this.referrer !== "") {
					this.referrer = this.referrer.split("&");
					var _self = this;
					_.each(this.referrer, function(item) {
						if(item.indexOf("guid=") != -1 || item.indexOf("GUID=") != -1) {
							_self.guid = item.split("=")[1];
						}
						if(item.indexOf("cid=") != -1) {
							_self.cid = item.split("=")[1];
						}
						if(item.indexOf("iid=") != -1) {
							_self.iid = item.split("=")[1];
						}
					});
				}
			}
		}

		this.atlasFrame = null;
		s.pageName="" 
		s.server="" 
		s.channel="" 
		s.pageType="" 
		s.prop1="" 
		s.prop2="" 
		s.prop3="" 
		s.prop4="" 
		s.prop5="" 
		/* Conversion Variables */ 
		s.campaign="" 
		s.state="" 
		s.zip="" 
		s.events="" 
		s.products="" 
		s.purchaseID="" 
		s.eVar1=""
		s.eVar2="" 
		s.eVar3="" 
		s.eVar4="" 
		s.eVar5="" 
		/************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/ 
		//var s_code=s.t();

		s.eVar1 = this.guid;
		s.campaign = this.cid;
		if(!s.campaign) {
			s.campaign = this.iid;
		}
		
		var _guid = this.guid;
		$.each(this.campaignTable, function(i, item) {
			if(item.guid === _guid) {
				window.ui.log(item.site, item.label);
				s.campaign = item.label;
				s.channel = item.site;
			}
		});

		if($('body').is('[data-tracking]')) {
			this.track($('body').attr('data-tracking'));
		}

		$(document).on('click','[data-tracking]',function(event) {
			if(!$(this).is('body')) {
				var _tags = $(this).attr('data-tracking').split(",");
				$.each(_tags, function(i, tag) {
					window.ui.tracking.track(tag);
				});
			}
		});
		$(document).on('click',"#organization-tab",function() {
			window.ui.tracking.track("Home_Charity_CLK");
		});
		$(document).on('click',"#invisible-bttn",function() {
			window.ui.tracking.track("Home_Support_CLK");
		});
	};

	_ui.calcRealworldDistance = function(lat1,lon1,lat2,lon2){
		lat1 = parseFloat(lat1);
		lat2 = parseFloat(lat2);
		lon1 = parseFloat(lon1);
		lon2 = parseFloat(lon2);
		var R = 6371; // km
		var dLat = (lat2-lat1)*Math.PI/180;
		var dLon = (lon2-lon1)*Math.PI/180; 
		var a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLon/2) * Math.sin(dLon/2); 
		var c = 2 * Math.asin(Math.sqrt(a)); 
		var d = R * c;
		return d;
	};

	_ui.postToWall = function(id, text, callback) {
		FB.api('/'+id+'/feed', 'post', { 'message': text }, callback);
	};

	_ui.prettyDate = function(time){
		var date = new Date((time || "").replace(/-/g, "/").replace(/[TZ]/g, " ")),
    diff = (((new Date()).getTime() - date.getTime()) / 1000),
    day_diff = Math.floor(diff / 86400);
		if (isNaN(day_diff) || day_diff < 0 || day_diff >= 31) {
				return;
		}
		return day_diff === 0 && (
		diff < 60 && "just now" || diff < 120 && "1 minute ago" || diff < 3600 && Math.floor(diff / 60) + " minutes ago" || diff < 7200 && "1 hour ago" || diff < 86400 && Math.floor(diff / 3600) + " hours ago") || day_diff == 1 && "Yesterday" || day_diff < 7 && day_diff + " days ago" || day_diff < 31 && Math.ceil(day_diff / 7) + " weeks ago";
	};

	_ui.shortDate = function(time){
		var _date = time.substr(0,10).split("-");
		var _return = "";
		if(_date.length == 3) {
			return (_date[1] +"/"+ _date[2] +"/"+ _date[0]);
		}
		return _return;
	};

	_ui.parseActivityDetails = function(data, num) {
		var retval = [];
		for (var ii=0;ii<num && ii<data.length;ii++) {
			retval[ii] = this.buildDetails(data[ii]);
		}
		return retval;
	};

	_ui.buildDetails = function(item) {
		var _desc = "";
		_.each(window.co.model.activities,function(activity){
			if(parseInt(item.activityId,10) == parseInt(activity.id,10)){
				_desc = activity.description;
			}
		});
		return _desc;
	};

	_ui.shareApp = function(){
		FB.ui({
			method:'apprequests',
			message:'Join the movement and cheer on the athletes of Team Citi every step of the way.',
			display:'popup',
			redirect_uri:'https://'+document.location.hostname+'/fb/close.php?u='+window.ui.theUser.id
		});
	};

	_ui.enumObj = function(obj) {
		for (var prop in obj) {
			if (obj.hasOwnProperty()) {
				window.ui.log(prop);
			}
		}
	};

	_ui.commifyNumber = function (number) { 
		number = number.toString();
		if (number.length <= 3) { 
			return number;
		} else { 
			var _pre = number.substr(0,number.length-3); 
			var _post = number.substr(number.length-3,3); 
			_pre = this.commifyNumber(_pre); 
			return _pre+","+_post; 
		}
	};

	_ui.numberToWord = function(s) {
		var th = ['','thousand','million', 'billion','trillion'];
		var dg = ['zero','one','two','three','four', 'five','six','seven','eight','nine']; 
		var tn = ['ten','eleven','twelve','thirteen', 'fourteen','fifteen','sixteen', 'seventeen','eighteen','nineteen']; 
		var tw = ['twenty','thirty','forty','fifty', 'sixty','seventy','eighty','ninety'];
		s = s.toString(); s = s.replace(/[\, ]/g,''); if (s != parseFloat(s)) return 'not a number'; var x = s.indexOf('.'); if (x == -1) x = s.length; if (x > 15) return 'too big'; var n = s.split(''); var str = ''; var sk = 0; for (var i=0; i < x; i++) {if ((x-i)%3==2) {if (n[i] == '1') {str += tn[Number(n[i+1])] + ' '; i++; sk=1;} else if (n[i]!=0) {str += tw[n[i]-2] + ' ';sk=1;}} else if (n[i]!=0) {str += dg[n[i]] +' '; if ((x-i)%3==0) str += 'hundred ';sk=1;} if ((x-i)%3==1) {if (sk) str += th[(x-i-1)/3] + ' ';sk=0;}} if (x != s.length) {var y = s.length; str += 'point '; for (var i=x+1; i<y; i++) str += dg[n[i]] +' ';} return str.replace(/\s+/g,' ');
	};

	_ui.prettifyNumber = function(number) {
		if(number > 999){
			number = (parseInt(number)/1000).toFixed(1);
			numbers = number.toString().split(".");
			if(numbers.length == 1){
				number = numbers[0]+"k+";
			}else{
				if(parseInt(numbers[1]) < 5){
					number = numbers[0]+"k+";
				}
				if(parseInt(numbers[1]) == 5){
					number = numbers[0]+".5k";
				}
				if(parseInt(numbers[1]) > 5){
					number = numbers[0]+".5k+";
				}
			}
		}
		return number;
	};

	_ui.prettifyFontSize = function(text){
		var _fontSize = 32;
		if(text.length > 3){
			_fontSize = 28;
		}
		if(text.length > 3){
			_fontSize = 24;
		}
		return _fontSize;
	};

	_ui.makeVideoPlayer = function(data) {
		// window.ui.log('flowplayer license key: '+window.co.model.flowplayer.license);
		/*
		not sure if this is a cool way to do it but any value you want to change just add
		ui.makeVideoPlayer({"key":value}) in the code where you create the parameter change
		then add in the conditional statement below this comment the new boolean variable
		*/
		var autoPlay = true;
		var selector = "a.videoPlayer";
		var onStart = function() {};
		var onFinish = function() {};
		var onUnload = function() {};
		
		if (arguments.length > 0){
			autoPlay = (data.autoPlay !== undefined) ? data.autoPlay : true;
			selector = (data.selector !== undefined) ? data.selector : selector;
			onStart = (data.onStart !== undefined) ? data.onStart : onStart;
			onFinish = (data.onFinish !== undefined) ? data.onFinish : onFinish;
			onUnload = (data.onUnload !== undefined) ? data.onUnload : onUnload;
		}

		// console.log(onUnload)
		
		flowplayer(selector, "/flowplayer/flowplayer.commercial-3.2.7.swf", {
			key: window.co.model.flowplayer.license,
			logo: null,
			wmode: "opaque",
			clip: {
				"autoPlay" : autoPlay,
				"autoBuffering" : true,
				"scaling" : "fit",
				"onFinish" : onFinish,
				"onStart" : onStart,
				"onUnload" : onUnload
			},
			canvas: {
				backgroundColor: 'rgba(255, 252, 255, 1)'
			},
			screen: {
				"height" : "100pct",
				"top" : 0
			},
			plugins: {
				controls: {
					"borderRadius":0,
					"timeColor":"#ffffff",
					"bufferGradient":"none",
					"backgroundColor":"rgba(8, 132, 194, 1)",
					"volumeSliderGradient":"none",
					"timeBorderRadius":20,
					"time":false,
					"progressGradient":"none",
					"height":20,
					"volumeColor":"#003d7e",
					"opacity":1,
					"timeFontSize":12,
					"border":"0px",
					"bufferColor":"#ffffff",
					"progressColor": "#003d7e",
					"volumeSliderColor":"#ffffff",
					"buttonColor":"#ffffff",
					"autoHide": {"enabled":true,"hideDelay":500,"hideStyle":"fade","mouseOutDelay":500,"hideDuration":400,"fullscreenOnly":false}
				},
				"backgroundGradient":[0.5,0.4,0.3,0.2,0,0,0,0],
				"width":"100pct","display":"block",
				"sliderBorder":"1px solid rgba(128, 128, 128, 0.7)",
				"buttonOverColor":"#ffffff","url":"flowplayer.controls-3.2.5.swf",
				"fullscreen":false,
				"timeBgColor":"rgb(0, 0, 0, 0)",
				"borderWidth":0,
				"scrubberBarHeightRatio":0.5,
				"bottom":0,
				"buttonOffColor":"rgba(130,130,130,1)",
				"zIndex":1,
				"sliderColor":"#ffffff",
				"scrubberHeightRatio":0.5,
				"tooltipTextColor":"#ffffff",
				"spacing":{"time":6,"volume":8,"all":2},
				"sliderGradient":"none",
				"timeBgHeightRatio":0.6,
				"volumeSliderHeightRatio":0.8,
				"name":"controls",
				"timeSeparator":" ",
				"volumeBarHeightRatio":0.4,
				"left":"50pct",
				"tooltipColor":"#000000",
				"durationColor":"#a3a3a3",
				"progressColor":"#ffffff",
				"timeBorder":"0px solid rgba(0, 0, 0, 0.3)",
				"volume":false,
				"builtIn":false,
				"volumeBorder":"1px solid rgba(128, 128, 128, 0.7)",
				"margins":[2,12,2,12]
			}
		});
	};
	
	_ui.showPopup = function(popupId){
		window.popupEnabled = false;
		$("#popup_bg").css({
			"opacity": "0.7"
		});
		window.ui.centerPopup(popupId);
		window.ui.loadPopup(popupId);
	};

	_ui.loadPopup =	function (popupId) {
		if (!window.popupEnabled) {
			$("#popup_bg").fadeIn("slow");
			$("#"+popupId).fadeIn("slow");
			window.popupEnabled = true;
		}
	};

	_ui.disablePopup = function () {
		popupId = "videoPopup";
		window.ui.log('closing popup');
		if (window.popupEnabled) {
			$('iframe', '#'+popupId).attr('src','');
			$("#popup_bg").hide();
			$("#"+popupId).hide();
			window.popupEnabled = false;
		}
	};

	_ui.centerPopup = function (popupId) {
		var windowWidth = document.documentElement.clientWidth;
		var windowHeight = document.documentElement.clientHeight;
		var popupHeight = $("#"+popupId).height();
		var popupWidth = $("#"+popupId).width();

		if(typeof FB != 'undefined'){
			FB.Canvas.getPageInfo(function(info){
				$("#"+popupId).css({
					"position": "absolute",
					"top": (info.clientHeight/2) - (456/2) + info.scrollTop,
					"margin-left": '15px'
				});
			});
		} else {
			$("#"+popupId).css({
				"position": "absolute",
				"top": windowHeight / 2 - 456 / 2+$(window).scrollTop() + "px",
				"left": windowWidth / 2 - popupWidth / 2+$(window).scrollLeft() -20 + "px"
			});
		}
		
		$("#popup_bg").css({
			"height": windowHeight * 2
		});
	};

	_ui.dateToAge = function(bd) {
		var today = new Date();
		var parts = bd.split('-');
		var year = parts[0];
		var month = parts[1]-1;
		var day = parts[2];
		var birthDate = new Date(year, month, day);
		var age = today.getFullYear() - birthDate.getFullYear();
		var m = today.getMonth() - birthDate.getMonth();
		if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
			age--;
		}
		//window.ui.log(age);
		return age;
	};

	_ui.createTabs = function(){
		$('.tab-wrapper > div').not(':first-child').hide();
		
		$(document).on('click', '.tab-switch > span', function(){
			var tabNum = $(this).index();
			$(this).parent().next('.tab-wrapper').children('div').hide();
			$(this).parent().next('.tab-wrapper').children('div').eq(tabNum).show();
			$(this).parent().children('span').removeClass('active');
			$(this).addClass('active');
		});	
	};


	_ui.initFBappUI = function () {
		
		$(document).on('click', 'a[href^="http://"], a[href^="https://"], .newWindow', function(evt){
			if($(this).attr('href').indexOf('://twitter.com/') == -1) {
				window.open($(this).attr('href'), '_blank');
				evt.preventDefault();
			}
		});

		$(document).on('click', '.closeButton,#popup_bg', function() {
			window.ui.disablePopup();
		});
		
		// initialize iframe modals
		if($('#modal-mask').length == 0) {
			$('body').append('<div id="modal-mask"></div><div id="modal-container"></div>');
		}

		$('#modal-mask').css('opacity', '0.5');

		$(document).on('click', '#modal-container .closeButton', function(){
			$('#modal-mask, #modal-container').hide();
		});

		$(document).on('click', '[use-modal-iframe="true"]', function(event){
			
			if(typeof FB != 'undefined'){
				FB.Canvas.getPageInfo(function(info){
					$('#modal-container').css({top:info.scrollTop+(($('body').is('.page-tab')) ? -50 : 50)});
				});
			} else {
				$('#modal-container').css({top:$(document).scrollTop()+50});
			}
			
			$('#modal-mask, #modal-container').show();

			if(!$(this).is('[data-modal-content]')) {
				$('#modal-container').empty();
				$('#modal-container').load(this.href, function() {
						$('.modal-body').trigger('ui:loaded');
						$(this).find('> div:first').append('<div class="closeButton"></div>');
						
						if($('#modal-container .modal-scroller').length > 0) {
							if(typeof FB != 'undefined'){
								FB.Canvas.getPageInfo(function(info){
									$('#modal-container .modal-body').css({height:info.clientHeight-340});
								});
							} else {
								$('#modal-container .modal-body').css({height:$(window).height()-340});
							}
						}
				});
			} else {
				$('#modal-container').append($($(this).attr('data-modal-content')));
				$('.modal-body').removeClass('hidden').trigger('ui:loaded');
				$('#modal-container').find('> div:first').append('<div class="closeButton"></div>');

				if(window.PIE) {
					$('.modal-body .cta_style-04').each(function() {
						PIE.detach(this);
						PIE.attach(this);
					});
				}
			}

			event.preventDefault();
			return false;
		});

		// tooltips
		$(document).on('mouseenter','[data-tooltip]',function() {
			$('.tooltip-content').hide();
			$('.tooltip-content',this).css({display:'block',top:-40,left:180});
		});

		$(document).on('mouseleave','#athlete-detail_progress-sidebar',function() {
			$('.tooltip-content').hide();
		});

	};


	return _ui;
});

