co.UserReady.then(function(){
	
	$('h1:first').attr('data-alt-title-size',34).canvasToolbox({type:'gradient-title'});
	$('h2.gradient span').attr('data-title-size',30).canvasToolbox({type:'gradient-title'});

	$(document).on({
			mouseenter: function() {
				$(this).css('opacity', '1');
			},
			mouseleave: function() {
				$(this).css('opacity', '0.6')
			}
	}, ".video_play,.video_replay");
	
	ui.makeVideoPlayer({
		onStart: function() {
			ui.tracking.track("About_Video_CLK");
		},
		onFinish: function() {
			$f().unload();
			$('.how-it-works_videoPlayer').addClass('replay');
		}
	});

	ui.createTabs();
	ui.ActivitiesView = new co.ActivitiesView(ui.theApp.get('activities'));

});
