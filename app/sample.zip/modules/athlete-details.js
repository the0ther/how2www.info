co.FeedsReady = $.Deferred();

co.GridView = Backbone.View.extend({
	initialize:function(){
		this.xmlData = null;
		this._currentType = 'athlete';
		this._currentPage = {video:0,news:0};
		this._pageSize = {video:6,news:4};
		this._pageCount = {video:0,news:0};

		var _athlete = document.location.pathname.substring(document.location.pathname.lastIndexOf('/')+1);
		var _data = ui.theAthletes.get(_athlete).toJSON();
		
		//window.ui.log('athlete detail: the athlete ',_athlete);

		$('#main').append(_.template($('#athlete-detail-template').html(), _data));

		
		// center profile image on sidebar if it's too large
		if ($('#profile-photo').width() > $('#athlete-detail-sidebar').width()) {
			var photoOffset = ($('#profile-photo').width() - $('#athlete-detail-sidebar').width()) / 2;
			$('#profile-photo').css('left','-' + photoOffset + 'px');
		}
		
		this._pagerImgHTML = $('.athlete-detail-paginator:first').html();

		// hide support buttons if not needed, otherwise wire them up
		if (ui.theUser.get('athleteId') !== undefined && ui.theUser.get('athleteId') !== null) {
			//$('[src*="gradient-sidebar.png"]').remove();
			$('.big-support').children().css('visibility', 'hidden');
			$('.sm-support').children().remove();
		} else {
			$('.support-btn').click(function(){
				ui.theUser.saveAthlete(_data.id);
			});
		}

		// FM feeds
		var _ready = false;

		ui.feedMan.getAthleteFeed(_data.firstName, $('[data-feed-type="athlete"] > div')[0], function(data, targetEl) {
			var _html = new Array();
			for(var i=0; i < data.updates.length; i++){
				var _stub = {
					"what":data.updates[i].data.text,
					"who":((data.updates[i].data.channel == "twitter")?data.updates[i].data.author.token:data.updates[i].data.author.alias),
					"when":ui.prettyDate(new Date(data.updates[i].data.timestamp*1000).toString().substring(4,24)),
					"channel":data.updates[i].data.channel
				};
				_html.push(_.template($('#athlete-feed-template').html(),_stub))
			}

			var $wrapper = $(targetEl);
			$wrapper.append(_html.join(""));
			var _height = $wrapper.height()-210;
			$wrapper.css({height:210,overflow:'hidden',background:'#fff'}).attr('data-feed-height',_height);

			if(_ready){
				co.FeedsReady.resolve();
			}else{
				_ready = true;
			}
		});

		ui.feedMan.getSupportersFeed(_data.firstName, $('[data-feed-type="supporter"] > div')[0], function(data, targetEl) {
			var _html = new Array();
			for(var i=0; i < data.updates.length; i++){
				var _stub = {
					"what":data.updates[i].data.text,
					"who":((data.updates[i].data.channel == "twitter")?data.updates[i].data.author.token:data.updates[i].data.author.alias),
					"when":ui.prettyDate(new Date(data.updates[i].data.timestamp*1000).toString().substring(4,24)),
					"channel":data.updates[i].data.channel
				};
				_html.push(_.template($('#athlete-feed-template').html(),_stub))
			}

			var $wrapper = $(targetEl);
			$wrapper.append(_html.join(""));
			$wrapper.parent().parent().css({display:'block'});
			var _height = $wrapper.height()-210;
			$wrapper.css({height:210,overflow:'hidden',background:'#fff'}).attr('data-feed-height',_height);
			$wrapper.parent().parent().css({display:'none'});

			if(_ready){
				co.FeedsReady.resolve();
			}else{
				_ready = true;
			}
		});

		
		var _self = this;

		// XML for videos and news
		$.get('/data/'+_athlete+'/athleteMedia.xml', function(data) {
				_self.xmlData = data;
				_self.render();
		});
	},
	events:{
		"click [data-grid-page]":"changePage",
		"click .tab-switch-indicator span":"changeType",
		"click [data-grid-action]":"changePageByDirection"
	},
	render:function(){
		this.$('.athlete-detail-paginator,#athlete-video-containter,#athlete-news-containter').find('*').not('h3').remove();
		this.parseMediaXML();
		this.$('#athlete-video-containter > div').not('[grid-page='+this._currentPage.video+']').css({display:'none'});
		this.$('#athlete-news-containter > div').not('[grid-page='+this._currentPage.news+']').css({display:'none'});
		this.$('.athlete-detail-paginator').append(this._pagerImgHTML);

		if(this._pageCount.video > 0){
			$(this.makePagination(this._pageCount.video)).insertAfter('.athlete-detail-paginator:first img:first');
		}else{
			$('.athlete-detail-paginator:first').empty();
		}

		if(this._pageCount.news > 0){
			$(this.makePagination(this._pageCount.news)).insertAfter('.athlete-detail-paginator:last img:first');
		}else{
			$('.athlete-detail-paginator:last').empty();
		}

		// $(".rotate180").rotate(180);
		
		this.setPagination(0,this._currentPage.video);
		this.setPagination(1,this._currentPage.news);

		if(window.PIE) {
			$('.cta_style-06,#athlete-detail-twitter,#athlete-detail_progress-sidebar').each(function() {
				PIE.attach(this);
			});
		}

		FB.XFBML.parse(this.el);
	},
	changePage:function(args){
		var _page = parseInt($(args.currentTarget).attr('data-grid-page'));
		var _type = $('.athlete-detail-paginator').index($(args.currentTarget).parent()[0]);
		if(_type == 0){
			this._currentPage.video = _page;
		}else{
			this._currentPage.news = _page;
		}
		this.$(((_type==0)?'#athlete-video-containter > div':'#athlete-news-containter > div')).css({display:'none'}).filter('[grid-page='+_page+']').css({display:'block'});
		this.setPagination(_type,_page);
	},
	changeType:function(args){
		var _index = this.$('.tab-switch-indicator span').index(args.currentTarget);
		if(_index==0){
			this._currentType = "athlete"
		}else{
			this._currentType = "cause"
		}
		this.render();
	},
	changePageByDirection:function(args){
		var _direction = ($(args.currentTarget).is('[data-grid-action="next"]'))?1:-1;
		var _type = $('.athlete-detail-paginator').index($(args.currentTarget).parent()[0]);

		if(_type == 0 && this._currentPage.video+_direction > -1 && this._currentPage.video+_direction <= this._pageCount.video){
			this._currentPage.video = this._currentPage.video+_direction;
			this.$('#athlete-video-containter > div').css({display:'none'}).filter('[grid-page='+this._currentPage.video+']').css({display:'block'});
			this.setPagination(_type,this._currentPage.video);
		}

		if(_type == 1 && this._currentPage.news+_direction > -1 && this._currentPage.news+_direction <= this._pageCount.news){
			this._currentPage.news = this._currentPage.news+_direction;
			this.$('#athlete-news-containter > div').css({display:'none'}).filter('[grid-page='+this._currentPage.news+']').css({display:'block'});
			this.setPagination(_type,this._currentPage.news);
		}
	},
	makePagination:function(count){
		_pagination = new Array();
		for(var i=0; i <= count; i++){
			if(i!=0){
				_pagination.push('&nbsp;|&nbsp;');
			}
			_pagination.push('<span data-grid-page="'+i+'">'+(i+1)+'</span>');
		}
		return _pagination.join("");
	},
	setPagination: function(_type,_page){
		$('.athlete-detail-paginator:eq('+_type+') span.active').removeClass('active');
		$('.athlete-detail-paginator:eq('+_type+')').find('span:eq('+_page+')').addClass('active');
	},
	parseMediaXML: function() {

		var _self = this;
		var allVideoData = $(this.xmlData).find(this._currentType + '-data').find('video');
		if (allVideoData.length > 0) {
			allVideoData.each(function(ii, item){
				var videoTemplate = $('#athlete-video-template').html();
				videoTemplate = $(videoTemplate).clone();
				var _page = Math.floor(ii/_self._pageSize.video);
				$(videoTemplate).attr('grid-page',_page);
				_self._pageCount.video = _page;
				$(videoTemplate).find('a').attr('href', $(this).find('mediaPath').text());
				$(videoTemplate).find('img').attr('src', $(this).find('thumbnails small').text());
				$(videoTemplate).find('img').attr('alt', $(this).find('description').text());
				$('#athlete-video-containter').show().append($(videoTemplate)[0]);
			});
		} else {
			$('#athlete-video-containter').hide();
		}
		
		var allNewsData = $(this.xmlData).find(this._currentType + '-data').find('article');
		if (allNewsData.length > 0) {
			allNewsData.each(function(ii, item){
				var newsTemplate = $('#athlete-news-template div').clone();
				var _page = Math.floor(ii/_self._pageSize.news);
				newsTemplate.attr('grid-page',_page);
				_self._pageCount.news = _page;
				newsTemplate.find('h5').text($(this).find('title').text());
				newsTemplate.find('h6').eq(0).text($(this).find('publication').text());
				newsTemplate.find('h6').eq(1).text($(this).find('date').text());
				newsTemplate.find('p').text($(this).find('copy').text());
				newsTemplate.find('a').attr('href', $(this).find('link').text());
				$('#athlete-news-containter').show().append(newsTemplate);
			});
		} else {
			$('#athlete-news-containter').hide();
		}
	}
});

co.UserReady.then(function(){
	
	new co.GridView({el:$('#main')});
	
	$('h1:first').canvasToolbox({type:'gradient-title'});

	ui.createTabs();
	ui.makeVideoPlayer({onStart:function() {
		ui.tracking.track("AthDet_Video_CLK");
	}});
	
	$('#athlete-detail-story').show();
});

co.FeedsReady.then(function(){
	$('[data-feed-type] > div').each(function(){
		this.locked = false;
		this.renderButtons = function(){
			var _scope = $(this).parent().parent()[0];
			var _top = 0;
			if($(this).find('.feed-item:first').length > 0) {
				_top = Math.abs(parseInt($(this).find('.feed-item:first').position().top));
			}

			if(_top == 0){
				$('[data-feed-action="prev"]',_scope).addClass('disabled');
			}else{
				$('[data-feed-action="prev"]',_scope).removeClass('disabled');
			}
			if(_top >= parseInt($(this).attr('data-feed-height'))){
				$('[data-feed-action="next"]',_scope).addClass('disabled');
			}else{
				$('[data-feed-action="next"]',_scope).removeClass('disabled');
			}
		}
	});

	$('[data-feed-action="next"]').mousedown(function(){
		var $feed = $(this).parent().siblings('[data-feed-type]').find('> div');
		var _h = parseInt($feed.attr('data-feed-height'));
		var _t = (_h-Math.abs(parseInt($feed.find('.feed-item:first').position().top)))/.25;
		$feed.find('.feed-item').animate({top:"-"+_h+"px"},_t,"linear");
	});

	$('[data-feed-action="prev"]').mousedown(function(){
		var $feed = $(this).parent().siblings('[data-feed-type]').find('> div');
		var _t = (Math.abs(parseInt($feed.find('.feed-item:first').position().top)))/.25;
		$feed.find('.feed-item').animate({top:0},_t,"linear");
	});

	$('[data-feed-action="next"],[data-feed-action="prev"]').mouseup(function(){
		var $feed = $(this).parent().siblings('[data-feed-type]').find('> div');
		$feed.find('.feed-item').stop();
		$feed[0].renderButtons();
	});

	$('[data-feed-type] > div').each(function(){
		this.renderButtons();
	});

});

$(document).on('click', '#athlete-video-containter a', function(event){
	//window.ui.log('entering the event handler for athlete video');
	window.ui.tracking.track("AthDet_Video_CLK");

	event.preventDefault();
  ui.showPopup('videoPopup');
	var videoPath = $(this).attr('href');
	var videoCaption = $(this).children('img').attr('alt');
	$('#videoPopup iframe').attr('src', function(i, val) {
		//window.ui.log('setting the videoPath');
		//window.ui.log(videoPath);
		return '/videoPopup.php?videoPath=' + videoPath + '&videoCaption=' + videoCaption;
	});
});

