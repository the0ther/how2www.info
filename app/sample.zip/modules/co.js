
define(function () {
	
	var _co = {};
	
	/* Backbone.js Models forever and ever */
	_co.App = Backbone.Model.extend({
		defaults: function(){
			return{
				name: 'Citi Every Step of the Way',
				ui: 'ui'
			};
		}
	});

	_co.User = Backbone.Model.extend({
		urlRoot: '/users',
		defaults: function(){
			return{
				id: null,
				totalPoints: 0,
				originUrl: null,
				loggedIn: false,
				athleteId: 0,
				token: window.co.model.csrfToken
			};
		},
		initialize: function() {
			FB.getLoginStatus(function(response) {
				if(response.status === 'connected') {
					window.ui.theUser.set({
						id: response.authResponse.userID,
						facebookAccessToken: response.authResponse.accessToken
					});
					var _fbResponse = response;
					
					// process app requests
					FB.api("/me/apprequests/", function (response) {
						for(var i=0; i < response.data.length; i++){
							// credit 
							$.post("/points",{"activityId":1,"userId":response.data[i].from.id,"metadata":'{"friendId":"'+response.data[i].to.id+'"}',token:window.co.model.csrfToken});
							// remove
							FB.api('/'+response.data[i].id, 'DELETE', function(response) {
							});
						}
					});

					$('#pre-match-user-profile-picture').attr('src','https://graph.facebook.com/'+response.authResponse.userID+'/picture?type=normal');

					window.ui.theUser.fetch({
						success:function(model,response){
							// if the user doesn't exist then create a new user
							if(model.id === null){
								window.ui.theUser.set({
									id: _fbResponse.authResponse.userID,
									facebookAccessToken: _fbResponse.authResponse.accessToken
								});

								Backbone.sync('create',window.ui.theUser,{
									success:function(){
										window.co.UserReady.resolve();
									}
								});
							} else {
								// set some other data for the user, like total points
								var _points = window.ui.theUser.attributes.points.details;
								var i = 0;
								for(i=0; i<_points.length; i++) {
									window.ui.theUser.attributes.totalPoints += _points[i].value;
									_points[i].label = window.ui.buildDetails(_points[i]);
								}

								// make sure weekTotal is always an object
								if(typeof(window.ui.theUser.attributes.points.weekTotal) != "object"){
									window.ui.theUser.attributes.points.weekTotal = {points:window.ui.theUser.attributes.points.weekTotal};
								}
								
								window.ui.theUser.attributes.fbPoints = 0;
								window.ui.theUser.attributes.twitterPoints = 0;
								window.ui.theUser.attributes.foursquarePoints = 0;
								_points = window.ui.theUser.attributes.points.byCategory;
								for(i=0; i<_points.length; i++) {
									if(_points[i].category == "facebook"){
											window.ui.theUser.attributes.fbPoints += _points[i].points;
									}
									if(_points[i].category == "twitter"){
											window.ui.theUser.attributes.twitterPoints += _points[i].points;
									}
									if(_points[i].category == "foursquare"){
											window.ui.theUser.attributes.foursquarePoints += _points[i].points;
									}
								}
								FB.api('/me?metadata=1&accessToken='+window.ui.theUser.facebookAccessToken,function(response){
									
									window.ui.theUser.attributes.firstName = response.first_name;
									window.ui.theUser.attributes.lastName = response.last_name;

									window.co.UserReady.resolve();
								});
								
							}

						}
					}); // end of fetch
				}
			});
		},
		populateBestMatchValues:function(){
			
			/*
				50 Hometown Distance: < 160km
				35 Current City Distance: < 160km
				15 Birth Day 
				5 Birth Year 
				25 College 
				10 High School 
				5 Gender
				
				1 (each) Interests/Likes (max 20)

			*/

			// get some juicy FB user data
			FB.api('/me?metadata=1&accessToken='+window.ui.theUser.facebookAccessToken,function(response){
				FB.api('/me/interests?metadata=1&accessToken='+window.ui.theUser.facebookAccessToken,function(userInterests){
					FB.api('/me/likes?metadata=1&accessToken='+window.ui.theUser.facebookAccessToken,function(userLikes){
						FB.api('/'+((typeof response.hometown != 'undefined')?response.hometown.id:'-1'),function(userHometown){
							FB.api('/'+((typeof response.location != 'undefined')?response.location.id:'-1'),function(userLocation){
								
								var _athleteLoc = '';

								var _filler = [
									{title:'Hometown',copy:"",image:'athlete-match_hometown-gray.png'},
									{title:'Location',copy:"",image:'athlete-match_location-gray.png'},
									{title:'Age',copy:"",image:'athlete-match_birthyear-gray.png'},
									{title:'Birthday',copy:"",image:'athlete-match_birthday-gray.png'},
									{title:'High School',copy:"",image:'athlete-match_highschool-gray.png'},
									{title:'College',copy:"",image:'athlete-match_college-gray.png'},
									{title:'Interests',copy:"",image:'athlete-match_interests-gray.png'}
								];

								//window.ui.log(response);
								for(var i=0; i<window.ui.theAthletes.length; i++){
								
									var _possibleMatchPoints = 50+35+15+5+25+10+5+20;
									var _userMatchPoints = 0;
									var _interests = [];

									window.ui.theAthletes.at(i).set({userMatchValue:0,userMatchItems:[]});

									// hometown match
									//window.ui.log(userHometown);
									if(userHometown.location){
										_athleteLoc = window.ui.theAthletes.at(i).get('birthGeocode').split(" ");

										if(window.ui.calcRealworldDistance(userHometown.location.latitude,userHometown.location.longitude,_athleteLoc[0],_athleteLoc[1]) < 161){
											_userMatchPoints += 50;
											window.ui.theAthletes.at(i).attributes.userMatchItems.push({title:'Hometown',copy:'Both of you were born near '+userHometown.name,image:'athlete-match_hometown.png'});
										}
									}
									// current town match
									//window.ui.log(userLocation);
									if(userLocation.location){
										_athleteLoc = window.ui.theAthletes.at(i).get('homeGeocode').split(" ");
										if(window.ui.calcRealworldDistance(userLocation.location.latitude,userLocation.location.longitude,_athleteLoc[0],_athleteLoc[1]) < 161){
											_userMatchPoints += 35;
											window.ui.theAthletes.at(i).attributes.userMatchItems.push({title:'Location',copy:'Both of you live near '+userLocation.name,image:'athlete-match_location.png'});
										}
									}

									// birth day + birth year
									if(response.birthday){
										var _userBday = response.birthday.split("/");
										var _athleteBday = window.ui.theAthletes.at(i).get('birthDate').split("-");
										if(_userBday.length == 3 && _athleteBday.length == 3){
											if(_userBday[2] == _athleteBday[0]){
												_userMatchPoints += 5;
												window.ui.theAthletes.at(i).attributes.userMatchItems.push({title:'Age',copy:'Both of you were born in '+_userBday[2],image:'athlete-match_birthyear.png'});
											}
											if(_userBday[0] == _athleteBday[1] && _userBday[1] == _athleteBday[2]){
												_userMatchPoints += 15;
												window.ui.theAthletes.at(i).attributes.userMatchItems.push({title:'Birthday',copy:'Both of you were born on '+_userBday[0]+"/"+_userBday[1],image:'athlete-match_birthday.png'});
											}
										}
									}

									// college + high school
									var j = 0;
									if(response.education){
										for(j=0; j<response.education.length; j++){
											if(_.indexOf(window.ui.theAthletes.at(i).get('fbGraphIds'),response.education[j].school.id) != -1){
												if(response.education[j].type == "High School"){
													_userMatchPoints += 10;
													window.ui.theAthletes.at(i).attributes.userMatchItems.push({title:'High School',copy:'Both of you attended '+response.education[j].school.name,image:'athlete-match_highschool.png'});
												} else {
													_userMatchPoints += 25;
													window.ui.theAthletes.at(i).attributes.userMatchItems.push({title:'College',copy:'Both of you attended '+response.education[j].school.name,image:'athlete-match_college.png'});
												}
											}
										}
									}

									// gender match
									if(response.gender){
										if(response.gender == 'male' && window.ui.theAthletes.at(i).get('sex') == 'M'){
											_userMatchPoints += 5;
											//window.ui.theAthletes.at(i).attributes.userMatchItems.push({title:'Gender',copy:'Both of you are Male',image:'athlete-match_gender.png'});
										}
										if(response.gender == 'female' && window.ui.theAthletes.at(i).get('sex') == 'F'){
											_userMatchPoints += 5;
											//window.ui.theAthletes.at(i).attributes.userMatchItems.push({title:'Gender',copy:'Both of you are Female',image:'athlete-match_gender.png'});
										}
									}
									
									// interest + like match
									if(userInterests.data){
										//_possibleMatchPoints += userInterests.data.length;
										for(j=0; j<userInterests.data.length; j++){
											if(_.indexOf(window.ui.theAthletes.at(i).get('fbGraphIds'),userInterests.data[j].id) != -1){
												_userMatchPoints += 1;
												_interests.push(userInterests.data[j].category);
											}
										}
									}
									if(userLikes.data){
										//_possibleMatchPoints += userLikes.data.length;
										for(j=0; j<userLikes.data.length; j++){
											if(_.indexOf(window.ui.theAthletes.at(i).get('fbGraphIds'),userLikes.data[j].id) != -1){
												_userMatchPoints += 1;
												_interests.push(userLikes.data[j].category);
											}
										}
									}
									_interests = _.uniq(_interests);
									if(_interests.length > 0){
										window.ui.theAthletes.at(i).attributes.userMatchItems.push({title:'Interests',copy:'You both share a favorite '+_interests.join(", "),image:'athlete-match_interests.png'});
									}

									if(window.ui.theAthletes.at(i).attributes.userMatchItems.length < 8){
										for(var j=0; j < _filler.length; j++){
											var _found = false;
											for(var k=0; k < window.ui.theAthletes.at(i).attributes.userMatchItems.length && !_found; k++){
												if(window.ui.theAthletes.at(i).attributes.userMatchItems[k].title == _filler[j].title){
													_found = true;
												}
											}
											if(!_found){
												window.ui.theAthletes.at(i).attributes.userMatchItems.push(_filler[j]);
											}
										}
									}
									
									//window.ui.theAthletes.at(i).attributes.userMatchItems.reverse();
									window.ui.theAthletes.at(i).set({userMatchValue:Math.round((((_userMatchPoints > 0)?(_userMatchPoints/_possibleMatchPoints):0)*50)+50)});
								}

								if(!window.ui.theRegView){
									window.ui.theRegView = new window.co.RegistrationView({el:'#main'});
								}
							});
						});
					});
				});
			});
		},
		saveAthlete: function(athleteId){
			// create og connection
			FB.api('/me/'+window.ui.theApp.get('fbNamespace')+':support?athlete=http://'+document.location.host+'/athletes/'+athleteId,'post',function(response){
			});

			window.ui.theUser.save( {athleteId : athleteId}, {success :function(){
				if(document.location.pathname == "/fb/home"){
					FB.Canvas.scrollTo(0,0);
					$('header nav a:last').removeClass('hidden').css({display:'inline-block'});
				} else {
					document.location.href = "/fb/home?supported="+athleteId;
				}
			}});
		}
	});

	_co.Athlete = Backbone.Model.extend({
		defaults: function(){
			return{
				id: 0,
				firstName: null,
				lastName: null,
				sport: null,
				points: 0,
				goal: 0,
				supporters: 0,
				causeId: 0,
				twitterUsername: null,
				story: null,
				hasIntroVideo: false,
				hasThankYouVideo: false,
				imageIds: [],
				homeCity: null,
				homeState: null,
				homeGeocode: null,
				birthCity: null,
				birthState: null,
				birthDate: null,
				birthGeocode: null,
				horoscope: null,
				college: null,
				major: null,
				highSchool: null,
				isFeatured: false,
				sex: "M",
				fbGraphIds: [],
				userMatchValue: 0,
				userMatchItems: []
			};
		}
	});

	_co.Athletes = Backbone.Collection.extend({
		//model: window.co.Athlete,
		url: '/athletes',
		setCauses: function(causes) {
			//window.ui.log('entering Athletes.setCauses()');
			this.each( function (item) {
				var causeId = item.get('causeId');
				var cause;
				causes.each(function (causeItem) {
					if (causeId == causeItem.get('id')) {
						cause = causeItem.toJSON();
					}
				});
				if (cause) {
					item.attributes.cause = cause;
				} else {
					throw new Exception('no cause found for athlete: ' + this.toJSON());
				}

				// max points
				if(parseInt(item.attributes.points,10) > parseInt(item.attributes.goal,10)){
					item.attributes.points = item.attributes.goal;
				}
			});
		},
		comparator: function(athlete) {
			if(athlete.get('isFeatured') == true){
				return "AAAAAAAAAAAAAA"+athlete.get("firstName");
			}else{
				return athlete.get("firstName");
			}
		}
	});

	_co.Cause = Backbone.Model.extend({
		defaults: function(){
			return{
				id: null,
				title: null,
				description: null,
				videoPath: null,
				goal: 0
			};
		}
	});

	_co.Causes = Backbone.Collection.extend({
		//model: window.co.Cause,
		url: '/causes'
	});

	_co.HeaderView = Backbone.View.extend({
		initialize:function(){
			this.navStates = [
				"/fb/home",
				"/fb/athletes",
				"/fb/about",
				"/fb/profile",
				"/fb/win"
			];
			this.navState = _.indexOf(this.navStates,document.location.pathname);
			if (this.navState == -1){
				this.navState = 0;
			}
			// additional check to test for athletes detail page
			if(/\/athletes\/[0-9]+/.test(document.location.pathname)) {
				this.navState = 1;
			}
			this.render();
		},
		render:function(){
			
			// window.ui.log('the current nav section is ' + this.navState);
			// populate to the top bar thingy

			if((window.ui.theUser.get('athleteId') === undefined || window.ui.theUser.get('athleteId') !== null) && window.ui.theUser.get('athleteId') !== 0){
				var _params = {
					pointsTotal:window.ui.theUser.attributes.totalPoints,
					pointsWeek:window.ui.theUser.attributes.points.weekTotal.points,
					firstName:window.ui.theAthletes.get(window.ui.theUser.get('athleteId')).get('firstName'),
					id:window.ui.theUser.get('athleteId')
				};

				$('#my-points-toolbar').html(_.template($('#global-toolbar-template').html(),_params));
				$('header').removeClass('anon-header');
				$('header nav a.inactive').removeClass('inactive').attr('href','/fb/profile');
			} else {
				$('header nav a.inactive').click(function(){
					return false;
				});
			}

			// set the nav
			var $el = $('header nav a:eq('+this.navState+')');
			$el.addClass('active');
			$('.header-nav-arrow').css({left:$el.position().left+($el.width()/2)-12+40,visibility:'visible'});
			
			// set the header image bg for each section - might be randomized later
			var newNavState = this.navState + 1;
			$('header').css('background-image', function(index, value) {
				
				return value.replace('_.jpg', '_0' + newNavState + '.jpg');
			});
		}
	});

	_co.PromoCodeFormView = Backbone.View.extend({
		initialize: function(){
			$('#input-promo-code').focus(function(){
				if($.trim($(this).val()) == $(this).attr('data-input-label')){
					$(this).val("");
				}
			});
			$('#input-promo-code').blur(function(){
				if($.trim($(this).val()) == ""){
					$(this).val($(this).attr('data-input-label'));
				}
			}).trigger('blur');
			this.render();
		},
		events:{
			"click .trigger-promo-code-form":"submitPromoCode"
		},
		render: function() {
			if(window.ui.theUser.attributes.promoCode != "" && window.ui.theUser.attributes.promoCode != null){
				$(this.el).html(_.template($('#global-promo-code-success').html(),{lastName:window.ui.theAthletes.get(window.ui.theUser.get('athleteId')).get('lastName')}));
				$('.img-promo-code-badge').css({opacity:0}).removeClass('hidden').animate({opacity:1},800,"swing");
			}
			$(this.el).removeClass('hidden');

			if(window.PIE) {
				this.$('.cta_style-05').add(this.el).each(function() {
					PIE.attach(this);
				});
			}
		},
		submitPromoCode: function(args){
			if($.trim($('#input-promo-code').val()) != $('#input-promo-code').attr('data-input-label') && $.trim($('#input-promo-code').val()) != ""){
				var _self = this;
				window.ui.theUser.save( {promoCode : $.trim($('#input-promo-code').val())}, {success: function(){
					window.ui.log(window.ui.theUser.attributes.promoCode);
					$('#target-promo-code-error').hide();
					_self.render();
				},error: function() {
					$('#target-promo-code-error').show();
				}});
			} else {
				$('#target-promo-code-error').show();
			}
		}
	});

	_co.RegistrationView = Backbone.View.extend({
		initialize: function(){
			this._viewstates = ["choose-athlete","athlete-chosen"];
			this._viewstate = "choose-athlete";

			if(document.location.search.indexOf('supported') == -1) {
				this.theCarouselView = new window.co.CarouselView({el:'#athlete-chooser'});
				this.theAthleteDetailWelcomeView = new window.co.AthleteDetailWelcomeView({el:'#container-athlete-detail'});
				
				var _athleteModel = new Array();
				var _matchValue = 0;

				for(var i=0; i<window.ui.theAthletes.length; i++){
					window.ui.log(window.ui.theAthletes.at(i).get('firstName'),window.ui.theAthletes.at(i).get('userMatchValue'));
					if(window.ui.theAthletes.at(i).get('userMatchValue') == _matchValue){
						_athleteModel.push(window.ui.theAthletes.at(i));
					}else if(window.ui.theAthletes.at(i).get('userMatchValue') > _matchValue) {
						_athleteModel = [window.ui.theAthletes.at(i)];
						_matchValue = window.ui.theAthletes.at(i).get('userMatchValue');
					}
				}

				if(_athleteModel.length == 1){
					_athleteModel = _athleteModel[0];
				}else{
					_athleteModel = _athleteModel[Math.floor(Math.random()*_athleteModel.length)];
				}

				this.theAthleteHeroView = new window.co.AthleteHeroView({el:'#athlete-hero',model:_athleteModel});
				
				var _data = _athleteModel.toJSON();
				_data.userId = window.ui.theUser.id;

				$('.container-athlete-match-cta').prepend(_.template($('#best-match-images-template').html(),_data));
				$('#athlete-match-percent').css({opacity:0});
			}
			
			$('#main').css({opacity:0,visibility:'visible'}).animate({opacity:1},1200,"swing");
			this.render();
		},
		events:{
			"click .trigger-share-app":"shareApp",
			"click .trigger-best-match-reveal":"showBestMatch"
		},
		render: function(){
			var _changingAthlete = ($.cookie('changingathlete') != null)?true:false;
			$.cookie('changingathlete',null,{path:"/"});

			if (window.ui.theUser.get('athleteId') > 0 && !_changingAthlete) {
				this._viewstate = 'athlete-chosen';
				$.cookie('dashboardinit','true',{path:"/"});

				window.ui.tracking.track("ATHTY_PV");

				var selectedAthlete = window.ui.theAthletes.get(window.ui.theUser.get('athleteId'));
				var __template = _.template($('#athlete-chosen-template').html(),selectedAthlete.toJSON());
				$('[view-state="athlete-chosen"]').append(__template);

				if(window.ui.theUser.attributes.twitter) {
					$('.container-confirmation-hero .float-right > div > div:first').css({visibility:'hidden'});
					$('.container-confirmation-hero .float-right > div > div:last').css({top:-118});
				}

				this._thePromoCodeForm = new window.co.PromoCodeFormView({el:'.container-promo-code-form'});

				$('.header-nav-arrow').remove();
				$('header nav a.active').removeClass('active');
				$('header').css('background-image', function(index, value) {
			
					return value.replace('_00.jpg', '_' + ui.theUser.get('athleteId') + '.jpg');
				});

				if (window.ui.theUser.attributes.twitter) {
					$('#link-twitter-button').css({opacity:0.5,cursor:'default'}).on('click', function() {
						return false;
					});
					$('.link-twitter-mask').removeClass('hidden');
				}
				
				/*var tooltipTimer;*/
				
				$('.container-confirmation-hero .cta_style-04').bind('mouseenter', function() {
					if(!this.tooltipTimer || this.tooltipTimer == null) {
						var _self = this;
						this.tooltipTimer = window.setTimeout(function () {
							$(_self).nextAll('.tooltip-content').show(0);
						}, 2000);
					}
				});
			
				$('.container-confirmation-hero .cta_style-04').bind('mouseleave click',function() {
					window.clearTimeout(this.tooltipTimer);
					this.tooltipTimer = null;
					$(this).nextAll('.tooltip-content').hide();
				});

				FB.XFBML.parse(this.el);

			} else {
				this._viewstate = 'choose-athlete';


			}
			$('[view-state]').css({display:'none'}).filter('[view-state='+this._viewstate+']').css({display:'block'});
			
			if(window.ui.theUser.get('athleteId') > 0 && !_changingAthlete) {
				$('.container-athlete-confirmation h1').canvasToolbox({type:'gradient-title'});
				$('.container-confirm-more-ways .gradient span').attr('data-title-size',30).attr('data-alt-title-size',29).canvasToolbox({type:'gradient-title'});
				$('.container-confirmation-hero h3').canvasToolbox({type:'gradient-title'});
			} else {
				$('h1:first').canvasToolbox({type:'gradient-title'});
				$('.container-athlete-intro h2').attr('data-title-size',28).attr('data-alt-title-size',24).canvasToolbox({type:'gradient-title'});
				$('.container-confirmation-more h3').attr('data-title-size',24).canvasToolbox({type:'gradient-title'});
			}
			
			$('#best-match-cta-container').hover(
				function () {
					$('img',this).css({top:-89});
				}, 
				function () {
					$('img',this).css({top:0});
				}
			);
			
			this.renderPIE();
		},
		shareApp:function(){
			window.ui.tracking.track("ATHTY_FB_CLK");
			window.ui.shareApp();
			return false;
		},
		showBestMatch:function(){
			$('.container-athlete-match-cta').animate({height:253},400,"swing",function () {
					
			});
			// $('.container-athlete-match-cta img').css({opacity:1}).animate({opacity:0},400,"swing");
			$('#athlete-hero-match').animate({height:179+$('#athlete-hero-match-details').height()},800,"swing",function () {
				$('#hero-facepile').append('<fb:facepile href="https://'+document.location.host+'/athletes/'+window.ui.theUser.get('athleteId')+'" action="'+window.ui.theApp.get('fbNamespace')+':support" width="200" max_rows="1"></fb:facepile>');
				FB.XFBML.parse(this.el);		
			});
			$('#athlete-hero-detail,.trigger-athlete-hero-expand').css({display:'block'});
			$('#athlete-match-percent').css({opacity:1});

			$('#athlete-match-them').css({zIndex:-1});
			$('#athlete-match-athlete').css({zIndex:1});

			$('#athlete-hero-match-images').find('[arc-percentage]').canvasToolbox({type:'arc'}).canvasToolbox('animateIn');
			this.theAthleteDetailWelcomeView.hideAthleteDetail();
			window.ui.iframeMan.smoothScroll(550);
		},
		renderPIE: function () {
			if(window.PIE) {
				$('.cta_style-01,.cta_style-02,.cta_style-03,.cta_style-04,.cta_style-05,.tooltip-content,#athlete-detail_progress-sidebar,.container-carousel-pager span,.container-carousel-toggle span,.container-carousel-toggle,.container-confirmation-promo-code .fb-like-box > span').each(function() {
					PIE.detach(this);
					PIE.attach(this);
				});
			}
		}
	});

	_co.AthleteCompactView = Backbone.View.extend({
		initialize: function(){
			this.render();
		},
		events: {
			"click":"showAthleteDetail"
		},
		render: function(){
			$(this.el).empty().append(_.template($('#athlete-compact-template').html(),this.model.toJSON()));
		},
		showAthleteDetail: function(args){
			var $target = $(args.currentTarget);
			window.ui.theRegView.theAthleteDetailWelcomeView._viewstate = "visible";
			window.ui.theRegView.theAthleteDetailWelcomeView._top = $target.offset().top-137;
			window.ui.theRegView.theAthleteDetailWelcomeView.model = window.ui.theAthletes.getByCid($(args.currentTarget).attr('athlete-cid'));
			window.ui.theRegView.theAthleteDetailWelcomeView.render();
			$('#container-athlete-header_indicator').css('left', $target.position().left+($target.width()/2)-50 + 'px');
		}
	});

	_co.AthleteDetailWelcomeView = Backbone.View.extend({
		initialize: function(){
			this._viewstates = ["hidden","visible"];
			this._viewstate = "hidden";
			this._top = -1;
		},
		events: {
			"click .trigger-athlete-detail-close":"hideAthleteDetail",
			"click .support-btn":"supportAthlete"
		},
		render: function(){
			$(this.el).empty();
			if(this._viewstate == "visible"){
				var _data = this.model.toJSON();
				_data.facepileAction = window.ui.theApp.get('fbNamespace')+':support';
				_data.facepileUrl = 'https://'+document.location.host+'/athletes/'+this.model.id;
				_.each(window.ui.theCauses.models, function(cause){
					// _data.causeId should not be a string, but it is, so using toString()
					if (cause.id.toString() === _data.causeId) {
						_data.cause = {"title": cause.get('title'), "description": cause.get('description')};
					}
				});

				var template = _.template($('#athlete-detail-template').html(),_data);
				$(this.el).append(template);

				// FB.XFBML.parse(this.el);
				$(this.el).css({display:'block',top:this._top});
				window.ui.iframeMan.smoothScroll(this._top+180);
				
				ui.feedMan.getAthleteFeed(_data.firstName, this.el, function(data, targetEl) {
					var _html = new Array();
					for(var i=0; i < data.updates.length && i < 2; i++){
						var _stub = {
							"what":data.updates[i].data.text,
							"who":((data.updates[i].data.channel == "twitter")?data.updates[i].data.author.token:data.updates[i].data.author.alias),
							"when":window.ui.prettyDate(new Date(data.updates[i].data.timestamp*1000).toString().substring(4,24)),
							"channel":data.updates[i].data.channel
						};
						_html.push(_.template($('#athlete-stub-feed-template').html(),_stub))
					}
					$(targetEl).find('[data-feed-type="athlete"]').empty().append(_html.join(""));
				});

			} else {
				$(this.el).css({display:'none'});
				this.$(".video-athlete-details").empty();
			}

			if(window.PIE) {
				this.$('.cta_style-03,#athlete-detail_progress-sidebar').each(function() {
					PIE.attach(this);
				});
			}
		},
		supportAthlete:function(args){
			this._viewstate = 'hidden';
			this.render();
			window.ui.theUser.saveAthlete(this.model.id);
			window.ui.tracking.track("Home_Supp_CLK");
			window.ui.theRegView.render();
			return false;
		},
		hideAthleteDetail:function(args){
			this._viewstate = 'hidden';
			this.render();
		}
	});

	_co.AthleteHeroView = Backbone.View.extend({
		initialize:function(){
			this._viewstate = "expanded";
			var _data = this.model.toJSON();
			
			_data.userId = window.ui.theUser.id;
			
			_.each(window.ui.theCauses.models, function(cause){
				// _data.causeId should not be a string, but it is, so using toString()
				if (cause.id.toString() === _data.causeId) {
					_data.cause = {"title": cause.get('title'), "description": cause.get('description')};
				}
			});
			
			$(this.el).html(_.template($('#athlete-hero-template').html(),_data));
			this.$('#athlete-hero-detail').html(_.template($('#athlete-detail-template').html(),_data));
			this.$('#athlete-hero-detail .container-athlete-header').remove();
			this.$('.video-athlete-details').removeClass('video-athlete-details').addClass('video-athlete-hero');

			// populate match details
			var _items = this.model.attributes.userMatchItems;
			for(var i=0; i<_items.length; i++){
					this.$('#athlete-hero-match-details > .clear-after').append(_.template($('#athlete-hero-match-details-template').html(),_items[i]));
			}
			
			$('.athlete-match-list p').each(function(){
				if($.trim($(this).text()) == ""){
					$(this).parent().addClass('match-filler').css({opacity:0.3});
				}
			});

			// make some buttons
			if($('.athlete-match-list').not('.match-filler').length > 5){
				$('#athlete-hero-match-details').append('<span class="trigger-match-carousel-right"></span><span class="trigger-match-carousel-left"></span>');
				
				$('#athlete-hero-match-details').each(function(){
					this.locked = false;
					this.currentIndex = 0;
					this.maxIndex = _items.length-5;
				});

				$('.trigger-match-carousel-left,.trigger-match-carousel-right').on('click',function(){
					var _carousel = $('#athlete-hero-match-details');
					if(($(this).is('.trigger-match-carousel-left') && _carousel[0].currentIndex > 0) || ($(this).is('.trigger-match-carousel-right') && _carousel[0].currentIndex < _carousel[0].maxIndex)){
						if(!_carousel[0].locked){
							_carousel[0].locked = true;
							_carousel[0].currentIndex += (($(this).is('.trigger-match-carousel-left'))?-1:1);
							_carousel.find('> .clear-after').animate({left:($(this).is('.trigger-match-carousel-left')?"+":"-")+"=146px"},800,"swing",function(){
									$('#athlete-hero-match-details')[0].locked = false;	
							});
						}
					}
				});
			}
			
			ui.feedMan.getAthleteFeed(_data.firstName, this.el, function(data, targetEl) {
				var _html = new Array();
				for(var i=0; i < data.updates.length && i < 2; i++){
					var _stub = {
						"what":data.updates[i].data.text,
						"who":((data.updates[i].data.channel == "twitter")?data.updates[i].data.author.token:data.updates[i].data.author.alias),
						"when":window.ui.prettyDate(new Date(data.updates[i].data.timestamp*1000).toString().substring(4,24)),
						"channel":data.updates[i].data.channel
					};
					_html.push(_.template($('#athlete-stub-feed-template').html(),_stub))
				}
				$(targetEl).find('[data-feed-type="athlete"]').empty().append(_html.join(""));
			});
			
			$(document).on('click', '.video-athlete-details img, .video-athlete-details, .video-athlete-hero', function(event){
				window.ui.log('entering the event handler for athlete video');
				window.ui.tracking.track("Home_Video_CLK");
				window.ui.showPopup('videoPopup');
				var videoPath = $(this).attr('href');
				var videoCaption = $(this).children('img').attr('alt');
				if ($(this)[0].tagName.toLowerCase() === 'img') {
					videoPath = $(this).parent().attr('href');
					videoCaption = $(this).attr('alt');
				}
				$('#videoPopup iframe').attr('src', function(i, val) {
					window.ui.log('setting the videoPath');
					window.ui.log(videoPath);
					return '/videoPopup.php?videoPath=' + videoPath + '&videoCaption=' + videoCaption;
				});
				event.stopPropagation();
				event.preventDefault();
				return false;
			});
			
			// more/less button
			
			$('.trigger-athlete-hero-expand span').eq(1).hide();

			this.render();
		},
		events:{
			"click .trigger-athlete-hero-expand":"toggleView",
			"click .support-btn":"supportAthlete"
		},
		render:function(){
			
			if(this._viewstate == "expanded"){
				this.$('#athlete-hero-detail').css({overflow:'visible',height:'auto'});
				$('.trigger-athlete-hero-expand span').eq(0).hide();
				$('.trigger-athlete-hero-expand span').eq(1).show();
				$('.trigger-athlete-hero-expand img').eq(0).hide();
				$('.trigger-athlete-hero-expand img').eq(1).show();
			} else {
				this.$('#athlete-hero-detail').css({overflow:'hidden',height:0});
				$('.trigger-athlete-hero-expand span').eq(1).hide();
				$('.trigger-athlete-hero-expand span').eq(0).show();
				$('.trigger-athlete-hero-expand img').eq(1).hide();
				$('.trigger-athlete-hero-expand img').eq(0).show();
			}

		},
		toggleView: function(event){
				
			event.preventDefault();
			this._viewstate = ((this._viewstate == 'collapsed')?'expanded':'collapsed');
			this.render();

			if(window.ui.theRegView) {
				window.ui.theRegView.theAthleteDetailWelcomeView._viewstate = 'hidden';
				window.ui.theRegView.theAthleteDetailWelcomeView.render();
			}
			
			window.ui.theRegView.theAthleteDetailWelcomeView.hideAthleteDetail();
		},
		supportAthlete:function(args){
			window.ui.log('entering co.AthleteHeroView.supportAthlete()');
			window.ui.theUser.saveAthlete(this.model.id);
			window.ui.tracking.track("Home_Supp_CLK");
			window.ui.theRegView.render();
			return false;
		}
	});

	_co.CarouselView = Backbone.View.extend({
		initialize: function(){
			this._animateRender = false;
			this._viewstates = ['carousel','show-all'];
			this._viewstate = 'show-all';
			this._pageSize = 4;
			this._currentPage = 0;
			this._lastPage = -1;
			this._pages = -1;
			this._sortOrder = "name";
			$(this.el).append(_.template($('#carousel-template').html()));
			this.render();
		},
		events: {
			"click .container-carousel-toggle span":"toggleView",
			"click .trigger-carousel-change":"go2",
			"click .container-carousel-pager span":"go2",
			"click .container-carousel-sorter span":"sort"
		},
		render: function(){
			if(window.ui.theRegView) {
				window.ui.theRegView.theAthleteDetailWelcomeView._viewstate = 'hidden';
				window.ui.theRegView.theAthleteDetailWelcomeView.render();
			}
			this.$('.container-carousel-toggle span,.container-carousel-sorter span').removeClass('active-left active-right').css({cursor:'pointer'});
			this.$('.container-athlete').remove();
			if(this._sortOrder == 'name'){
				this.$('.container-carousel-sorter span:eq(0)').addClass('active');
				window.ui.theAthletes.sort();
			} else {
				this.$('.container-carousel-sorter span:eq(1)').addClass('active');
				window.ui.theAthletes.comparator = function(athlete) {return -parseInt(athlete.get("userMatchValue"), 10); };
				window.ui.theAthletes.sort();
			}

			var i = 0;
			for(i=0; i<window.ui.theAthletes.length; i++){
				var _className = "float-left container-athlete";
				if(window.ui.theAthletes.at(i).get('isFeatured') == true){
					_className += " featured-athlete";
				}
				var _el = this.make("div",{"class":_className});
				$(_el).attr('carousel-page',Math.floor(i/this._pageSize)).attr('athlete-cid',window.ui.theAthletes.at(i).cid);
				$(this.el).append(_el);
				this._pages = Math.floor(i/this._pageSize)+1;
			}
			this.$('.container-athlete').each(function(i){
				new window.co.AthleteCompactView({el:this,model:window.ui.theAthletes.at(i)});
			});
			if(this._viewstate == 'carousel'){
				$(this.el).removeClass('showOverflow');
				this.$('.container-athlete').not('[carousel-page='+this._currentPage+'],[carousel-page='+this._lastPage+']').css({visibility:'hidden'});
				var _self = this;
				this.$('.container-athlete[carousel-page='+this._lastPage+']').each(function(i){
					$(this).css({top:-(_self._lastPage*360)+"px"}).animate({left:600,opacity:0},((_self._animateRender)?800:0),"swing",function(){
						$(this).css('zIndex',-1);		
					});
				});
				this.$('.container-athlete[carousel-page='+this._currentPage+']').each(function(){
					$(this).css({top:-(_self._currentPage*360)+"px",left:-(200*i),zIndex:1}).animate({left:0,opacity:1},((_self._animateRender)?800:0),"swing");
				});
				this.$('.container-carousel-toggle span:eq(0)').addClass('active-left').css({cursor:'default'});
				this.$('.container-carousel-pager').empty();
				for(i=0; i<this._pages; i++){
					this.$(".container-carousel-pager").append('<span class="'+((i == this._currentPage)?'active':'')+'" carousel-page="'+(i)+'"></span>');
				}
				this.$('.container-carousel-pager,.trigger-carousel-change').css({display:'block'});
			} else {
				$(this.el).addClass('showOverflow');
				this.$('.container-athlete').css({display:'block',position:'relative'});
				this.$('.container-carousel-toggle span:eq(1)').addClass('active-right').css({cursor:'default'});
				this.$('.container-carousel-pager,.trigger-carousel-change').css({display:'none'});
			}
			this._animateRender = true;

		},
		sort:function(args){
			this._sortOrder = ((this._sortOrder == 'name')?'match':'name');
			this.render();
		},
		go2: function(args){
			var $target = $(args.currentTarget);
			if($target.is('[carousel-page]')){
				this._lastPage = this._currentPage;
				this._currentPage = parseInt($target.attr('carousel-page'), 10);
			}
			if($target.is('.arrow-left')){
				this._lastPage = this._currentPage;
				this._currentPage = (this._currentPage-1 < 0)?(this._pages-1):(this._currentPage-1);
			}
			if($target.is('.arrow-right')){
				this._lastPage = this._currentPage;
				this._currentPage = (this._currentPage+1 >= this._pages)?0:(this._currentPage+1);
			}
			this._animateRender = true;
			this.render();
		},
		toggleView: function(args){
			var _index = $('.container-carousel-toggle span').index(args.currentTarget);
			if(_index == 1){
				this._viewstate = 'show-all';
				this.render();
			}else{
				if(this._viewstate != 'carousel'){
					this._viewstate = 'carousel';
					this.render();
				}
			}
		}
	});

	_co.ActivitiesView = Backbone.View.extend({
		initialize: function(acts){
			this.activities = _.filter(acts, function(item) { return item.isActive && item.category !== 'citi'; });
			this.activities = _.sortBy(this.activities, function(item) { return item.displayOrder;});
			this.render();
		},
		tagName: "table",
		className: "activities",
		render: function() {
			var rowTmpl = '<tr>' +
					'<td><img src="/images/how-it-works/<%= icon %>" alt=""></td>' +
					'<td><%= uiDescription %></td>' +
					'<td><img src="/images/how-it-works/icon_plus<%= pointValue %>.png" alt=""></td>' +
					'</tr>';
			var tbody = $('<tbody></tbody>');
			$.each(this.activities, function(ii, elem){
				var thisRow = _.template(rowTmpl, elem);
				tbody.append(thisRow);
			});
			$('table.activities').append(tbody);
			$('table.activities tr:odd').addClass('alternating');
		}
	});

	_co.PageTabView = Backbone.View.extend({
		initialize:function(){
			this.viewstate = 'collapsed';
			this.render();
		},
		events:{
			"click .cta-more":"toggle",
			"click #container-more .closeButton":"toggle"
		},
		render:function(){
			this.$('#main').css({visibility:'visible'});
			if(this.viewstate == "expanded"){
				this.$('#container-more').slideDown();
			} else {
				this.$('#container-more').slideUp();
			}
			if(window.PIE) {
				$('.cta_style-01,.cta_style-02,.cta_style-05').each(function() {
					PIE.detach(this);
					PIE.attach(this);
				});
			}
		},
		toggle:function(event){
			event.preventDefault();
			if(this.viewstate == "collapsed"){
				this.viewstate = "expanded";
				$('#find-out-more').slideUp();
			} else {
				this.viewstate = "collapsed";
				$('#find-out-more').slideDown();
			}
			this.render();
		}
	});
	
	return _co;
});
