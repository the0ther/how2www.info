$(document).ready(function(){

	$('img#submit').hover(function () {
		$(this).attr("src", "/images/promo-code/get-code-btn-on.jpg")
	}, function () {
		$(this).attr("src", "/images/promo-code/get-code-btn-off.jpg")
	});

	$('img#gtfb').hover(function () {
		$(this).attr("src", "/images/promo-code/go-tofb-btn-on.jpg")
	}, function () {
		$(this).attr("src", "/images/promo-code/go-tofb-btn-off.jpg")
	});
    
	$('img#gtws').hover(function () {
		$(this).attr("src", "/images/promo-code/go-to-ws-btn-on.jpg")
	}, function () {
		$(this).attr("src", "/images/promo-code/go-to-ws-btn-off.jpg")
	});
	
	$('input').focus(function(){
		if($(this).val() == "000000")	{
			$(this).val('');
		}
		$(this).css("color", "#000000");
	});

	$('#promoCodeConfirmation, .error').hide();
	$('#the-code').css("border","2px solid #898989");
	$('#the-capcha').css("border","2px solid #898989");
		
	$('#submit').click( function(){
		$('p.error').hide();
	  window.ui.log('submitting form');
	  $.ajax('/promo-codes', {
	    type: 'POST',
	    data: {"id": $('#the-code').val(), captcha: $('#the-capcha').val(),"token": co.model.csrfToken}
	  })
		  .done(function(res, statusText){
		  	window.ui.log('heres the respoinse');
		  	window.ui.log(statusText);
	      window.ui.log(res);
	      if (res.promoCode) {
	              
	        $('#pc-form').slideUp("slow", function () {
				$('#form-success').slideDown("slow");
			});
	        
	        var code = res.promoCode;
	        $('#r-code').html(code);
	      } else if (res.error) {
	      }
		  })
		  .fail(function(res, statusText){
		  	window.ui.log('in fail condition');
		  	window.ui.log(statusText);
		  	window.ui.log(res);
		  	if (res.responseText.match(/SOEID/i)) {
				$('#the-code').css("border","2px solid red");
				$('#captcha_img').attr('src','/captcha/?sid=' + Math.random());
		  		$('p.is-used').show();
		  	} else if (res.responseText.match(/invalid captcha/i)) {
				$('#the-capcha').css("border","2px solid red");
		  		$('p.generic').show();
				// Refresh Captcha
				$('#captcha_img').attr('src','/captcha/?sid=' + Math.random());
				$('#the-capcha').val('');
		  	} else {
		  		$('#the-code').css("border","2px solid red");
				$('#captcha_img').attr('src','/captcha/?sid=' + Math.random());
				$('p.generic').show();
		  	}
		  });
	});
});