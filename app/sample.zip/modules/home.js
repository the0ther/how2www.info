co.UserReady.then(function(){

	var _changingAthlete = ($.cookie('changingathlete') != null)?true:false;

	if(ui.theUser.get('athleteId') == null || ui.theUser.get('athleteId') == 0 || _changingAthlete){
		$('.container-dashboard-page').remove();
		$('.container-welcome-page').attr('role','main').attr('id','main');
		$('header').css('background-image', function(index, value) {
			
			return value.replace('_01.jpg', '_00.jpg');
		});
		ui.tracking.track("Home_PV");
		ui.theUser.populateBestMatchValues();
	} else {
		if(document.location.search.indexOf('supported') != -1) {
			$('.container-dashboard-page').remove();
			$('.container-welcome-page').attr('role','main').attr('id','main');
			ui.theRegView = new co.RegistrationView({el:'#main'});
			
		}else{
			// trash the welcome stuff and show the dashboard
			$('.container-welcome-page').remove();
			$('.container-dashboard-page').attr('role','main').attr('id','main');
			$('header').css('background-image', function(index, value) {
				return value.replace('_01.jpg', '_' + ui.theUser.get('athleteId') + '.jpg');
			});
			//document.location.href = "/dashboard";
			ui.tracking.track("Dashboard_PV");
			require([window.ui.serverBasePath+"/js/modules/dashboard.js"]);
		}
	}
});