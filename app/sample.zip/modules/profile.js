
co.ProfileView = Backbone.View.extend({
	initialize:function(){
		
		$(this.el).css({opacity:0,visibility:'visible'}).animate({opacity:1},1200,"swing");
		this.render();
		this._thePromoCodeForm = new co.PromoCodeFormView({el:'.container-promo-code-form'});
	},
	events:{
		"click .trigger-share-app":"shareApp"
	},
	render:function(){
		var _params = {
			firstName:ui.theAthletes.get(ui.theUser.get('athleteId')).get('firstName'),
			lastName:ui.theAthletes.get(ui.theUser.get('athleteId')).get('lastName'),
			causeName:ui.theCauses.get(ui.theAthletes.get(ui.theUser.get('athleteId')).get('causeId')).get('title'),
			points:ui.theUser.attributes.totalPoints,
			fbPoints:ui.theUser.attributes.fbPoints,
			twitterPoints:ui.theUser.attributes.twitterPoints,
			foursquarePoints:ui.theUser.attributes.twitterPoints,
			socialPoints:ui.theUser.attributes.fbPoints+ui.theUser.attributes.twitterPoints,
			athleteImgUrl:"/images/athlete-detail/"+ui.theUser.get('athleteId')+"/about-photo.png",
			activity:ui.theUser.attributes.points.details
		};
		
		if(!ui.theUser.attributes.twitter){
			_params.twitterPoints = -1;
		}

		if(!ui.theUser.attributes.foursquare){
			_params.foursquarePoints = -1;
		}

		$(this.el).html(_.template($('#profile-template').html(),_params));
		this.$('h1:first').canvasToolbox({type:'gradient-title'});

		var _points = ui.theUser.attributes.totalPoints.toString().split("");

		for(var i=0; (typeof _points !== 'undefined') && i<_points.length; i++){
			this.$('.container-profile-counter').append('<span>'+_points[i]+'</span>');
		}

		if(window.PIE) {
			this.$('.cta_style-04').each(function() {
				PIE.attach(this);
			});
		}
	},
	shareApp:function(){
		ui.shareApp();
		return false;
	}
});

co.UserReady.then(function(){
	
	$(document).on('click', '[data-trigger-action="close-modal"]', function(){
		$('#modal-mask, #modal-container').hide();
	});

	$(document).on('click', '[data-trigger-action="clear-athlete"]', function(){
		$.cookie('changingathlete', 'true', {path: '/'});
		document.location.href = "/fb/home";
	});

	$(document).on('ui:loaded', '.modal-body', function(){
		$('[data-target-data="athlete-name"]').text(ui.theAthletes.get(ui.theUser.get('athleteId')).get('firstName'));
		$('[data-target-data="cause-title"]').text(ui.theCauses.get(ui.theAthletes.get(ui.theUser.get('athleteId')).get('causeId')).get('title'));
	});

	ui.theProfileView = new co.ProfileView({el:$('#main')});
	
	$('header').css('background-image', function(index, value) {
			
		return value.replace('_04.jpg', '_' + ui.theUser.get('athleteId') + '.jpg');
	});
	
});

