
co.UserReady.then(function(){
	// listen for enter keypress, submit form on enter
	$(document).on('keypress', function(evt) {
		if(evt.which === 13){
			$('.enter').trigger('click');
		}
	});

	$('h1:first').canvasToolbox({type:'gradient-title'});
	$('h2.gradient span').attr('data-title-size',30).canvasToolbox({type:'gradient-title'});

	$('#over18, #agreedToTerms').on('click', function(){
		if ($(this).is(':checked')) {
			$('+label', this).removeClass('errText');
		}
	});
	
	$('.share').on('click', function(){
		window.ui.log('entering share.click()');
		window.ui.shareApp();
	});
	
	$('.enter').on('click', function(){
		var data = $.extend(window.ui.theSweeps.toJSON(), {token: window.ui.theUser.get('token')});
		var check = co.checkSweepsForm();
		if (check === undefined) {
			$.ajax({
				url: '/sweepstakes', 
				data: data, 
				success: function(data){
					if (data.success) {
						window.ui.theSweepsForm._viewstate = 'done';
						window.ui.theSweepsForm.render();
					} // TODO: fails quietly
				},
				type: 'POST'
			});
		}
	});
	
	//TODO: i think this might be a problem when minified, prefer bind() or on()
	$('.win input[type="text"]').focus(function() {
		$(this).addClass('focused');
	}).blur(function() {
		$(this).removeClass('focused');
	});
	
	$('#firstName').on('change', function(){
		window.ui.theSweeps.set({firstName: $.trim($(this).val())});
	});

	$('#lastName').on('change', function(){
		window.ui.theSweeps.set({lastName: $.trim($(this).val())});
	});

	$('#zip').on('change', function(){
		window.ui.theSweeps.set({zip: $.trim($(this).val())});
	});

	$('#email').on('change', function(){
		window.ui.theSweeps.set({email: $.trim($(this).val())});
	});

	$('#phoneNum').on('change', function(){
		window.ui.theSweeps.set({phone: $.trim($(this).val())});
	});

	$('#over18').on('change', function(){
		window.ui.theSweeps.set({over18: ($(this).val()==='on')?1:0});
	});
	
	$('#agreedToTerms').on('change', function(){
		window.ui.theSweeps.set({agreedToTerms: ($(this).val()==='on')?1:0});
	});
	
	$('#optin').on('change', function(){
		window.ui.theSweeps.set({optin: ($(this).val()==='on')?1:0});
	});

	if(!('placeholder' in document.createElement('input'))) {
		$('[placeholder]').each(function () {
			$(this).val($.trim($(this).attr('placeholder')));
		});
		$('[placeholder]').bind('focus', function () {
			 if($.trim($(this).val()) == $.trim($(this).attr('placeholder'))) {$(this).val(""); }
		});
		$('[placeholder]').bind('blur', function () {
			if($.trim($(this).val()) == '') { $(this).val($.trim($(this).attr('placeholder'))); }
		});
	}
	
	if(window.PIE) {
		$('.cta_style-04').each(function() {
			PIE.detach(this);
			PIE.attach(this);
		});
	}

	window.ui.theSweeps = new co.SweepsModel();
	window.ui.theSweepsForm = new co.SweepsForm();
});


co.SweepsModel = Backbone.Model.extend({
	validate: function(attrs){
		window.ui.log('entering validate');
		window.ui.log(attrs);
		var isValid = true;
		var retval = {};
		
		if (attrs.firstName && !/[a-zA-Z ]+/.test(attrs.firstName)) {
			retval.firstName = false;
			$('#firstName').addClass('err');
			$('#firstName').siblings('label').addClass('errText')
			isValid = false;
		} else if (attrs.firstName) {
			$('#firstName').removeClass('err');
			$('#firstName').siblings('label').removeClass('errText');
		}
		if (attrs.lastName && !/[a-zA-Z ]+/.test(attrs.lastName)) {
			retval.lastName = false;
			$('#lastName').addClass('err');
			$('#lastName').siblings('label').addClass('errText');
			isValid = false;
		} else if (attrs.lastName) {
			$('#lastName').removeClass('err');
			$('#lastName').siblings('label').removeClass('errText');
		}
		if (attrs.zip && !window.ui.zipRegex.test(attrs.zip)) {
			retval.zip = false;
			$('#zip').addClass('err');
			$('#zip').siblings('label').addClass('errText');
			isValid = false;
		} else if (attrs.zip) {
			$('#zip').removeClass('err');
			$('#zip').siblings('label').removeClass('errText');
		}
		if (attrs.email && !window.ui.emailRegex.test(attrs.email)) {
			retval.email = false;
			$('#email').addClass('err');
			$('#email').siblings('label').addClass('errText');
			isValid = false;
		} else if (attrs.email) {
			$('#email').removeClass('err');
			$('#email').siblings('label').removeClass('errText');
		}
		if (attrs.phone && attrs.phone !== '' && !window.ui.phoneRegex.test(attrs.phone)) {
			retval.phone = false;
			$('#phoneNum').addClass('err');
			$('#phoneNum').siblings('label').addClass('errText');
			isValid = false;
		} else if (attrs.phone) {
			$('#phoneNum').removeClass('err');
			$('#phoneNum').siblings('label').removeClass('errText');
		}
		if (attrs.over18 && attrs.over18 !== 1) {
			retval.over18 = false;
			$('#over18').parent().addClass('errText');
			isValid = false;
		}
		if (attrs.agreedToTerms && attrs.agreedToTerms !== 1) {
			retval.agreedToTerms = false;
			$('#agreedToTerms').parent().addClass('errText');
			isValid = false;
		}
		if (!isValid) {
			return retval;
		}
	}
});

co.SweepsForm = Backbone.View.extend({
	$el: function(){
		return $('#main');
	},
	render: function() {
		if (this._viewstate !== 'enter' && this._viewstate !== 'error') {
			window.ui.tracking.track("Sweeps_TY_PV");
			$('#formContainer').hide();
			$('.done').show();
			$('h1:last').canvasToolbox({type:'gradient-title'});
		}
	},
	initialize:function(){
		this._viewstates = ["enter","error","done"];
		this._viewstate = "enter";
		this.render();
	}
});

co.checkSweepsForm = function() {
	var isValid = true;
	var retval = {};
	
	if (!window.ui.theSweeps.get('firstName') || !/[a-zA-Z ]+/.test(window.ui.theSweeps.get('firstName'))) {
		retval.firstName = false;
		$('#firstName').addClass('err');
		$('#firstName').siblings('label').addClass('errText');
		isValid = false;
	} else {
		$('#firstName').removeClass('err');
		$('#firstName').siblings('label').removeClass('errText');
	}
	if (!window.ui.theSweeps.get('lastName') || !/[a-zA-Z ]+/.test(window.ui.theSweeps.get('lastName'))) {
		retval.lastName = false;
		$('#lastName').addClass('err');
		$('#lastName').siblings('label').addClass('errText');
		isValid = false;
	} else {
		$('#lastName').removeClass('err');
		$('#lastName').siblings('label').removeClass('errText');
	}
	if (!window.ui.theSweeps.get('zip') || !window.ui.zipRegex.test(window.ui.theSweeps.get('zip'))) {
		retval.zip = false;
		$('#zip').addClass('err');
		$('#zip').siblings('label').addClass('errText');
		isValid = false;
	} else {
		$('#zip').removeClass('err');
		$('#zip').siblings('label').removeClass('errText');
	}
	if (!window.ui.theSweeps.get('email') || !window.ui.emailRegex.test(window.ui.theSweeps.get('email'))) {
		retval.email = false;
		$('#email').addClass('err');
		$('#email').siblings('label').addClass('errText');
		isValid = false;
	} else {
		$('#email').removeClass('err');
		$('#email').siblings('label').removeClass('errText');
	}
	if ((window.ui.theSweeps.get('phone') !== undefined && window.ui.theSweeps.get('phone') !== '' && !window.ui.phoneRegex.test(window.ui.theSweeps.get('phone'))) 
			|| ( $('#phoneNum').val() !== '' && !window.ui.phoneRegex.test($('#phoneNum').val()) )
			) {
		retval.phone = false;
		$('#phoneNum').addClass('err');
		$('#phoneNum').siblings('label').addClass('errText');
		isValid = false;
	} else {
		$('#phoneNum').removeClass('err');
		$('#phoneNum').siblings('label').removeClass('errText');
	}
	if (!window.ui.theSweeps.get('over18') || window.ui.theSweeps.get('over18') !== 1) {
		retval.over18 = false;
		$('#over18').siblings('label').addClass('errText');
		isValid = false;
	} else {
		$('#over18').siblings('label').removeClass('errText');
	}
	if (!window.ui.theSweeps.get('agreedToTerms') || window.ui.theSweeps.get('agreedToTerms') !== 1) {
		retval.agreedToTerms = false;
		$('#agreedToTerms').siblings('label').addClass('errText');
		isValid = false;
	} else {
		$('#agreedToTerms').siblings('label').removeClass('errText');
	}
	if (!isValid) {
		return retval;
	}
};
