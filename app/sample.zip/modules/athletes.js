co.UserReady.then(function(){

	var _html = new Array();
	var sortedAthletes = ui.theAthletes.sortBy(function(item) { return item.get('firstName'); });
	_.each(sortedAthletes, function(athlete) {
		_html.push(_.template($('#athlete-list-template').html(), athlete.toJSON()));
	});
	$('#athlete-list-container').append(_html.join(""));

	$('#main').css({opacity:0,visibility:'visible'}).animate({opacity:1},1200,"swing",function() {
		$('h1:first').canvasToolbox({type:'gradient-title'});		
	});

	$(document).on('click', '.container-athlete', function(){
		window.location = $(this).find('a').attr('href');
	});

});